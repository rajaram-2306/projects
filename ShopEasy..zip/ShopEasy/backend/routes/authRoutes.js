import { Router } from 'express';
import {
  registerCustomer,
  registerSeller,
  login,
  getMe,
  logout,
  forgotPassword,
  resetPassword
} from '../controllers/authController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import {
  validateCustomerRegistration,
  validateSellerRegistration,
  validateLogin,
  validateForgotPassword,
  validateResetPassword
} from '../middleware/validators/authValidators.js';

const router = Router();

// Public Authentication Endpoints
router.post('/register', validateCustomerRegistration, registerCustomer);
router.post('/register/seller', validateSellerRegistration, registerSeller);
router.post('/login', validateLogin, login);
router.post('/logout', logout);
router.post('/forgot-password', validateForgotPassword, forgotPassword);
router.post('/reset-password', validateResetPassword, resetPassword);

// Protected Authentication Endpoints
router.get('/me', protect, getMe);

// Role Guard Verification Endpoints
router.get('/seller-only', protect, restrictTo('SELLER', 'ADMIN'), (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'Authorized: You have accessed the protected Seller endpoint.',
    user: { id: req.user.id, role: req.user.role }
  });
});

router.get('/admin-only', protect, restrictTo('ADMIN'), (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'Authorized: You have accessed the protected SuperAdmin endpoint.',
    user: { id: req.user.id, role: req.user.role }
  });
});

export default router;
