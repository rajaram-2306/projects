import { Router } from 'express';
import { getAllProducts, getProductByIdOrCode } from '../controllers/productController.js';

const router = Router();

router.get('/', getAllProducts);
router.get('/:id', getProductByIdOrCode);
router.get('/id/:id', getProductByIdOrCode);

export default router;
