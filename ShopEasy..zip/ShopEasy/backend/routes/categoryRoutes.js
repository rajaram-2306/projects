import { Router } from 'express';
import { getAllCategories, getCategoryByCode } from '../controllers/categoryController.js';

const router = Router();

router.get('/', getAllCategories);
router.get('/:code', getCategoryByCode);

export default router;
