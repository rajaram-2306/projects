import { sequelize, activeDialect } from '../config/database.js';
import { env } from '../config/env.js';

export const getHealth = async (req, res, next) => {
  try {
    let dbStatus = 'healthy';
    try {
      await sequelize.authenticate();
    } catch (e) {
      dbStatus = 'disconnected';
    }

    res.status(200).json({
      status: 'success',
      message: 'ShopEasy API is operational',
      data: {
        environment: env.NODE_ENV,
        database: {
          status: dbStatus,
          dialect: activeDialect,
          name: env.DB_NAME
        },
        uptime: `${Math.round(process.uptime())}s`,
        timestamp: new Date().toISOString()
      }
    });
  } catch (err) {
    next(err);
  }
};
