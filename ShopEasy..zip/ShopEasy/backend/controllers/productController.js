import { Op } from 'sequelize';
import { Product, ProductImage, Category, Subcategory, Brand, Seller, Review, User } from '../models/index.js';
import { AppError } from '../utils/AppError.js';

export const getAllProducts = async (req, res, next) => {
  try {
    const {
      q,
      category,
      brand,
      minPrice,
      maxPrice,
      minRating,
      inStock,
      deal,
      trending,
      bestseller,
      sort = 'relevance',
      page = 1,
      limit = 20
    } = req.query;

    const where = { status: 'ACTIVE' };

    // Search query
    if (q) {
      const searchTerm = `%${q.trim()}%`;
      where[Op.or] = [
        { product_name: { [Op.like]: searchTerm } },
        { short_description: { [Op.like]: searchTerm } },
        { product_id: { [Op.like]: searchTerm } },
        { sku: { [Op.like]: searchTerm } }
      ];
    }

    // Category filter
    if (category && category !== 'all') {
      const catRecord = await Category.findOne({
        where: { [Op.or]: [{ id: category }, { code: category.toUpperCase() }] }
      });
      if (catRecord) {
        where.category_id = catRecord.id;
      }
    }

    // Brand filter
    if (brand) {
      const brandsList = Array.isArray(brand) ? brand : brand.split(',');
      const brandRecords = await Brand.findAll({ where: { name: { [Op.in]: brandsList } } });
      if (brandRecords.length > 0) {
        where.brand_id = { [Op.in]: brandRecords.map((b) => b.id) };
      }
    }

    // Price filtering
    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) where.price[Op.gte] = parseFloat(minPrice);
      if (maxPrice) where.price[Op.lte] = parseFloat(maxPrice);
    }

    // Rating filtering
    if (minRating) {
      where.rating = { [Op.gte]: parseFloat(minRating) };
    }

    // In-Stock filtering
    if (inStock === 'true') {
      where.stock_quantity = { [Op.gt]: 0 };
    }

    // Flags
    if (deal === 'true') where.is_deal = true;
    if (trending === 'true') where.is_trending = true;
    if (bestseller === 'true') where.is_bestseller = true;

    // Sorting
    let order = [['created_at', 'DESC']];
    if (sort === 'price_low') order = [['price', 'ASC']];
    if (sort === 'price_high') order = [['price', 'DESC']];
    if (sort === 'rating') order = [['rating', 'DESC']];
    if (sort === 'discount') order = [['discount', 'DESC']];
    if (sort === 'newest') order = [['created_at', 'DESC']];

    // Pagination
    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 20;
    const offset = (pageNum - 1) * limitNum;

    const { count, rows: products } = await Product.findAndCountAll({
      where,
      include: [
        { model: ProductImage, as: 'images', attributes: ['id', 'image_url', 'is_primary'] },
        { model: Category, as: 'category', attributes: ['id', 'name', 'code', 'slug'] },
        { model: Subcategory, as: 'subcategory', attributes: ['id', 'name', 'slug'] },
        { model: Brand, as: 'brand', attributes: ['id', 'name', 'slug'] },
        { model: Seller, as: 'seller', attributes: ['id', 'business_name', 'rating'] }
      ],
      order,
      limit: limitNum,
      offset
    });

    res.status(200).json({
      status: 'success',
      results: products.length,
      pagination: {
        total: count,
        page: pageNum,
        totalPages: Math.ceil(count / limitNum),
        limit: limitNum
      },
      data: { products }
    });
  } catch (err) {
    next(err);
  }
};

export const getProductByIdOrCode = async (req, res, next) => {
  try {
    const { id } = req.params;

    const product = await Product.findOne({
      where: {
        [Op.or]: [{ id }, { product_id: id.toUpperCase() }]
      },
      include: [
        { model: ProductImage, as: 'images', attributes: ['id', 'image_url', 'is_primary'] },
        { model: Category, as: 'category', attributes: ['id', 'name', 'code', 'slug'] },
        { model: Subcategory, as: 'subcategory', attributes: ['id', 'name', 'slug'] },
        { model: Brand, as: 'brand', attributes: ['id', 'name', 'slug'] },
        { model: Seller, as: 'seller', attributes: ['id', 'business_name', 'rating'] },
        {
          model: Review,
          as: 'reviews',
          where: { status: 'APPROVED' },
          required: false,
          include: [{ model: User, as: 'user', attributes: ['name', 'avatar'] }]
        }
      ]
    });

    if (!product) {
      return next(new AppError(`Product with identifier '${id}' was not found in ShopEasy catalog`, 404));
    }

    res.status(200).json({
      status: 'success',
      data: { product }
    });
  } catch (err) {
    next(err);
  }
};
