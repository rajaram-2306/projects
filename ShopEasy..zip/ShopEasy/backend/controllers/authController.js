import { Op } from 'sequelize';
import { User, Seller, Cart, Address } from '../models/index.js';
import { AppError } from '../utils/AppError.js';
import { signToken, hashPassword, comparePasswords, generateResetToken, hashToken } from '../utils/auth.js';

// In-memory or database reset token registry for forgot/reset flow
const resetPasswordStore = new Map();

/**
 * Format clean sanitized user response (excluding password hash)
 */
const formatAuthResponse = (user, token) => {
  const userData = {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    role: user.role,
    whatsapp_verified: user.whatsapp_verified,
    avatar: user.avatar,
    status: user.status,
    seller: user.seller
      ? {
          id: user.seller.id,
          business_name: user.seller.business_name,
          business_email: user.seller.business_email,
          approval_status: user.seller.approval_status
        }
      : null,
    created_at: user.created_at
  };

  return {
    status: 'success',
    token,
    data: {
      user: userData
    }
  };
};

/**
 * Register a new Customer
 */
export const registerCustomer = async (req, res, next) => {
  try {
    const { name, email, phone, password, whatsapp_verified } = req.body;

    // Check existing email or phone
    const existingUser = await User.findOne({
      where: {
        [Op.or]: [{ email }, { phone }]
      }
    });

    if (existingUser) {
      if (existingUser.email === email) {
        return next(new AppError('An account with this email address already exists. Please sign in.', 400));
      }
      if (existingUser.phone === phone) {
        return next(new AppError('An account with this mobile number already exists.', 400));
      }
    }

    // Hash password
    const password_hash = await hashPassword(password);

    // Create user
    const newUser = await User.create({
      name,
      email,
      phone,
      password_hash,
      role: 'CUSTOMER',
      whatsapp_verified: whatsapp_verified || false,
      status: 'ACTIVE'
    });

    // Create empty Cart for user
    await Cart.create({
      user_id: newUser.id,
      status: 'ACTIVE'
    });

    const token = signToken(newUser);
    res.status(201).json(formatAuthResponse(newUser, token));
  } catch (err) {
    next(err);
  }
};

/**
 * Register a new Seller
 */
export const registerSeller = async (req, res, next) => {
  try {
    const {
      name,
      email,
      phone,
      password,
      business_name,
      business_email,
      business_phone,
      gst_number,
      pan_number,
      store_description
    } = req.body;

    // Check existing user
    const existingUser = await User.findOne({
      where: {
        [Op.or]: [{ email }, { phone }]
      }
    });

    if (existingUser) {
      return next(new AppError('An account with this email or phone number already exists.', 400));
    }

    const password_hash = await hashPassword(password);

    // Create Seller User
    const newUser = await User.create({
      name,
      email,
      phone,
      password_hash,
      role: 'SELLER',
      whatsapp_verified: true, // Will be verified via OTP
      status: 'ACTIVE'
    });

    // Create Seller Profile Record
    const newSeller = await Seller.create({
      user_id: newUser.id,
      business_name,
      business_email: business_email || email,
      business_phone: business_phone || phone,
      gst_number,
      pan_number,
      store_description,
      approval_status: 'PENDING'
    });

    // Create Cart
    await Cart.create({
      user_id: newUser.id,
      status: 'ACTIVE'
    });

    newUser.seller = newSeller;
    const token = signToken(newUser);

    res.status(201).json(formatAuthResponse(newUser, token));
  } catch (err) {
    next(err);
  }
};

/**
 * User Login
 */
export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // Find user with password hash
    const user = await User.findOne({
      where: { email },
      include: [{ model: Seller, as: 'seller', required: false }]
    });

    if (!user) {
      return next(new AppError('Invalid email or password.', 401));
    }

    // Verify bcrypt password
    const isPasswordCorrect = await comparePasswords(password, user.password_hash);
    if (!isPasswordCorrect) {
      return next(new AppError('Invalid email or password.', 401));
    }

    // Check if account is suspended
    if (user.status === 'SUSPENDED') {
      return next(new AppError('Your account has been suspended. Please contact customer support.', 403));
    }

    const token = signToken(user);
    res.status(200).json(formatAuthResponse(user, token));
  } catch (err) {
    next(err);
  }
};

/**
 * Get Current Authenticated User Profile
 */
export const getMe = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id, {
      include: [
        { model: Seller, as: 'seller', required: false },
        { model: Address, as: 'addresses', required: false }
      ]
    });

    res.status(200).json({
      status: 'success',
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role,
          whatsapp_verified: user.whatsapp_verified,
          avatar: user.avatar,
          status: user.status,
          seller: user.seller,
          addresses: user.addresses,
          created_at: user.created_at
        }
      }
    });
  } catch (err) {
    next(err);
  }
};

/**
 * User Logout
 */
export const logout = (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'User successfully logged out.'
  });
};

/**
 * Forgot Password: Generates reset token
 */
export const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({ where: { email } });
    if (!user) {
      return next(new AppError('No user account found with that email address.', 404));
    }

    const { resetToken, hashedToken, expiresAt } = generateResetToken();
    resetPasswordStore.set(hashedToken, {
      userId: user.id,
      expiresAt
    });

    // In a live environment this sends an email; for dev/demo we return instructions + demo reset token
    res.status(200).json({
      status: 'success',
      message: 'Password reset instructions have been generated.',
      resetToken, // Provided in response for seamless local testing & verification
      expiresIn: '15 minutes'
    });
  } catch (err) {
    next(err);
  }
};

/**
 * Reset Password with token
 */
export const resetPassword = async (req, res, next) => {
  try {
    const { token, new_password } = req.body;

    const hashedToken = hashToken(token);
    const resetEntry = resetPasswordStore.get(hashedToken);

    if (!resetEntry || resetEntry.expiresAt < new Date()) {
      return next(new AppError('Password reset token is invalid or has expired.', 400));
    }

    const user = await User.findByPk(resetEntry.userId);
    if (!user) {
      return next(new AppError('User belonging to this reset token was not found.', 404));
    }

    // Update password
    user.password_hash = await hashPassword(new_password);
    await user.save();

    // Invalidate reset token
    resetPasswordStore.delete(hashedToken);

    const freshToken = signToken(user);
    res.status(200).json({
      status: 'success',
      message: 'Password has been updated successfully.',
      token: freshToken,
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      }
    });
  } catch (err) {
    next(err);
  }
};
