import { Category, Subcategory, Product } from '../models/index.js';
import { AppError } from '../utils/AppError.js';

export const getAllCategories = async (req, res, next) => {
  try {
    const categories = await Category.findAll({
      where: { status: 'ACTIVE' },
      include: [
        {
          model: Subcategory,
          as: 'subcategories',
          attributes: ['id', 'name', 'slug', 'description']
        }
      ],
      order: [['name', 'ASC']]
    });

    res.status(200).json({
      status: 'success',
      results: categories.length,
      data: { categories }
    });
  } catch (err) {
    next(err);
  }
};

export const getCategoryByCode = async (req, res, next) => {
  try {
    const { code } = req.params;
    const category = await Category.findOne({
      where: { code: code.toUpperCase() },
      include: [
        {
          model: Subcategory,
          as: 'subcategories'
        }
      ]
    });

    if (!category) {
      return next(new AppError(`Category with code ${code} not found`, 404));
    }

    res.status(200).json({
      status: 'success',
      data: { category }
    });
  } catch (err) {
    next(err);
  }
};
