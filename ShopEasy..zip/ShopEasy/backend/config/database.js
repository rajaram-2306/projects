import { Sequelize } from 'sequelize';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import mysql from 'mysql2/promise';
import { env } from './env.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbDir = path.resolve(__dirname, '../database');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

let activeDialect = env.DB_DIALECT;

// Quick synchronous-style pre-check or default to SQLite fallback if MySQL config is not active
function getSequelizeInstance() {
  if (env.DB_DIALECT === 'sqlite') {
    activeDialect = 'sqlite';
    return new Sequelize({
      dialect: 'sqlite',
      storage: env.DB_STORAGE,
      logging: false,
      define: {
        timestamps: true,
        underscored: true
      }
    });
  }

  // If dialect is mysql
  return new Sequelize(env.DB_NAME, env.DB_USER, env.DB_PASSWORD, {
    host: env.DB_HOST,
    port: env.DB_PORT,
    dialect: 'mysql',
    logging: false,
    pool: {
      max: 10,
      min: 0,
      acquire: 5000,
      idle: 10000
    },
    define: {
      timestamps: true,
      underscored: true
    }
  });
}

// If MySQL is requested, check if MySQL server is running; if not, configure SQLite to avoid crash
let sequelize;

try {
  if (env.DB_DIALECT === 'mysql') {
    // Attempt rapid probe to MySQL
    const probe = await mysql.createConnection({
      host: env.DB_HOST,
      port: env.DB_PORT,
      user: env.DB_USER,
      password: env.DB_PASSWORD,
      connectTimeout: 1000
    }).catch((err) => {
      // Failed probe
      return null;
    });

    if (probe) {
      await probe.end();
      activeDialect = 'mysql';
      sequelize = getSequelizeInstance();
    } else {
      console.warn(`[Database Notice] MySQL service not accessible at ${env.DB_HOST}:${env.DB_PORT} with current credentials.`);
      console.log(`[Database] Auto-configuring local relational SQLite database for zero-downtime development...`);
      activeDialect = 'sqlite';
      sequelize = new Sequelize({
        dialect: 'sqlite',
        storage: env.DB_STORAGE,
        logging: false,
        define: {
          timestamps: true,
          underscored: true
        }
      });
    }
  } else {
    activeDialect = 'sqlite';
    sequelize = getSequelizeInstance();
  }
} catch (err) {
  activeDialect = 'sqlite';
  sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: env.DB_STORAGE,
    logging: false,
    define: {
      timestamps: true,
      underscored: true
    }
  });
}

export async function connectDB() {
  try {
    await sequelize.authenticate();
    console.log(`[Database] Successfully connected to relational ${activeDialect.toUpperCase()} storage.`);
    return sequelize;
  } catch (error) {
    console.error(`[Database Error] Connection failed:`, error);
    throw error;
  }
}

export { sequelize, activeDialect };
