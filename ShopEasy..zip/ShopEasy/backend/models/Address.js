import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Address = sequelize.define('Address', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  name: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  mobile: {
    type: DataTypes.STRING(20),
    allowNull: false
  },
  street: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  state: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  pin: {
    type: DataTypes.STRING(10),
    allowNull: false
  },
  landmark: {
    type: DataTypes.STRING(150),
    allowNull: true
  },
  type: {
    type: DataTypes.ENUM('HOME', 'WORK', 'OTHER'),
    defaultValue: 'HOME'
  },
  is_default: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
}, {
  tableName: 'addresses',
  timestamps: true,
  underscored: true
});
