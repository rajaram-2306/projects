import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Product = sequelize.define('Product', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  product_id: {
    type: DataTypes.STRING(30),
    allowNull: false,
    unique: true // Unique Immutable ShopEasy ID e.g. SHP-ELE-000001
  },
  product_name: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  slug: {
    type: DataTypes.STRING(280),
    allowNull: false,
    unique: true
  },
  category_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  subcategory_id: {
    type: DataTypes.STRING(36),
    allowNull: true
  },
  brand_id: {
    type: DataTypes.STRING(36),
    allowNull: true
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  short_description: {
    type: DataTypes.STRING(500),
    allowNull: false
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  original_price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  discount: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  stock_quantity: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  sku: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true
  },
  specifications: {
    type: DataTypes.JSON,
    defaultValue: {}
  },
  highlights: {
    type: DataTypes.JSON,
    defaultValue: []
  },
  tags: {
    type: DataTypes.JSON,
    defaultValue: []
  },
  rating: {
    type: DataTypes.DECIMAL(3, 2),
    defaultValue: 0.00
  },
  review_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  seller_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('ACTIVE', 'INACTIVE', 'DRAFT'),
    defaultValue: 'ACTIVE'
  },
  is_featured: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  is_trending: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  is_deal: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  is_bestseller: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
}, {
  tableName: 'products',
  timestamps: true,
  underscored: true
});
