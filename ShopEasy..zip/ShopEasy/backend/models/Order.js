import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Order = sequelize.define('Order', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  order_id: {
    type: DataTypes.STRING(30),
    allowNull: false,
    unique: true // e.g. ORD-2026-000001
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  subtotal: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  discount_amount: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00
  },
  shipping_fee: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00
  },
  tax_amount: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00
  },
  total_amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  coupon_id: {
    type: DataTypes.STRING(36),
    allowNull: true
  },
  order_status: {
    type: DataTypes.ENUM('PLACED', 'CONFIRMED', 'PACKED', 'SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED'),
    defaultValue: 'PLACED'
  },
  shipping_address_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  }
}, {
  tableName: 'orders',
  timestamps: true,
  underscored: true
});

export const OrderItem = sequelize.define('OrderItem', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  order_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  product_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  product_code: {
    type: DataTypes.STRING(30),
    allowNull: false // Preserves SHP-[CAT]-[NUM] in order history
  },
  product_name: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  sku: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  image_url: {
    type: DataTypes.STRING(500),
    allowNull: false
  },
  seller_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  }
}, {
  tableName: 'order_items',
  timestamps: true,
  underscored: true
});

export const Payment = sequelize.define('Payment', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  order_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    unique: true
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  payment_method: {
    type: DataTypes.ENUM('UPI', 'CREDIT_CARD', 'DEBIT_CARD', 'NET_BANKING', 'COD'),
    allowNull: false
  },
  payment_status: {
    type: DataTypes.ENUM('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED'),
    defaultValue: 'PENDING'
  },
  transaction_id: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  payment_gateway_response: {
    type: DataTypes.JSON,
    allowNull: true
  }
}, {
  tableName: 'payments',
  timestamps: true,
  underscored: true
});
