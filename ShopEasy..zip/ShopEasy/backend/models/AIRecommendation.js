import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const AIRecommendation = sequelize.define('AIRecommendation', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: true
  },
  product_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  score: {
    type: DataTypes.DECIMAL(4, 3),
    defaultValue: 0.000
  },
  recommendation_type: {
    type: DataTypes.ENUM('VIEW_SIMILAR', 'FREQUENTLY_BOUGHT', 'SEASONAL', 'BUDGET'),
    allowNull: false
  },
  reason: {
    type: DataTypes.STRING(255),
    allowNull: true
  }
}, {
  tableName: 'ai_recommendations',
  timestamps: true,
  underscored: true
});

export const SearchHistory = sequelize.define('SearchHistory', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: true
  },
  query: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  interpreted_filters: {
    type: DataTypes.JSON,
    allowNull: true
  },
  result_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
}, {
  tableName: 'search_history',
  timestamps: true,
  underscored: true
});

export const RecentlyViewed = sequelize.define('RecentlyViewed', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  product_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  viewed_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'recently_viewed',
  timestamps: false,
  underscored: true,
  indexes: [
    {
      unique: true,
      fields: ['user_id', 'product_id']
    }
  ]
});
