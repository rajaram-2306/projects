import { sequelize } from '../config/database.js';
import { User } from './User.js';
import { Seller } from './Seller.js';
import { Category } from './Category.js';
import { Subcategory } from './Subcategory.js';
import { Brand } from './Brand.js';
import { Product } from './Product.js';
import { ProductImage } from './ProductImage.js';
import { Cart, CartItem } from './Cart.js';
import { Wishlist } from './Wishlist.js';
import { Address } from './Address.js';
import { Order, OrderItem, Payment } from './Order.js';
import { Coupon } from './Coupon.js';
import { Review, Notification, Banner } from './Review.js';
import { AIRecommendation, SearchHistory, RecentlyViewed } from './AIRecommendation.js';

// ==================== RELATIONSHIPS & FOREIGN KEYS ====================

// User <-> Seller (1:1)
User.hasOne(Seller, { foreignKey: 'user_id', as: 'seller', onDelete: 'CASCADE' });
Seller.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User <-> Address (1:N)
User.hasMany(Address, { foreignKey: 'user_id', as: 'addresses', onDelete: 'CASCADE' });
Address.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User <-> Cart (1:1)
User.hasOne(Cart, { foreignKey: 'user_id', as: 'cart', onDelete: 'CASCADE' });
Cart.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User <-> Wishlist (1:N)
User.hasMany(Wishlist, { foreignKey: 'user_id', as: 'wishlist_items', onDelete: 'CASCADE' });
Wishlist.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User <-> Order (1:N)
User.hasMany(Order, { foreignKey: 'user_id', as: 'orders', onDelete: 'RESTRICT' });
Order.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User <-> Review (1:N)
User.hasMany(Review, { foreignKey: 'user_id', as: 'reviews', onDelete: 'CASCADE' });
Review.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User <-> Notification (1:N)
User.hasMany(Notification, { foreignKey: 'user_id', as: 'notifications', onDelete: 'CASCADE' });
Notification.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// Category <-> Subcategory (1:N)
Category.hasMany(Subcategory, { foreignKey: 'category_id', as: 'subcategories', onDelete: 'CASCADE' });
Subcategory.belongsTo(Category, { foreignKey: 'category_id', as: 'category' });

// Category <-> Product (1:N)
Category.hasMany(Product, { foreignKey: 'category_id', as: 'products', onDelete: 'RESTRICT' });
Product.belongsTo(Category, { foreignKey: 'category_id', as: 'category' });

// Subcategory <-> Product (1:N)
Subcategory.hasMany(Product, { foreignKey: 'subcategory_id', as: 'products', onDelete: 'SET NULL' });
Product.belongsTo(Subcategory, { foreignKey: 'subcategory_id', as: 'subcategory' });

// Brand <-> Product (1:N)
Brand.hasMany(Product, { foreignKey: 'brand_id', as: 'products', onDelete: 'SET NULL' });
Product.belongsTo(Brand, { foreignKey: 'brand_id', as: 'brand' });

// Seller <-> Product (1:N)
Seller.hasMany(Product, { foreignKey: 'seller_id', as: 'products', onDelete: 'CASCADE' });
Product.belongsTo(Seller, { foreignKey: 'seller_id', as: 'seller' });

// Product <-> ProductImage (1:N)
Product.hasMany(ProductImage, { foreignKey: 'product_id', as: 'images', onDelete: 'CASCADE' });
ProductImage.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

// Cart <-> CartItem (1:N)
Cart.hasMany(CartItem, { foreignKey: 'cart_id', as: 'items', onDelete: 'CASCADE' });
CartItem.belongsTo(Cart, { foreignKey: 'cart_id', as: 'cart' });

// Product <-> CartItem (1:N)
Product.hasMany(CartItem, { foreignKey: 'product_id', as: 'cart_entries', onDelete: 'CASCADE' });
CartItem.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

// Product <-> Wishlist (1:N)
Product.hasMany(Wishlist, { foreignKey: 'product_id', as: 'wishlisted_records', onDelete: 'CASCADE' });
Wishlist.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

// Order <-> OrderItem (1:N)
Order.hasMany(OrderItem, { foreignKey: 'order_id', as: 'items', onDelete: 'CASCADE' });
OrderItem.belongsTo(Order, { foreignKey: 'order_id', as: 'order' });

// Product <-> OrderItem (1:N)
Product.hasMany(OrderItem, { foreignKey: 'product_id', as: 'order_history_items', onDelete: 'RESTRICT' });
OrderItem.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

// Order <-> Payment (1:1)
Order.hasOne(Payment, { foreignKey: 'order_id', as: 'payment', onDelete: 'CASCADE' });
Payment.belongsTo(Order, { foreignKey: 'order_id', as: 'order' });

// Order <-> Address
Order.belongsTo(Address, { foreignKey: 'shipping_address_id', as: 'shipping_address' });

// Order <-> Coupon
Order.belongsTo(Coupon, { foreignKey: 'coupon_id', as: 'coupon' });

// Product <-> Review (1:N)
Product.hasMany(Review, { foreignKey: 'product_id', as: 'reviews', onDelete: 'CASCADE' });
Review.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

// Product <-> AIRecommendation (1:N)
Product.hasMany(AIRecommendation, { foreignKey: 'product_id', as: 'ai_recommendations', onDelete: 'CASCADE' });
AIRecommendation.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

// Product <-> RecentlyViewed (1:N)
Product.hasMany(RecentlyViewed, { foreignKey: 'product_id', as: 'recent_views', onDelete: 'CASCADE' });
RecentlyViewed.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

export {
  sequelize,
  User,
  Seller,
  Category,
  Subcategory,
  Brand,
  Product,
  ProductImage,
  Cart,
  CartItem,
  Wishlist,
  Address,
  Order,
  OrderItem,
  Payment,
  Coupon,
  Review,
  Notification,
  Banner,
  AIRecommendation,
  SearchHistory,
  RecentlyViewed
};
