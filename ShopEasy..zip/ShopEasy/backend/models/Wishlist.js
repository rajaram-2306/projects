import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Wishlist = sequelize.define('Wishlist', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  product_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  }
}, {
  tableName: 'wishlist',
  timestamps: true,
  underscored: true,
  indexes: [
    {
      unique: true,
      fields: ['user_id', 'product_id']
    }
  ]
});
