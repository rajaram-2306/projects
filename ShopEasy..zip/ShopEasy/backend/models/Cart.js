import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Cart = sequelize.define('Cart', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    unique: true
  },
  status: {
    type: DataTypes.ENUM('ACTIVE', 'ABANDONED', 'CHECKED_OUT'),
    defaultValue: 'ACTIVE'
  }
}, {
  tableName: 'carts',
  timestamps: true,
  underscored: true
});

export const CartItem = sequelize.define('CartItem', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  cart_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  product_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  quantity: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
    allowNull: false
  },
  variant: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  price_snapshot: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  }
}, {
  tableName: 'cart_items',
  timestamps: true,
  underscored: true
});
