import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Review = sequelize.define('Review', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  product_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  rating: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 5
    }
  },
  title: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  comment: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  verified_purchase: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  helpful_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  status: {
    type: DataTypes.ENUM('APPROVED', 'PENDING', 'REJECTED'),
    defaultValue: 'APPROVED'
  }
}, {
  tableName: 'reviews',
  timestamps: true,
  underscored: true
});

export const Notification = sequelize.define('Notification', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  title: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  message: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  type: {
    type: DataTypes.ENUM('ORDER', 'PROMOTION', 'SECURITY', 'SYSTEM'),
    defaultValue: 'SYSTEM'
  },
  is_read: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
}, {
  tableName: 'notifications',
  timestamps: true,
  underscored: true
});

export const Banner = sequelize.define('Banner', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  title: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  subtitle: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  image_url: {
    type: DataTypes.STRING(500),
    allowNull: false
  },
  link_url: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  position: {
    type: DataTypes.ENUM('HERO', 'PROMO', 'SIDEBAR'),
    defaultValue: 'HERO'
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  display_order: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
}, {
  tableName: 'banners',
  timestamps: true,
  underscored: true
});
