import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Coupon = sequelize.define('Coupon', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  coupon_code: {
    type: DataTypes.STRING(30),
    allowNull: false,
    unique: true
  },
  discount_type: {
    type: DataTypes.ENUM('PERCENT', 'FIXED'),
    allowNull: false
  },
  discount_value: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  minimum_order: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00
  },
  maximum_discount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  usage_limit: {
    type: DataTypes.INTEGER,
    defaultValue: 1000
  },
  used_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  expiry_date: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  description: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('ACTIVE', 'EXPIRED', 'DISABLED'),
    defaultValue: 'ACTIVE'
  }
}, {
  tableName: 'coupons',
  timestamps: true,
  underscored: true
});
