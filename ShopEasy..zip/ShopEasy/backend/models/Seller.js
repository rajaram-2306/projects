import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Seller = sequelize.define('Seller', {
  id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: DataTypes.UUIDV4
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    unique: true
  },
  business_name: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  business_email: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  business_phone: {
    type: DataTypes.STRING(20),
    allowNull: false
  },
  gst_number: {
    type: DataTypes.STRING(30),
    allowNull: true
  },
  pan_number: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  store_description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  rating: {
    type: DataTypes.DECIMAL(3, 2),
    defaultValue: 0.00
  },
  total_sales: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  approval_status: {
    type: DataTypes.ENUM('PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED'),
    defaultValue: 'PENDING'
  }
}, {
  tableName: 'sellers',
  timestamps: true,
  underscored: true
});
