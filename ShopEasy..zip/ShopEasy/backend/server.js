import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { env } from './config/env.js';
import { connectDB, sequelize, activeDialect } from './config/database.js';
import { AppError } from './utils/AppError.js';
import { errorHandler } from './middleware/errorHandler.js';
import apiRoutes from './routes/index.js';
import { seedDatabase } from './database/seed.js';
import { Product } from './models/index.js';

const app = express();

// Security & Utility Middlewares
app.use(helmet());
app.use(
  cors({
    origin: [env.CLIENT_URL, 'http://localhost:5173', 'http://127.0.0.1:5173'],
    credentials: true
  })
);
app.use(morgan(env.NODE_ENV === 'development' ? 'dev' : 'combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Root Welcome Route
app.get('/', (req, res) => {
  res.status(200).json({
    name: 'ShopEasy Backend API',
    tagline: 'Everything You Need. One Easy Shop.',
    version: '1.0.0',
    documentation: '/api/health',
    status: 'ACTIVE'
  });
});

// Mount Main API Router
app.use('/api', apiRoutes);

// Catch 404 for Undefined Routes
app.all('*', (req, res, next) => {
  next(new AppError(`Cannot find endpoint ${req.originalUrl} on ShopEasy server`, 404));
});

// Global Centralized Error Handling Middleware
app.use(errorHandler);

// Database Connection & Server Initialization
async function startServer() {
  try {
    await connectDB();
    await sequelize.sync(); // Ensure tables are created
    console.log(`[Database] Schema tables verified on ${activeDialect.toUpperCase()}`);

    // Auto-seed if database is empty
    const productCount = await Product.count();
    if (productCount === 0) {
      console.log('[Database] Database is empty. Running initial seed...');
      await seedDatabase();
    }

    app.listen(env.PORT, () => {
      console.log(`====================================================`);
      console.log(`🚀 ShopEasy Backend Server running on port ${env.PORT}`);
      console.log(`🌍 Environment: ${env.NODE_ENV}`);
      console.log(`🔗 API Base: http://localhost:${env.PORT}/api`);
      console.log(`❤️  Health Check: http://localhost:${env.PORT}/api/health`);
      console.log(`====================================================`);
    });
  } catch (error) {
    console.error('[Fatal Error] Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
