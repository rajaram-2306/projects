import bcrypt from 'bcryptjs';
import { connectDB } from '../config/database.js';
import {
  sequelize,
  User,
  Seller,
  Category,
  Subcategory,
  Brand,
  Product,
  ProductImage,
  Coupon,
  Review
} from '../models/index.js';

export async function seedDatabase() {
  try {
    console.log('[Seeder] Initializing database synchronization...');
    await connectDB();
    await sequelize.sync({ force: true });
    console.log('[Seeder] Database tables synchronized successfully.');

    // 1. Seed Users
    const passwordHash = await bcrypt.hash('ShopEasy@2026', 10);

    const customerUser = await User.create({
      id: 'usr-customer-001',
      name: 'Alex Johnson',
      email: 'customer@shopeasy.com',
      password_hash: passwordHash,
      phone: '+919876543210',
      role: 'CUSTOMER',
      whatsapp_verified: true,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      status: 'ACTIVE'
    });

    const sellerUser = await User.create({
      id: 'usr-seller-001',
      name: 'Apex Retailers',
      email: 'seller@shopeasy.com',
      password_hash: passwordHash,
      phone: '+919876543211',
      role: 'SELLER',
      whatsapp_verified: true,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      status: 'ACTIVE'
    });

    const adminUser = await User.create({
      id: 'usr-admin-001',
      name: 'ShopEasy SuperAdmin',
      email: 'admin@shopeasy.com',
      password_hash: passwordHash,
      phone: '+919876543212',
      role: 'ADMIN',
      whatsapp_verified: true,
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=200&q=80',
      status: 'ACTIVE'
    });

    // 2. Seed Seller Profile
    const seller = await Seller.create({
      id: 'sel-apex-001',
      user_id: sellerUser.id,
      business_name: 'Apex Official Store',
      business_email: 'support@apexretail.com',
      business_phone: '+919876543211',
      gst_number: '29ABCDE1234F1Z5',
      pan_number: 'ABCDE1234F',
      store_description: 'Authorized retailer of electronics, fashion, beauty, home and gadgets.',
      rating: 4.85,
      total_sales: 1420,
      approval_status: 'APPROVED'
    });

    // 3. Seed Categories & Subcategories
    const categoryData = [
      {
        id: 'cat-fas',
        name: "Women's Fashion",
        code: 'FAS',
        slug: 'womens-fashion',
        icon: 'Shirt',
        image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&w=600&q=80',
        subcategories: ["Women's Wear", 'Sarees', 'Kurtis']
      },
      {
        id: 'cat-mob',
        name: 'Mobile Accessories',
        code: 'MOB',
        slug: 'mobile-accessories',
        icon: 'Smartphone',
        image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80',
        subcategories: ['Fast Chargers', 'Power Banks', 'Phone Cases']
      },
      {
        id: 'cat-bea',
        name: 'Beauty & Skincare',
        code: 'BEA',
        slug: 'beauty-skincare',
        icon: 'Sparkles',
        image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80',
        subcategories: ['Skincare', 'Haircare', 'Cosmetics']
      },
      {
        id: 'cat-ele',
        name: 'Electronics',
        code: 'ELE',
        slug: 'electronics',
        icon: 'Laptop',
        image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&w=600&q=80',
        subcategories: ['Audio & Headphones', 'Laptops', 'Smart Gadgets']
      },
      {
        id: 'cat-hom',
        name: 'Home & Kitchen',
        code: 'HOM',
        slug: 'home-kitchen',
        icon: 'Home',
        image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&q=80',
        subcategories: ['Storage & Organizers', 'Kitchenware', 'Decor']
      }
    ];

    const categoryMap = new Map();
    const subcatMap = new Map();
    for (const cat of categoryData) {
      const createdCat = await Category.create({
        id: cat.id,
        name: cat.name,
        code: cat.code,
        slug: cat.slug,
        icon: cat.icon,
        image: cat.image,
        description: `Explore quality ${cat.name} products.`
      });
      categoryMap.set(cat.name, createdCat.id);

      for (const subName of cat.subcategories) {
        const subSlug = `${cat.slug}-${subName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
        const createdSub = await Subcategory.create({
          id: `sub-${subSlug}`,
          category_id: createdCat.id,
          name: subName,
          slug: subSlug
        });
        subcatMap.set(subName, createdSub.id);
      }
    }

    // 4. Seed Brands
    const brandNames = [
      'Elysian Atelier', 'UrbanAura', 'EthnicBloom', 'VogueCraft', 'SilkAndLace',
      'VoltSpeed', 'MagShield', 'PowerPulse', 'CellArmor', 'ApexCharge',
      'GlowBotanica', 'AromaVelvet', 'HimalayanPure', 'DermaGlow', 'PureBotanics',
      'AeroSound', 'NovaTech', 'PixelCraft', 'LumixView', 'HyperTech',
      'ChefMaster', 'Stonewell', 'NutriHarvest', 'HomeEase', 'KitchenCraft',
      'IronFlex', 'UrbanWalk', 'ChronoMax', 'RuggedTrail', 'StitchCraft'
    ];

    const brandMap = new Map();
    for (const bName of brandNames) {
      const bSlug = bName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      const createdBrand = await Brand.create({
        id: `brd-${bSlug}`,
        name: bName,
        slug: bSlug,
        description: `Official ${bName} merchandise.`
      });
      brandMap.set(bName, createdBrand.id);
    }

    // 5. Generate Exactly 100 Products (SE001 to SE100)
    const categoriesConfig = [
      { name: "Women's Fashion", code: 'FAS', sub: 'Sarees', count: 25, start: 1 },
      { name: 'Mobile Accessories', code: 'MOB', sub: 'Fast Chargers', count: 20, start: 26 },
      { name: 'Beauty & Skincare', code: 'BEA', sub: 'Skincare', count: 20, start: 46 },
      { name: 'Electronics', code: 'ELE', sub: 'Audio & Headphones', count: 15, start: 66 },
      { name: 'Home & Kitchen', code: 'HOM', sub: 'Storage & Organizers', count: 10, start: 81 },
      { name: "Men's Fashion", code: 'FAS', sub: 'Women\'s Wear', count: 10, start: 91 },
    ];

    const sampleImages = {
      "Women's Fashion": [
        'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80'
      ],
      'Mobile Accessories': [
        'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1601524909162-ae872629040c?auto=format&fit=crop&w=800&q=80'
      ],
      'Beauty & Skincare': [
        'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80'
      ],
      'Electronics': [
        'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=800&q=80'
      ],
      'Home & Kitchen': [
        'https://images.unsplash.com/photo-1585515320310-259814833e62?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1615874959474-d6099696fc51?auto=format&fit=crop&w=800&q=80'
      ],
      "Men's Fashion": [
        'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80'
      ]
    };

    const brandsMap = {
      "Women's Fashion": ['Elysian Atelier', 'UrbanAura', 'EthnicBloom', 'VogueCraft', 'SilkAndLace'],
      'Mobile Accessories': ['VoltSpeed', 'MagShield', 'PowerPulse', 'CellArmor', 'ApexCharge'],
      'Beauty & Skincare': ['GlowBotanica', 'AromaVelvet', 'HimalayanPure', 'DermaGlow', 'PureBotanics'],
      'Electronics': ['AeroSound', 'NovaTech', 'PixelCraft', 'LumixView', 'HyperTech'],
      'Home & Kitchen': ['ChefMaster', 'Stonewell', 'NutriHarvest', 'HomeEase', 'KitchenCraft'],
      "Men's Fashion": ['IronFlex', 'UrbanWalk', 'ChronoMax', 'RuggedTrail', 'StitchCraft']
    };

    let currentIdNum = 1;
    for (const catConfig of categoriesConfig) {
      const imgs = sampleImages[catConfig.name];
      const catBrands = brandsMap[catConfig.name];
      const categoryId = categoryMap.get(catConfig.name) || 'cat-fas';
      const subcategoryId = subcatMap.get(catConfig.sub) || Array.from(subcatMap.values())[0];

      for (let i = 0; i < catConfig.count; i++) {
        const numStr = String(currentIdNum).padStart(3, '0');
        const productId = `SE${numStr}`;
        const sku = `SKU-${productId}-${catConfig.code}`;
        const brandName = catBrands[i % catBrands.length];
        const brandId = brandMap.get(brandName) || Array.from(brandMap.values())[0];
        const img = imgs[i % imgs.length];

        const name = `${brandName} ${catConfig.name} Item ${productId}`;
        const price = Math.floor(Math.random() * 3500) + 299;
        const originalPrice = Math.round(price * (1.2 + Math.random() * 0.5));
        const discount = Math.round(((originalPrice - price) / originalPrice) * 100);
        const rating = Number((4.1 + Math.random() * 0.8).toFixed(1));
        const reviewCount = Math.floor(Math.random() * 350) + 20;
        const stock = Math.floor(Math.random() * 75) + 10;

        const product = await Product.create({
          id: `prod-${productId.toLowerCase()}`,
          product_id: productId,
          product_name: name,
          slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''),
          category_id: categoryId,
          subcategory_id: subcategoryId,
          brand_id: brandId,
          description: `Premium quality ${name} crafted for durability, modern style, and exceptional everyday performance.`,
          short_description: `Top-rated ${catConfig.name} essential by ${brandName} with verified quality.`,
          price,
          original_price: originalPrice,
          discount,
          stock_quantity: stock,
          sku,
          specifications: { 'Brand': brandName, 'Product ID': productId, 'Warranty': '1 Year' },
          highlights: ['Verified Authenticity', 'Fast Shipping', '7-Day Return'],
          tags: [catConfig.name.toLowerCase().split(' ')[0], brandName.toLowerCase(), productId.toLowerCase()],
          rating,
          review_count: reviewCount,
          seller_id: seller.id,
          status: 'ACTIVE',
          is_featured: currentIdNum % 5 === 0,
          is_trending: currentIdNum % 7 === 0,
          is_deal: currentIdNum % 4 === 0,
          is_bestseller: currentIdNum % 6 === 0
        });

        await ProductImage.create({
          id: `img-${productId.toLowerCase()}-1`,
          product_id: product.id,
          image_url: img,
          is_primary: true
        });

        currentIdNum++;
      }
    }

    // 6. Seed Coupons
    await Coupon.create({
      coupon_code: 'SHOPNOW20',
      discount_type: 'PERCENT',
      discount_value: 20,
      minimum_order: 499,
      maximum_discount: 1000,
      expiry_date: new Date(Date.now() + 86400000 * 30),
      description: 'Get 20% off on all orders above ₹499',
      status: 'ACTIVE'
    });

    console.log('[Seeder] Database seeded successfully with exactly 100 products (SE001 to SE100)!');
  } catch (error) {
    console.error('[Seeder Error] Failed to seed database:', error);
    throw error;
  }
}
