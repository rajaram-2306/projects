import { env } from '../config/env.js';

export function errorHandler(err, req, res, next) {
  err.statusCode = err.statusCode || 500;
  err.status = err.status || 'error';

  // Format Sequelize Unique Constraint Errors
  if (err.name === 'SequelizeUniqueConstraintError') {
    const field = err.errors?.[0]?.path || 'Field';
    err.statusCode = 400;
    err.message = `${field} already exists. Please use a unique value.`;
  }

  // Format Sequelize Validation Errors
  if (err.name === 'SequelizeValidationError') {
    const messages = err.errors?.map((e) => e.message).join(', ');
    err.statusCode = 400;
    err.message = `Validation Error: ${messages}`;
  }

  // Format JWT Errors
  if (err.name === 'JsonWebTokenError') {
    err.statusCode = 401;
    err.message = 'Invalid authentication token. Please sign in again.';
  }

  if (err.name === 'TokenExpiredError') {
    err.statusCode = 401;
    err.message = 'Authentication token expired. Please sign in again.';
  }

  if (env.NODE_ENV === 'development') {
    return res.status(err.statusCode).json({
      status: err.status,
      error: err,
      message: err.message,
      stack: err.stack
    });
  }

  // Production Clean Error Output
  if (err.isOperational) {
    return res.status(err.statusCode).json({
      status: err.status,
      message: err.message
    });
  }

  // Unknown Programming or System Error
  console.error('[CRITICAL ERROR] 💥', err);
  return res.status(500).json({
    status: 'error',
    message: 'An unexpected internal server error occurred.'
  });
}
