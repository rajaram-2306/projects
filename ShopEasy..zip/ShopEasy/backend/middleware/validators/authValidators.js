import { body } from 'express-validator';
import { validateRequest } from '../validator.js';

export const validateCustomerRegistration = [
  body('name')
    .trim()
    .notEmpty().withMessage('Full name is required')
    .isLength({ min: 2, max: 100 }).withMessage('Name must be between 2 and 100 characters'),
  body('email')
    .trim()
    .notEmpty().withMessage('Email address is required')
    .isEmail().withMessage('Please provide a valid email address')
    .normalizeEmail(),
  body('phone')
    .trim()
    .notEmpty().withMessage('Phone number is required')
    .matches(/^[+]?[(]?[0-9]{1,4}[)]?[-\s./0-9]{7,15}$/).withMessage('Please provide a valid mobile phone number'),
  body('password')
    .notEmpty().withMessage('Password is required')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters long'),
  validateRequest
];

export const validateSellerRegistration = [
  body('name')
    .trim()
    .notEmpty().withMessage('Owner/Representative name is required')
    .isLength({ min: 2, max: 100 }).withMessage('Name must be between 2 and 100 characters'),
  body('email')
    .trim()
    .notEmpty().withMessage('Email address is required')
    .isEmail().withMessage('Please provide a valid personal email address')
    .normalizeEmail(),
  body('phone')
    .trim()
    .notEmpty().withMessage('Phone number is required')
    .matches(/^[+]?[(]?[0-9]{1,4}[)]?[-\s./0-9]{7,15}$/).withMessage('Please provide a valid mobile number'),
  body('password')
    .notEmpty().withMessage('Password is required')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters long'),
  body('business_name')
    .trim()
    .notEmpty().withMessage('Business or store name is required')
    .isLength({ min: 3, max: 150 }).withMessage('Business name must be between 3 and 150 characters'),
  body('business_email')
    .optional({ checkFalsy: true })
    .isEmail().withMessage('Please provide a valid business email address'),
  body('business_phone')
    .optional({ checkFalsy: true })
    .matches(/^[+]?[(]?[0-9]{1,4}[)]?[-\s./0-9]{7,15}$/).withMessage('Please provide a valid business phone number'),
  validateRequest
];

export const validateLogin = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email address is required')
    .isEmail().withMessage('Please enter a valid email address')
    .normalizeEmail(),
  body('password')
    .notEmpty().withMessage('Password is required'),
  validateRequest
];

export const validateForgotPassword = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email address is required')
    .isEmail().withMessage('Please enter a valid email address')
    .normalizeEmail(),
  validateRequest
];

export const validateResetPassword = [
  body('token')
    .notEmpty().withMessage('Password reset token is required'),
  body('new_password')
    .notEmpty().withMessage('New password is required')
    .isLength({ min: 8 }).withMessage('New password must be at least 8 characters long'),
  validateRequest
];
