import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { User, Seller } from '../models/index.js';
import { AppError } from '../utils/AppError.js';

/**
 * Protect routes: verifies JWT and attaches authenticated user
 */
export const protect = async (req, res, next) => {
  try {
    let token;

    // 1. Extract token from Authorization header
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return next(new AppError('You are not logged in. Please sign in to gain access.', 401));
    }

    // 2. Verify token
    let decoded;
    try {
      decoded = jwt.verify(token, env.JWT_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return next(new AppError('Your session has expired. Please sign in again.', 401));
      }
      return next(new AppError('Invalid authentication token. Please sign in again.', 401));
    }

    // 3. Check if user still exists in database
    const currentUser = await User.findByPk(decoded.id, {
      include: [{ model: Seller, as: 'seller', required: false }]
    });

    if (!currentUser) {
      return next(new AppError('The user belonging to this session token no longer exists.', 401));
    }

    // 4. Check if user is suspended
    if (currentUser.status === 'SUSPENDED') {
      return next(new AppError('Your account has been suspended. Please contact ShopEasy support.', 403));
    }

    // 5. Grant access: attach user to request object
    req.user = currentUser;
    next();
  } catch (err) {
    next(err);
  }
};

/**
 * Restrict access to specific roles (e.g. 'CUSTOMER', 'SELLER', 'ADMIN')
 */
export const restrictTo = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return next(
        new AppError(`Access denied. Your role '${req.user?.role || 'ANONYMOUS'}' does not have permission to perform this action.`, 403)
      );
    }
    next();
  };
};
