import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { env } from '../config/env.js';

/**
 * Sign JWT token for user authentication
 */
export const signToken = (user) => {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role
    },
    env.JWT_SECRET,
    {
      expiresIn: env.JWT_EXPIRES_IN
    }
  );
};

/**
 * Hash plaintext password using bcrypt
 */
export const hashPassword = async (password) => {
  return await bcrypt.hash(password, 12);
};

/**
 * Compare candidate password with stored hash
 */
export const comparePasswords = async (candidatePassword, userPasswordHash) => {
  return await bcrypt.compare(candidatePassword, userPasswordHash);
};

/**
 * Generate secure random reset token and hashed digest
 */
export const generateResetToken = () => {
  const resetToken = crypto.randomBytes(32).toString('hex');
  const hashedToken = crypto.createHash('sha256').update(resetToken).digest('hex');
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes validity
  return { resetToken, hashedToken, expiresAt };
};

/**
 * Hash a plain token using SHA-256
 */
export const hashToken = (token) => {
  return crypto.createHash('sha256').update(token).digest('hex');
};
