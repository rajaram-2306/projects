# ShopEasy — AI-Powered E-Commerce Platform

> **Tagline:** Everything You Need. One Easy Shop.

ShopEasy is a modern, full-stack, production-grade e-commerce ecosystem featuring a Customer Application, Seller Portal, Admin Dashboard, AI Shopping Assistant, AI Natural-Language Search, Product Recommendation & Comparison engine, WhatsApp OTP Verification, and a robust Unique Product ID System (`SHP-[CATEGORY]-[NUMBER]`).

---

## 🏗️ Architecture & Modules

- **Frontend:** React 18, TypeScript, Tailwind CSS, Lucide Icons, React Router v6, Context API.
- **Backend (Phase 2+):** Node.js, Express.js, JWT, bcrypt, modular MVC architecture.
- **Database (Phase 2+):** Relational Schema (MySQL / PostgreSQL ready) with comprehensive models for Users, Sellers, Products, Orders, Reviews, AI Recommendations, etc.
- **ShopEasy AI (Phase 10+):** Natural language search, filter extraction, product comparison, review summaries, and seller description generation grounded in real database records.
- **WhatsApp OTP (Phase 4):** Secure 6-digit WhatsApp OTP verification service with rate limiting and mock/live adapters.

---

## 📂 Project Structure

```
shopeasy/
├── frontend/             # React + TypeScript + Tailwind CSS Frontend
│   ├── src/
│   │   ├── assets/       # Icons, brand logos, badges
│   │   ├── components/   # Reusable UI & layout components
│   │   │   ├── common/   # Button, Modal, Badge, LoadingScreen, etc.
│   │   │   ├── layout/   # Header, Footer, Navbar, MobileNav
│   │   │   ├── product/  # ProductCard, ProductGrid, QuickViewModal, etc.
│   │   │   └── ai/       # AIAssistantModal, AISearchBar, etc.
│   │   ├── context/      # AuthContext, CartContext, WishlistContext, UIContext
│   │   ├── data/         # Realistic demo data (50+ products with SHP IDs)
│   │   ├── hooks/        # Custom hooks (useCart, useWishlist, useDebounce, etc.)
│   │   ├── layouts/      # RootLayout, AuthLayout, DashboardLayout
│   │   ├── pages/        # Home, Products, ProductDetails, Cart, Wishlist, Account, Login, Register, 404
│   │   ├── services/     # API services abstraction layer
│   │   ├── types/        # TypeScript interfaces and models
│   │   └── utils/        # Formatting, product ID generator, calculations
│   └── package.json
├── backend/              # Express.js REST API Backend
│   ├── config/           # Database and environment configurations
│   ├── controllers/      # API Controllers
│   ├── middleware/       # Auth, validation, rate limiting, error handlers
│   ├── models/           # Data models and entities
│   ├── routes/           # API routes
│   ├── services/         # WhatsApp OTP, AI Assistant, Email services
│   ├── utils/            # Helper utilities, ID generators
│   └── server.js         # Server entry point
├── database/
│   ├── schema/           # SQL DDL schemas
│   └── seed/             # Initial seed data
├── .env.example
├── README.md
└── package.json
```

---

## 🚀 Getting Started

### 1. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```

### 2. Available Scripts
- `npm run dev`: Starts the Vite development server on `http://localhost:5173`
- `npm run build`: Type-checks and builds the production bundle
- `npm run preview`: Previews the production build locally
