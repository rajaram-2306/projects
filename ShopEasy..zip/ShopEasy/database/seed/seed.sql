-- =====================================================================
-- SHOP EASY — Initial Data Seed SQL
-- =====================================================================

USE shopeasy_db;

-- 1. Insert Default Users (Password: ShopEasy@2026)
INSERT INTO users (id, name, email, password_hash, phone, role, whatsapp_verified, status)
VALUES 
('usr-customer-001', 'Alex Johnson', 'customer@shopeasy.com', '$2a$10$wTf7P1t5xZl61R3o.eJq3.UuKkJb90mG99jV4oXwWf1s11F.Q0zKG', '+919876543210', 'CUSTOMER', TRUE, 'ACTIVE'),
('usr-seller-001', 'Apex Retailers', 'seller@shopeasy.com', '$2a$10$wTf7P1t5xZl61R3o.eJq3.UuKkJb90mG99jV4oXwWf1s11F.Q0zKG', '+919876543211', 'SELLER', TRUE, 'ACTIVE'),
('usr-admin-001', 'ShopEasy SuperAdmin', 'admin@shopeasy.com', '$2a$10$wTf7P1t5xZl61R3o.eJq3.UuKkJb90mG99jV4oXwWf1s11F.Q0zKG', '+919876543212', 'ADMIN', TRUE, 'ACTIVE')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- 2. Insert Seller Record
INSERT INTO sellers (id, user_id, business_name, business_email, business_phone, gst_number, pan_number, store_description, rating, approval_status)
VALUES
('sel-apex-001', 'usr-seller-001', 'Apex Official Store', 'support@apexretail.com', '+919876543211', '29ABCDE1234F1Z5', 'ABCDE1234F', 'Authorized retailer of high quality audio, smartphones, and smart appliances.', 4.85, 'APPROVED')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- 3. Insert 10 Categories
INSERT INTO categories (id, name, code, slug, icon, description, status)
VALUES
('cat-ele', 'Electronics', 'ELE', 'electronics', 'Laptop', 'Laptops, Smart Audio, Cameras, TV & Smart Home tech.', 'ACTIVE'),
('cat-mob', 'Mobile & Accessories', 'MOB', 'mobile-accessories', 'Smartphone', 'Flagship Smartphones, Fast Chargers, Powerbanks & Cases.', 'ACTIVE'),
('cat-fas', 'Fashion', 'FAS', 'fashion', 'Shirt', 'Trendy Men & Women Apparel, Jackets, Formals & Casuals.', 'ACTIVE'),
('cat-bea', 'Beauty & Personal Care', 'BEA', 'beauty', 'Sparkles', 'Organic Skincare, Haircare, Fragrances & Grooming essentials.', 'ACTIVE'),
('cat-hom', 'Home & Kitchen', 'HOM', 'home-kitchen', 'Home', 'Modern Kitchenware, Smart Appliances, Cookware & Decor.', 'ACTIVE'),
('cat-gro', 'Grocery & Gourmet', 'GRO', 'grocery', 'ShoppingBag', 'Farm Fresh Organic Staples, Dry Fruits, Beverages & Snacks.', 'ACTIVE'),
('cat-bks', 'Books & Stationery', 'BKS', 'books', 'BookOpen', 'Bestsellers, Fiction, Technology, Self-Help & Stationery.', 'ACTIVE'),
('cat-spt', 'Sports & Fitness', 'SPT', 'sports', 'Trophy', 'Gym Equipment, Yoga Mats, Running Gear & Outdoor Gear.', 'ACTIVE'),
('cat-ftw', 'Footwear', 'FTW', 'footwear', 'Footprints', 'Performance Running Shoes, Sneakers, Formals & Sandals.', 'ACTIVE'),
('cat-acc', 'Accessories & Watches', 'ACC', 'accessories', 'Watch', 'Luxury Chronographs, Smartwatches, Sunglasses & Wallets.', 'ACTIVE')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- 4. Insert Coupons
INSERT INTO coupons (id, coupon_code, discount_type, discount_value, minimum_order, maximum_discount, expiry_date, description, status)
VALUES
('cpn-01', 'WELCOME10', 'PERCENT', 10.00, 500.00, 250.00, '2026-12-31', 'Get 10% OFF up to ₹250 on your first order above ₹500', 'ACTIVE'),
('cpn-02', 'SAVE20', 'PERCENT', 20.00, 1999.00, 600.00, '2026-12-31', 'Save 20% OFF up to ₹600 on premium orders over ₹1999', 'ACTIVE'),
('cpn-03', 'FIRSTORDER', 'FIXED', 150.00, 799.00, 150.00, '2026-12-31', 'Flat ₹150 instant discount for all new shoppers above ₹799', 'ACTIVE')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;
