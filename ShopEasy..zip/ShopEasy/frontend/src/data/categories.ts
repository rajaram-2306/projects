import { Category } from '../types';

export const CATEGORIES: Category[] = [
  {
    id: 'cat-ele',
    name: 'Electronics',
    code: 'ELE',
    slug: 'electronics',
    icon: 'Laptop',
    image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&w=600&q=80',
    itemCount: 142,
    description: 'Laptops, Smart Audio, Cameras, TV & Smart Home tech.',
    subcategories: ['Laptops', 'Audio & Headphones', 'Cameras', 'Smart Home', 'Televisions', 'Computer Peripherals']
  },
  {
    id: 'cat-mob',
    name: 'Mobile & Accessories',
    code: 'MOB',
    slug: 'mobile-accessories',
    icon: 'Smartphone',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80',
    itemCount: 198,
    description: 'Flagship Smartphones, Fast Chargers, Powerbanks & Cases.',
    subcategories: ['Smartphones', 'Tablets', 'Fast Chargers', 'Power Banks', 'Cases & Covers', 'Screen Protectors']
  },
  {
    id: 'cat-fas',
    name: 'Fashion',
    code: 'FAS',
    slug: 'fashion',
    icon: 'Shirt',
    image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&w=600&q=80',
    itemCount: 320,
    description: 'Trendy Men & Women Apparel, Jackets, Formals & Casuals.',
    subcategories: ["Men's Wear", "Women's Wear", 'Ethnic Wear', 'Winterwear', 'Innerwear', 'Activewear']
  },
  {
    id: 'cat-bea',
    name: 'Beauty & Personal Care',
    code: 'BEA',
    slug: 'beauty',
    icon: 'Sparkles',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80',
    itemCount: 110,
    description: 'Organic Skincare, Haircare, Fragrances & Grooming essentials.',
    subcategories: ['Skincare', 'Haircare', 'Fragrances', 'Makeup', "Men's Grooming", 'Oral Care']
  },
  {
    id: 'cat-hom',
    name: 'Home & Kitchen',
    code: 'HOM',
    slug: 'home-kitchen',
    icon: 'Home',
    image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&q=80',
    itemCount: 165,
    description: 'Modern Kitchenware, Smart Appliances, Cookware & Decor.',
    subcategories: ['Cookware', 'Kitchen Appliances', 'Home Decor', 'Storage & Organization', 'Dining', 'Bedding']
  },
  {
    id: 'cat-gro',
    name: 'Grocery & Gourmet',
    code: 'GRO',
    slug: 'grocery',
    icon: 'ShoppingBag',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
    itemCount: 250,
    description: 'Farm Fresh Organic Staples, Dry Fruits, Beverages & Snacks.',
    subcategories: ['Staples & Grains', 'Dry Fruits & Nuts', 'Tea & Coffee', 'Healthy Snacks', 'Cooking Oils', 'Organic Superfoods']
  },
  {
    id: 'cat-bks',
    name: 'Books & Stationery',
    code: 'BKS',
    slug: 'books',
    icon: 'BookOpen',
    image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80',
    itemCount: 88,
    description: 'Bestsellers, Fiction, Technology, Self-Help & Stationery.',
    subcategories: ['Fiction', 'Non-Fiction & Self-Help', 'Tech & Coding', 'Exam Prep', 'Stationery & Pens', 'Notebooks']
  },
  {
    id: 'cat-spt',
    name: 'Sports & Fitness',
    code: 'SPT',
    slug: 'sports',
    icon: 'Trophy',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80',
    itemCount: 95,
    description: 'Gym Equipment, Yoga Mats, Running Gear & Outdoor Gear.',
    subcategories: ['Fitness Equipment', 'Yoga & Pilates', 'Outdoor & Camping', 'Cricket & Football', 'Sportswear', 'Hydration & Bottles']
  },
  {
    id: 'cat-ftw',
    name: 'Footwear',
    code: 'FTW',
    slug: 'footwear',
    icon: 'Footprints',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80',
    itemCount: 130,
    description: 'Performance Running Shoes, Sneakers, Formals & Sandals.',
    subcategories: ['Running Shoes', 'Casual Sneakers', 'Formal Shoes', 'Sandals & Slides', 'Boots', 'Orthopedic Footwear']
  },
  {
    id: 'cat-acc',
    name: 'Accessories & Watches',
    code: 'ACC',
    slug: 'accessories',
    icon: 'Watch',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
    itemCount: 115,
    description: 'Luxury Chronographs, Smartwatches, Sunglasses & Wallets.',
    subcategories: ['Smartwatches', 'Luxury Watches', 'Sunglasses', 'Leather Wallets', 'Backpacks & Bags', 'Belts']
  }
];

export const CATEGORY_MAP = new Map(CATEGORIES.map(c => [c.code, c]));
