import { Coupon } from '../types';

export const COUPONS: Coupon[] = [
  {
    coupon_code: 'WELCOME10',
    discount_type: 'PERCENT',
    discount_value: 10,
    minimum_order: 500,
    maximum_discount: 250,
    expiry_date: '2026-12-31',
    description: 'Get 10% OFF up to ₹250 on your first order above ₹500',
    status: 'ACTIVE'
  },
  {
    coupon_code: 'SAVE20',
    discount_type: 'PERCENT',
    discount_value: 20,
    minimum_order: 1999,
    maximum_discount: 600,
    expiry_date: '2026-12-31',
    description: 'Save 20% OFF up to ₹600 on premium orders over ₹1999',
    status: 'ACTIVE'
  },
  {
    coupon_code: 'FIRSTORDER',
    discount_type: 'FIXED',
    discount_value: 150,
    minimum_order: 799,
    maximum_discount: 150,
    expiry_date: '2026-12-31',
    description: 'Flat ₹150 instant discount for all new shoppers above ₹799',
    status: 'ACTIVE'
  },
  {
    coupon_code: 'FESTIVE500',
    discount_type: 'FIXED',
    discount_value: 500,
    minimum_order: 3999,
    maximum_discount: 500,
    expiry_date: '2026-12-31',
    description: 'Mega festive flat ₹500 OFF on orders above ₹3999',
    status: 'ACTIVE'
  }
];
