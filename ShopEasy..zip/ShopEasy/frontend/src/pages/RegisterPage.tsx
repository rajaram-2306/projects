import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';
import {
  ShoppingBag,
  Sparkles,
  Lock,
  Mail,
  User,
  Phone,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Store,
  KeyRound
} from 'lucide-react';

export const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialRole = searchParams.get('type') === 'seller' ? 'SELLER' : 'CUSTOMER';

  const { register } = useAuth();
  const { addToast } = useUI();

  const [role, setRole] = useState<'CUSTOMER' | 'SELLER'>(initialRole);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [businessName, setBusinessName] = useState('');

  // WhatsApp OTP verification step
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const [isOtpVerified, setIsOtpVerified] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  const handleSendOtp = () => {
    if (!phone || phone.length < 10) {
      addToast('Invalid Mobile Number', 'Please enter a valid 10-digit mobile number for WhatsApp verification', 'error');
      return;
    }

    setOtpSent(true);
    setResendCooldown(60);
    addToast('WhatsApp OTP Dispatched!', 'Demo verification code: 123456 sent to your WhatsApp', 'success', 6000);

    const timer = setInterval(() => {
      setResendCooldown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleVerifyOtp = () => {
    if (otp === '123456' || otp.length === 6) {
      setIsOtpVerified(true);
      addToast('WhatsApp Number Verified!', 'Phone number successfully authenticated', 'success');
    } else {
      addToast('Invalid OTP', 'Please enter 123456 for mock verification', 'error');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOtpVerified) {
      addToast('Verification Required', 'Please verify your WhatsApp mobile number before continuing', 'warning');
      return;
    }

    register({
      name,
      email,
      phone,
      role,
      whatsapp_verified: true,
      seller_business_name: role === 'SELLER' ? businessName : undefined
    });

    addToast('Account Created!', `Welcome to ShopEasy as a verified ${role.toLowerCase()}`, 'success');
    navigate('/');
  };

  return (
    <div className="min-h-[90vh] flex items-center justify-center py-12 px-4 sm:px-6">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-xl border border-slate-100 p-8 space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-brand-600 via-indigo-600 to-accent-500 p-[1.5px] shadow-glow flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
            </div>
            <span className="text-2xl font-black font-display text-slate-900">
              SHOP<span className="text-brand-600">EASY</span>
            </span>
          </Link>
          <h2 className="text-xl font-bold font-display text-slate-900 pt-2">
            Create Your Verified Account
          </h2>
          <p className="text-xs text-slate-500">
            Secure registration with instant 6-digit WhatsApp OTP verification.
          </p>
        </div>

        {/* Customer vs Seller Tabs */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl">
          <button
            type="button"
            onClick={() => setRole('CUSTOMER')}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              role === 'CUSTOMER' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            <User className="w-3.5 h-3.5" /> Customer Account
          </button>
          <button
            type="button"
            onClick={() => setRole('SELLER')}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              role === 'SELLER' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            <Store className="w-3.5 h-3.5" /> Seller Partner
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Full Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Alex Johnson"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white"
              />
            </div>
          </div>

          {role === 'SELLER' && (
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Business / Store Name
              </label>
              <div className="relative">
                <Store className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  required
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder="e.g. Apex Electronics Hub"
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="alex.johnson@example.com"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white"
              />
            </div>
          </div>

          {/* WhatsApp Mobile Number & OTP Verification Module */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>WhatsApp Mobile Number</span>
              </label>
              {isOtpVerified && (
                <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> WhatsApp Verified
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <input
                type="tel"
                required
                disabled={isOtpVerified}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="flex-1 px-3 py-2.5 bg-white border border-emerald-200 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 disabled:bg-emerald-100/50"
              />
              {!isOtpVerified && (
                <button
                  type="button"
                  onClick={handleSendOtp}
                  disabled={resendCooldown > 0}
                  className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shrink-0 transition-colors"
                >
                  {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : otpSent ? 'Resend OTP' : 'Send WhatsApp OTP'}
                </button>
              )}
            </div>

            {otpSent && !isOtpVerified && (
              <div className="flex gap-2 pt-2 border-t border-emerald-200 animate-slide-up">
                <div className="relative flex-1">
                  <KeyRound className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    maxLength={6}
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="Enter 6-digit OTP (123456)"
                    className="w-full pl-8 pr-3 py-2 bg-white border border-emerald-200 rounded-xl text-xs font-mono font-bold tracking-widest text-slate-900 focus:outline-none"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleVerifyOtp}
                  className="px-4 py-2 bg-slate-900 text-white font-bold rounded-xl text-xs hover:bg-slate-800"
                >
                  Verify OTP
                </button>
              </div>
            )}
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Set Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 8 characters"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-glow flex items-center justify-center gap-2 transition-all"
          >
            <span>Complete Registration</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <p className="text-center text-xs text-slate-500">
          Already have an account?{' '}
          <Link to="/login" className="font-bold text-brand-600 hover:underline">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};
