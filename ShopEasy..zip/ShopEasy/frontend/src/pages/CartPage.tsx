import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';
import { formatPrice } from '../utils';
import { ProductIdBadge } from '../components/common/ProductIdBadge';
import { EmptyState } from '../components/common/EmptyState';
import {
  Trash2,
  Heart,
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
  Tag,
  CheckCircle2,
  X,
  CreditCard,
  Truck,
  Sparkles,
  Lock
} from 'lucide-react';

export const CartPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    cart,
    removeFromCart,
    updateQuantity,
    clearCart,
    appliedCoupon,
    couponError,
    applyCoupon,
    removeCoupon,
    subtotal,
    discountAmount,
    shippingFee,
    taxAmount,
    totalAmount,
    totalItemsCount
  } = useCart();

  const { toggleWishlist } = useWishlist();
  const { user } = useAuth();
  const { addToast } = useUI();

  const [couponInput, setCouponInput] = useState('');
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<'UPI' | 'CARD' | 'NET_BANKING' | 'COD'>('UPI');
  const [isOrderPlaced, setIsOrderPlaced] = useState(false);
  const [placedOrderId, setPlacedOrderId] = useState('');

  // Shipping progress towards free shipping threshold (₹499)
  const freeShippingThreshold = 499;
  const progressPercent = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const success = applyCoupon(couponInput);
    if (success) {
      addToast('Coupon Applied!', `Saved with ${couponInput.toUpperCase()}`, 'success');
      setCouponInput('');
    }
  };

  const handleSaveForLater = (product: any) => {
    removeFromCart(product.id);
    toggleWishlist(product);
    addToast('Saved for Later', `${product.product_name} moved to wishlist`, 'info');
  };

  const handlePlaceOrder = () => {
    const orderId = `ORD-2026-${Math.floor(100000 + Math.random() * 900000)}`;
    setPlacedOrderId(orderId);
    setIsOrderPlaced(true);
    clearCart();
    addToast('Order Placed Successfully!', `Your order ID is ${orderId}`, 'success', 5000);
  };

  if (isOrderPlaced) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-6 animate-fade-in">
        <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-black text-slate-900 font-display">
          Thank You for Your Order!
        </h1>
        <p className="text-sm text-slate-600">
          Your order has been placed successfully and is being prepared for dispatch.
        </p>

        <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 text-left space-y-3">
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Order ID:</span>
            <span className="font-mono font-bold text-brand-600">{placedOrderId}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Payment Status:</span>
            <span className="font-semibold text-emerald-600">Paid ({selectedPayment})</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">WhatsApp Notification:</span>
            <span className="font-semibold text-slate-800">Sent to {user?.phone || '+91 98765 43210'}</span>
          </div>
        </div>

        <div className="flex justify-center gap-4 pt-4">
          <Link
            to="/account?tab=orders"
            className="px-6 py-3 bg-brand-600 text-white font-bold rounded-xl text-xs shadow-md hover:bg-brand-500 transition-colors"
          >
            Track Order Status
          </Link>
          <Link
            to="/products"
            className="px-6 py-3 bg-slate-900 text-white font-bold rounded-xl text-xs hover:bg-slate-800 transition-colors"
          >
            Continue Shopping
          </Link>
        </div>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <EmptyState
          icon={<ShoppingBag className="w-12 h-12 stroke-[1.5]" />}
          title="Your Shopping Cart is Empty"
          description="Looks like you haven't added anything to your cart yet. Explore our top-rated collections and deals to start shopping!"
          actionText="Explore Products"
          actionHref="/products"
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mb-2">
        Shopping Cart ({totalItemsCount} items)
      </h1>
      <p className="text-xs text-slate-500 mb-8">
        Review your items, apply promotional discount coupons, and proceed to secure checkout.
      </p>

      {/* Free Delivery Bar */}
      <div className="p-4 bg-brand-50 rounded-2xl border border-brand-100 mb-8">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="font-bold text-brand-900 flex items-center gap-1.5">
            <Truck className="w-4 h-4 text-brand-600" />
            {subtotal >= freeShippingThreshold
              ? '🎉 Congratulations! You have unlocked FREE Express Delivery'
              : `Add ${formatPrice(freeShippingThreshold - subtotal)} more for FREE Delivery`}
          </span>
          <span className="font-bold text-brand-700">{Math.round(progressPercent)}%</span>
        </div>
        <div className="w-full h-2 bg-brand-200/60 rounded-full overflow-hidden">
          <div
            className="h-full bg-brand-600 rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Cart Items List */}
        <div className="lg:col-span-8 space-y-4">
          {cart.map((item) => (
            <div
              key={item.id}
              className="p-4 sm:p-5 bg-white rounded-3xl border border-slate-100 shadow-sm flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6"
            >
              {/* Product Thumbnail */}
              <Link to={`/products/${item.product.product_id}`} className="shrink-0">
                <img
                  src={item.product.images[0]}
                  alt={item.product.product_name}
                  className="w-24 h-24 object-cover rounded-2xl border border-slate-100"
                />
              </Link>

              {/* Product Info */}
              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-brand-600 uppercase tracking-wider">
                    {item.product.brand}
                  </span>
                  <ProductIdBadge productId={item.product.product_id} size="sm" />
                </div>
                <Link
                  to={`/products/${item.product.product_id}`}
                  className="text-sm font-bold text-slate-900 hover:text-brand-600 transition-colors line-clamp-1 font-display"
                >
                  {item.product.product_name}
                </Link>
                <p className="text-xs text-slate-500">SKU: {item.product.sku}</p>

                <div className="flex items-center gap-4 pt-1">
                  <span className="text-base font-black text-slate-900">
                    {formatPrice(item.product.price)}
                  </span>
                  {item.product.original_price > item.product.price && (
                    <span className="text-xs text-slate-400 line-through">
                      {formatPrice(item.product.original_price)}
                    </span>
                  )}
                  <span className="text-xs text-emerald-600 font-semibold">In Stock</span>
                </div>
              </div>

              {/* Quantity Stepper & Actions */}
              <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-4">
                <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
                  <button
                    onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                    className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 font-bold text-xs"
                  >
                    -
                  </button>
                  <span className="px-3 py-1.5 text-xs font-bold text-slate-900">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                    className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 font-bold text-xs"
                  >
                    +
                  </button>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleSaveForLater(item.product)}
                    className="text-xs text-slate-500 hover:text-brand-600 font-medium flex items-center gap-1 transition-colors"
                    title="Move to Wishlist"
                  >
                    <Heart className="w-3.5 h-3.5" /> Save
                  </button>
                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="text-xs text-rose-500 hover:text-rose-700 font-medium flex items-center gap-1 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary Card */}
        <div className="lg:col-span-4 space-y-6">
          <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-6 sticky top-24">
            <h3 className="text-base font-bold text-slate-900 font-display border-b border-slate-100 pb-4">
              Order Summary
            </h3>

            {/* Coupon input */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Have a Promo Coupon?
              </label>
              {appliedCoupon ? (
                <div className="flex items-center justify-between p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs">
                  <div className="flex items-center gap-2 text-emerald-800 font-bold">
                    <Tag className="w-4 h-4" />
                    <span>{appliedCoupon.coupon_code} applied</span>
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="text-xs text-rose-600 hover:text-rose-800 font-semibold"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="WELCOME10, SAVE20"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs uppercase focus:outline-none focus:ring-1 focus:ring-brand-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800"
                  >
                    Apply
                  </button>
                </form>
              )}
              {couponError && (
                <p className="text-[11px] text-rose-600 mt-1.5">{couponError}</p>
              )}
            </div>

            {/* Price Calculations Breakdown */}
            <div className="space-y-2.5 text-xs text-slate-600 border-t border-slate-100 pt-4">
              <div className="flex justify-between">
                <span>Subtotal ({totalItemsCount} items)</span>
                <span className="font-semibold text-slate-900">{formatPrice(subtotal)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-600 font-semibold">
                  <span>Coupon Discount</span>
                  <span>- {formatPrice(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Estimated Shipping</span>
                <span className="font-semibold text-slate-900">
                  {shippingFee === 0 ? <span className="text-emerald-600">FREE</span> : formatPrice(shippingFee)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Estimated GST Tax (5% Incl.)</span>
                <span className="font-semibold text-slate-900">{formatPrice(taxAmount)}</span>
              </div>
              <div className="flex justify-between text-base font-black text-slate-900 border-t border-slate-100 pt-3">
                <span>Total Amount</span>
                <span className="text-brand-600 font-display text-lg">{formatPrice(totalAmount)}</span>
              </div>
            </div>

            {/* Checkout CTA */}
            <button
              onClick={() => setIsCheckoutModalOpen(true)}
              className="w-full py-4 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-glow flex items-center justify-center gap-2 transition-all"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400">
              <Lock className="w-3.5 h-3.5 text-emerald-500" />
              <span>Safe & Secure 256-Bit SSL Checkout</span>
            </div>
          </div>
        </div>
      </div>

      {/* Checkout Modal Mockup */}
      {isCheckoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-slate-100 p-6 space-y-6 max-h-[90vh] overflow-y-auto animate-slide-up">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Complete Your Order
              </h3>
              <button
                onClick={() => setIsCheckoutModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Delivery Address Review */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">Delivery Address:</span>
                <span className="text-[10px] text-emerald-600 font-semibold">Default (Home)</span>
              </div>
              <p className="text-slate-700 font-semibold">{user?.name || 'Alex Johnson'}</p>
              <p className="text-slate-500">402, High Street Towers, Indiranagar</p>
              <p className="text-slate-500">Bengaluru, Karnataka - 560038</p>
              <p className="text-slate-500 font-mono">Mobile: {user?.phone || '+91 98765 43210'}</p>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                Select Mock Payment Method
              </label>
              <div className="grid grid-cols-2 gap-3 text-xs">
                {[
                  { id: 'UPI', label: 'UPI (GPay / PhonePe)', icon: '⚡' },
                  { id: 'CARD', label: 'Credit / Debit Card', icon: '💳' },
                  { id: 'NET_BANKING', label: 'Net Banking', icon: '🏦' },
                  { id: 'COD', label: 'Cash on Delivery', icon: '💵' }
                ].map((method) => (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => setSelectedPayment(method.id as any)}
                    className={`p-3 rounded-2xl border text-left flex items-center gap-2.5 transition-all ${
                      selectedPayment === method.id
                        ? 'border-brand-600 bg-brand-50 text-brand-900 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="text-base">{method.icon}</span>
                    <span>{method.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Order Total & Confirm */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500">Payable Amount:</span>
                <span className="block text-xl font-black text-slate-900 font-display">
                  {formatPrice(totalAmount)}
                </span>
              </div>
              <button
                onClick={handlePlaceOrder}
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-md transition-all"
              >
                Confirm & Pay ({formatPrice(totalAmount)})
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
