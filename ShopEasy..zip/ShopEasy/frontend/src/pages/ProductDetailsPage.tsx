import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { PRODUCTS, DEMO_REVIEWS } from '../data/products';
import { ProductCard } from '../components/product/ProductCard';
import { RatingStars } from '../components/common/RatingStars';
import { ProductIdBadge } from '../components/common/ProductIdBadge';
import { Badge } from '../components/common/Badge';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useUI } from '../context/UIContext';
import { formatPrice } from '../utils';
import {
  ShoppingBag,
  Zap,
  Heart,
  Scale,
  Truck,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  Check,
  ArrowRight,
  Share2,
  MapPin,
  Bot,
  ThumbsUp,
  Award
} from 'lucide-react';

export const ProductDetailsPage: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const navigate = useNavigate();

  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { addToCompare, compareList, openAIAssistant, addToast } = useUI();

  // Find product by either product_id (e.g. SHP-ELE-000001) or internal id
  const product = PRODUCTS.find(
    (p) => p.product_id.toLowerCase() === productId?.toLowerCase() || p.id === productId
  );

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [pinCode, setPinCode] = useState('');
  const [deliveryStatus, setDeliveryStatus] = useState<string | null>(null);

  if (!product) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-slate-900 mb-2 font-display">Product Not Found</h2>
        <p className="text-slate-500 text-sm mb-6">
          We couldn't find a product with ID: <code className="font-mono text-brand-600">{productId}</code>
        </p>
        <Link
          to="/products"
          className="inline-flex items-center gap-2 px-6 py-3 bg-brand-600 text-white font-bold rounded-xl text-xs shadow-md"
        >
          Browse Product Catalog
        </Link>
      </div>
    );
  }

  const isWishlisted = isInWishlist(product.id);
  const isCompared = compareList.some((p) => p.id === product.id);
  const reviews = DEMO_REVIEWS[product.product_id] || DEMO_REVIEWS['SE001'] || [];

  // Similar products in same category
  const similarProducts = PRODUCTS.filter(
    (p) => p.category_code === product.category_code && p.id !== product.id
  ).slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    addToast('Added to Cart', `${quantity}x ${product.product_name} added to cart`, 'success');
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    navigate('/cart');
  };

  const handleCheckDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinCode.length >= 5) {
      setDeliveryStatus(`Express Delivery available to ${pinCode} by Tomorrow, 5:00 PM!`);
    } else {
      setDeliveryStatus('Please enter a valid 6-digit PIN code.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-12">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-xs text-slate-500 flex-wrap">
        <Link to="/" className="hover:text-brand-600 transition-colors">Home</Link>
        <span>/</span>
        <Link to="/products" className="hover:text-brand-600 transition-colors">Products</Link>
        <span>/</span>
        <Link to={`/products?category=${product.category_code}`} className="hover:text-brand-600 transition-colors">
          {product.category_name}
        </Link>
        <span>/</span>
        <span className="text-slate-900 font-semibold truncate max-w-xs">{product.product_name}</span>
      </nav>

      {/* Main Product Showcase Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-start">
        {/* Left Column: Image Gallery */}
        <div className="lg:col-span-6 space-y-4">
          <div className="aspect-square w-full rounded-3xl overflow-hidden bg-white border border-slate-100 shadow-sm relative group">
            <img
              src={product.images[selectedImageIndex] || product.images[0]}
              alt={product.product_name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            {product.discount > 0 && (
              <div className="absolute top-4 left-4">
                <Badge variant="discount" discountPercent={product.discount} />
              </div>
            )}
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-20 h-20 rounded-2xl overflow-hidden border-2 transition-all shrink-0 ${
                    selectedImageIndex === idx
                      ? 'border-brand-600 shadow-sm scale-105'
                      : 'border-slate-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Details & Actions */}
        <div className="lg:col-span-6 space-y-6">
          {/* Brand, Category & Product ID Header */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-brand-600 uppercase tracking-wider">
                  {product.brand}
                </span>
                <span className="text-slate-300">•</span>
                <span className="text-xs text-slate-500">{product.category_name}</span>
              </div>
              <ProductIdBadge productId={product.product_id} size="md" />
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display leading-snug">
              {product.product_name}
            </h1>

            {/* Ratings & Seller Verified Bar */}
            <div className="flex items-center gap-4 text-xs pt-1">
              <RatingStars rating={product.rating} reviewCount={product.review_count} showCount size="sm" />
              <span className="text-slate-300">•</span>
              <span className="text-emerald-600 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600" /> Verified Authentic Seller ({product.seller_name})
              </span>
            </div>
          </div>

          {/* Pricing Box */}
          <div className="p-5 bg-slate-50/80 rounded-3xl border border-slate-200/80">
            <div className="flex items-baseline gap-3">
              <span className="text-3xl sm:text-4xl font-black text-slate-900 font-display">
                {formatPrice(product.price)}
              </span>
              {product.original_price > product.price && (
                <span className="text-base text-slate-400 line-through">
                  {formatPrice(product.original_price)}
                </span>
              )}
              {product.discount > 0 && (
                <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold">
                  Save {formatPrice(product.original_price - product.price)} ({product.discount}% OFF)
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Inclusive of all taxes. Free 1-Day delivery on this order.
            </p>
          </div>

          {/* Stock Availability */}
          <div>
            {product.stock_quantity <= 5 ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                ⚠️ Hurry! Only {product.stock_quantity} items remaining in stock
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> In Stock ({product.stock_quantity} units available)
              </span>
            )}
          </div>

          {/* Highlights checklist */}
          {product.highlights && product.highlights.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Product Highlights
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {product.highlights.map((item, index) => (
                  <div key={index} className="flex items-start gap-2 text-xs text-slate-700">
                    <Check className="w-4 h-4 text-brand-600 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quantity & CTA Buttons */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3">
              {/* Quantity Stepper */}
              <div className="flex items-center border border-slate-300 rounded-2xl overflow-hidden bg-white shadow-sm">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-4 py-3 text-slate-600 hover:bg-slate-100 font-bold"
                >
                  -
                </button>
                <span className="px-4 py-3 text-sm font-bold text-slate-900">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => Math.min(product.stock_quantity, q + 1))}
                  className="px-4 py-3 text-slate-600 hover:bg-slate-100 font-bold"
                >
                  +
                </button>
              </div>

              {/* Add to Cart */}
              <button
                onClick={handleAddToCart}
                className="flex-1 py-3.5 px-6 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <ShoppingBag className="w-4 h-4" /> Add to Cart
              </button>

              {/* Buy Now */}
              <button
                onClick={handleBuyNow}
                className="flex-1 py-3.5 px-6 rounded-2xl bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs sm:text-sm shadow-glow flex items-center justify-center gap-2 transition-all"
              >
                <Zap className="w-4 h-4" /> Buy Now
              </button>
            </div>

            {/* Auxiliary actions: Wishlist & Compare */}
            <div className="flex items-center gap-3 pt-1">
              <button
                onClick={() => {
                  toggleWishlist(product);
                  if (!isWishlisted) addToast('Saved to Wishlist', `${product.product_name} saved`, 'info');
                }}
                className={`flex-1 py-2.5 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                  isWishlisted ? 'bg-rose-50 border-rose-200 text-rose-600' : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                <span>{isWishlisted ? 'In Wishlist' : 'Add to Wishlist'}</span>
              </button>

              <button
                onClick={() => addToCompare(product)}
                className={`flex-1 py-2.5 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                  isCompared ? 'bg-brand-50 border-brand-200 text-brand-700' : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Scale className="w-4 h-4" />
                <span>{isCompared ? 'In Compare Dock' : 'Compare Product'}</span>
              </button>
            </div>
          </div>

          {/* Delivery PIN Code Checker */}
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
              <MapPin className="w-4 h-4 text-brand-600" />
              <span>Delivery & Availability Check</span>
            </div>
            <form onSubmit={handleCheckDelivery} className="flex gap-2">
              <input
                type="text"
                placeholder="Enter 6-digit PIN code"
                maxLength={6}
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-brand-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800"
              >
                Check
              </button>
            </form>
            {deliveryStatus && (
              <p className="text-xs text-emerald-600 font-semibold animate-fade-in">{deliveryStatus}</p>
            )}
          </div>
        </div>
      </div>

      {/* Specifications & AI Review Insights Tabs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-8 border-t border-slate-200">
        {/* Specifications & Description */}
        <div className="lg:col-span-7 space-y-8">
          <div>
            <h3 className="text-lg font-bold text-slate-900 font-display mb-4">
              Technical Specifications
            </h3>
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
              <table className="w-full text-xs text-left">
                <tbody className="divide-y divide-slate-100">
                  <tr className="bg-slate-50/60">
                    <td className="p-3.5 font-bold text-slate-600 w-1/3">ShopEasy Product ID</td>
                    <td className="p-3.5 font-mono font-bold text-brand-600">{product.product_id}</td>
                  </tr>
                  <tr>
                    <td className="p-3.5 font-bold text-slate-600">Brand</td>
                    <td className="p-3.5 text-slate-800 font-semibold">{product.brand}</td>
                  </tr>
                  <tr className="bg-slate-50/60">
                    <td className="p-3.5 font-bold text-slate-600">SKU Code</td>
                    <td className="p-3.5 font-mono text-slate-700">{product.sku}</td>
                  </tr>
                  {Object.entries(product.specifications || {}).map(([key, value], idx) => (
                    <tr key={key} className={idx % 2 === 0 ? '' : 'bg-slate-50/60'}>
                      <td className="p-3.5 font-bold text-slate-600">{key}</td>
                      <td className="p-3.5 text-slate-800">{value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold text-slate-900 font-display mb-3">
              Product Overview & Description
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed bg-white p-6 rounded-2xl border border-slate-100">
              {product.description}
            </p>
          </div>
        </div>

        {/* AI Review Summary & Customer Reviews */}
        <div className="lg:col-span-5 space-y-6">
          {/* AI Review Summary Card */}
          <div className="bg-gradient-to-br from-brand-900 to-slate-900 text-white p-6 rounded-3xl border border-brand-800 shadow-md space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-accent-400" />
                <h4 className="text-sm font-bold font-display">AI Customer Review Summary</h4>
              </div>
              <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded-full font-mono text-accent-300">
                AI Grounded
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Based on {product.review_count} verified purchase reviews, customers praise this product for exceptional durability, ease of use, and build quality.
            </p>

            <div className="space-y-2 pt-2 border-t border-white/10 text-xs">
              <div className="flex items-center gap-2 text-emerald-300">
                <Check className="w-3.5 h-3.5 shrink-0" />
                <span>Common positive: High performance & premium materials</span>
              </div>
              <div className="flex items-center gap-2 text-emerald-300">
                <Check className="w-3.5 h-3.5 shrink-0" />
                <span>Common positive: Great value for price ratio</span>
              </div>
            </div>
          </div>

          {/* Verified Customer Reviews List */}
          <div className="space-y-4">
            <h3 className="text-base font-bold text-slate-900 font-display">
              Customer Reviews ({reviews.length})
            </h3>

            {reviews.length > 0 ? (
              <div className="space-y-3">
                {reviews.map((rev: any) => (
                  <div key={rev.id} className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900">{rev.user_name}</span>
                      <span className="text-[10px] text-slate-400">{rev.created_at}</span>
                    </div>
                    <RatingStars rating={rev.rating} size="xs" />
                    <h5 className="text-xs font-bold text-slate-800">{rev.title}</h5>
                    <p className="text-xs text-slate-600 leading-relaxed">{rev.comment}</p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-slate-50">
                      <span className="text-emerald-600 font-medium">✓ Verified Purchase</span>
                      <span className="flex items-center gap-1 cursor-pointer hover:text-slate-600">
                        <ThumbsUp className="w-3 h-3" /> Helpful ({rev.helpful_count})
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 bg-slate-50 rounded-2xl text-center text-xs text-slate-500 border border-slate-200">
                No customer reviews yet. Be the first verified buyer to review!
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Similar Products Carousel */}
      {similarProducts.length > 0 && (
        <section className="pt-10 border-t border-slate-200">
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-display mb-6">
            Similar Products You Might Like
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {similarProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
