import React from 'react';
import { Link } from 'react-router-dom';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { useUI } from '../context/UIContext';
import { formatPrice } from '../utils';
import { ProductIdBadge } from '../components/common/ProductIdBadge';
import { EmptyState } from '../components/common/EmptyState';
import { Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';

export const WishlistPage: React.FC = () => {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { addToast } = useUI();

  const handleMoveToCart = (product: any) => {
    addToCart(product, 1);
    removeFromWishlist(product.id);
    addToast('Moved to Cart', `${product.product_name} moved to your cart`, 'success');
  };

  if (wishlist.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <EmptyState
          icon={<Heart className="w-12 h-12 stroke-[1.5] text-rose-500" />}
          title="Your Wishlist is Empty"
          description="Save items you love to your wishlist. Review them anytime and easily move them to your shopping cart."
          actionText="Discover Products"
          actionHref="/products"
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            My Wishlist ({wishlist.length} items)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Items saved for later. Prices and stock update in real-time.
          </p>
        </div>

        <button
          onClick={clearWishlist}
          className="text-xs font-bold text-rose-600 hover:text-rose-700 underline underline-offset-4"
        >
          Clear All Items
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {wishlist.map(({ id, product }) => (
          <div
            key={id}
            className="group bg-white rounded-3xl border border-slate-100 hover:border-brand-200 p-4 shadow-sm hover:shadow-soft transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              {/* Image */}
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-slate-50 mb-3">
                <Link to={`/products/${product.product_id}`}>
                  <img
                    src={product.images[0]}
                    alt={product.product_name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </Link>
                <button
                  onClick={() => removeFromWishlist(product.id)}
                  className="absolute top-2.5 right-2.5 p-2 bg-white/90 hover:bg-white text-slate-500 hover:text-rose-600 rounded-full shadow-sm transition-colors"
                  title="Remove from Wishlist"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Brand & ID */}
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <span className="text-xs font-bold text-brand-600 uppercase tracking-wider">
                  {product.brand}
                </span>
                <ProductIdBadge productId={product.product_id} size="sm" />
              </div>

              {/* Title */}
              <Link
                to={`/products/${product.product_id}`}
                className="text-sm font-bold text-slate-800 hover:text-brand-600 transition-colors line-clamp-2 mb-2 font-display"
              >
                {product.product_name}
              </Link>

              {/* Price */}
              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-lg font-black text-slate-900">
                  {formatPrice(product.price)}
                </span>
                {product.original_price > product.price && (
                  <span className="text-xs text-slate-400 line-through">
                    {formatPrice(product.original_price)}
                  </span>
                )}
                {product.discount > 0 && (
                  <span className="text-xs text-emerald-600 font-bold">
                    {product.discount}% OFF
                  </span>
                )}
              </div>
            </div>

            {/* Move to cart action */}
            <button
              onClick={() => handleMoveToCart(product)}
              className="w-full py-2.5 px-4 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-xl text-xs shadow-sm hover:shadow-glow flex items-center justify-center gap-2 transition-all"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Move to Cart</span>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
