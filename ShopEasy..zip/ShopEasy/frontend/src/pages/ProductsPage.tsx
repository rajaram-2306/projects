import React, { useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { ProductGrid } from '../components/product/ProductGrid';
import { ProductIdBadge } from '../components/common/ProductIdBadge';
import {
  Filter,
  SlidersHorizontal,
  Grid,
  List,
  X,
  Sparkles,
  ChevronDown,
  Star,
  Check,
  Search,
  ArrowUpDown
} from 'lucide-react';
import { formatPrice } from '../utils';

export const ProductsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // URL Query Parameters
  const queryParam = searchParams.get('q') || '';
  const categoryParam = searchParams.get('category') || 'all';
  const dealParam = searchParams.get('deal') === 'true';
  const trendingParam = searchParams.get('trending') === 'true';

  // Local Filter States
  const [selectedCategory, setSelectedCategory] = useState<string>(categoryParam);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(100000);
  const [minRating, setMinRating] = useState<number>(0);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [minDiscount, setMinDiscount] = useState<number>(0);
  const [sortBy, setSortBy] = useState<string>('relevance');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState<boolean>(false);

  // Sync category param from URL if changed
  React.useEffect(() => {
    setSelectedCategory(categoryParam);
  }, [categoryParam]);

  // Extract all unique brands in catalog
  const allBrands = useMemo(() => {
    return Array.from(new Set(PRODUCTS.map((p) => p.brand))).sort();
  }, []);

  // Filter and Sort Logic
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      // Search query
      if (queryParam) {
        const q = queryParam.toLowerCase();
        const matchesName = product.product_name.toLowerCase().includes(q);
        const matchesBrand = product.brand.toLowerCase().includes(q);
        const matchesId = product.product_id.toLowerCase().includes(q);
        const matchesSku = product.sku.toLowerCase().includes(q);
        const matchesCategory = product.category_name.toLowerCase().includes(q);
        const matchesTags = product.tags.some((t) => t.toLowerCase().includes(q));

        if (!matchesName && !matchesBrand && !matchesId && !matchesSku && !matchesCategory && !matchesTags) {
          return false;
        }
      }

      // Category
      if (selectedCategory !== 'all' && product.category_code !== selectedCategory) {
        return false;
      }

      // Deals & Trending flags
      if (dealParam && !product.is_deal) return false;
      if (trendingParam && !product.is_trending) return false;

      // Brands
      if (selectedBrands.length > 0 && !selectedBrands.includes(product.brand)) {
        return false;
      }

      // Price Range
      if (product.price < minPrice || product.price > maxPrice) {
        return false;
      }

      // Rating
      if (product.rating < minRating) {
        return false;
      }

      // In stock
      if (inStockOnly && product.stock_quantity <= 0) {
        return false;
      }

      // Discount
      if (minDiscount > 0 && product.discount < minDiscount) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price_low') return a.price - b.price;
      if (sortBy === 'price_high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'discount') return b.discount - a.discount;
      if (sortBy === 'newest') return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      return 0; // relevance
    });
  }, [
    queryParam,
    selectedCategory,
    dealParam,
    trendingParam,
    selectedBrands,
    minPrice,
    maxPrice,
    minRating,
    inStockOnly,
    minDiscount,
    sortBy
  ]);

  const handleBrandToggle = (brand: string) => {
    setSelectedBrands((prev) =>
      prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]
    );
  };

  const clearAllFilters = () => {
    setSelectedCategory('all');
    setSelectedBrands([]);
    setMinPrice(0);
    setMaxPrice(100000);
    setMinRating(0);
    setInStockOnly(false);
    setMinDiscount(0);
    setSortBy('relevance');
    setSearchParams({});
  };

  const hasActiveFilters =
    selectedCategory !== 'all' ||
    selectedBrands.length > 0 ||
    minPrice > 0 ||
    maxPrice < 100000 ||
    minRating > 0 ||
    inStockOnly ||
    minDiscount > 0 ||
    !!queryParam;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      {/* Breadcrumb & Top Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <Link to="/" className="hover:text-brand-600 transition-colors">Home</Link>
            <span>/</span>
            <span className="text-slate-800 font-semibold">Products</span>
            {queryParam && (
              <>
                <span>/</span>
                <span className="text-brand-600 font-medium font-mono">"{queryParam}"</span>
              </>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            {queryParam
              ? `Search Results for "${queryParam}"`
              : selectedCategory !== 'all'
              ? `${CATEGORIES.find((c) => c.code === selectedCategory)?.name || 'Category'}`
              : dealParam
              ? "Today's Flash Deals"
              : trendingParam
              ? 'Trending Catalog'
              : 'All Products'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Showing <strong className="text-slate-900">{filteredProducts.length}</strong> verified products
          </p>
        </div>

        {/* View Toggle & Mobile Filter Button */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsMobileFilterOpen(true)}
            className="lg:hidden flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 shadow-sm"
          >
            <Filter className="w-4 h-4 text-brand-600" />
            <span>Filters ({selectedBrands.length + (selectedCategory !== 'all' ? 1 : 0)})</span>
          </button>

          {/* Sort Select */}
          <div className="flex items-center bg-white border border-slate-200 rounded-xl px-3 py-1.5 shadow-sm text-xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 mr-2" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-transparent font-semibold text-slate-700 focus:outline-none cursor-pointer py-1"
            >
              <option value="relevance">Sort: Relevance</option>
              <option value="price_low">Price: Low to High</option>
              <option value="price_high">Price: High to Low</option>
              <option value="rating">Top Customer Rated</option>
              <option value="discount">Biggest Discount</option>
              <option value="newest">Newest Arrivals</option>
            </select>
          </div>

          {/* Grid / List Switcher */}
          <div className="hidden sm:flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'
              }`}
              title="Grid View"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'list' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Active Filter Chips */}
      {hasActiveFilters && (
        <div className="flex items-center gap-2 flex-wrap mb-6 p-3 bg-brand-50/50 rounded-2xl border border-brand-100">
          <span className="text-xs font-bold text-brand-900">Active Filters:</span>
          {selectedCategory !== 'all' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white border border-brand-200 text-xs font-semibold text-brand-700 shadow-sm">
              Category: {selectedCategory}
              <button onClick={() => setSelectedCategory('all')}>
                <X className="w-3 h-3 text-brand-400 hover:text-brand-600" />
              </button>
            </span>
          )}
          {selectedBrands.map((b) => (
            <span key={b} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white border border-brand-200 text-xs font-semibold text-brand-700 shadow-sm">
              Brand: {b}
              <button onClick={() => handleBrandToggle(b)}>
                <X className="w-3 h-3 text-brand-400 hover:text-brand-600" />
              </button>
            </span>
          ))}
          {minRating > 0 && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white border border-brand-200 text-xs font-semibold text-brand-700 shadow-sm">
              ★ {minRating}+ Stars
              <button onClick={() => setMinRating(0)}>
                <X className="w-3 h-3 text-brand-400 hover:text-brand-600" />
              </button>
            </span>
          )}
          {inStockOnly && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white border border-brand-200 text-xs font-semibold text-emerald-700 shadow-sm">
              In Stock Only
              <button onClick={() => setInStockOnly(false)}>
                <X className="w-3 h-3 text-emerald-400 hover:text-emerald-600" />
              </button>
            </span>
          )}
          <button
            onClick={clearAllFilters}
            className="text-xs text-rose-600 hover:text-rose-700 font-bold ml-auto underline underline-offset-2"
          >
            Clear All
          </button>
        </div>
      )}

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        {/* Left Filter Sidebar (Desktop) */}
        <aside className="hidden lg:block bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-6 sticky top-24">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 font-display flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-brand-600" />
              Filter Catalog
            </h3>
            {hasActiveFilters && (
              <button
                onClick={clearAllFilters}
                className="text-[11px] text-rose-600 font-bold hover:underline"
              >
                Reset
              </button>
            )}
          </div>

          {/* Category Filter */}
          <div>
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
              Categories
            </h4>
            <div className="space-y-1.5 text-xs max-h-48 overflow-y-auto pr-1">
              <label className="flex items-center gap-2 cursor-pointer hover:text-brand-600">
                <input
                  type="radio"
                  name="category"
                  checked={selectedCategory === 'all'}
                  onChange={() => setSelectedCategory('all')}
                  className="text-brand-600 focus:ring-brand-500 rounded"
                />
                <span className={selectedCategory === 'all' ? 'font-bold text-brand-600' : 'text-slate-600'}>
                  All Categories ({PRODUCTS.length})
                </span>
              </label>
              {CATEGORIES.map((cat) => (
                <label key={cat.code} className="flex items-center gap-2 cursor-pointer hover:text-brand-600">
                  <input
                    type="radio"
                    name="category"
                    checked={selectedCategory === cat.code}
                    onChange={() => setSelectedCategory(cat.code)}
                    className="text-brand-600 focus:ring-brand-500"
                  />
                  <span className={selectedCategory === cat.code ? 'font-bold text-brand-600' : 'text-slate-600'}>
                    {cat.name} ({cat.code})
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
              Price Range
            </h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-900">
                <span>{formatPrice(minPrice)}</span>
                <span>{formatPrice(maxPrice)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="80000"
                step="500"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-brand-600"
              />
            </div>
          </div>

          {/* Brands Filter */}
          <div className="pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
              Brands
            </h4>
            <div className="space-y-1.5 text-xs max-h-40 overflow-y-auto pr-1">
              {allBrands.map((brand) => (
                <label key={brand} className="flex items-center gap-2 cursor-pointer hover:text-brand-600">
                  <input
                    type="checkbox"
                    checked={selectedBrands.includes(brand)}
                    onChange={() => handleBrandToggle(brand)}
                    className="rounded text-brand-600 focus:ring-brand-500"
                  />
                  <span className={selectedBrands.includes(brand) ? 'font-bold text-brand-600' : 'text-slate-600'}>
                    {brand}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Customer Rating */}
          <div className="pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
              Customer Rating
            </h4>
            <div className="space-y-1.5 text-xs">
              {[4, 3, 2].map((stars) => (
                <label key={stars} className="flex items-center gap-2 cursor-pointer hover:text-brand-600">
                  <input
                    type="radio"
                    name="rating"
                    checked={minRating === stars}
                    onChange={() => setMinRating(stars)}
                    className="text-brand-600 focus:ring-brand-500"
                  />
                  <span className="flex items-center gap-1 text-slate-700">
                    <span className="font-bold">{stars}★ & above</span>
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* In Stock & Discounts */}
          <div className="pt-4 border-t border-slate-100 space-y-2">
            <label className="flex items-center gap-2 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="rounded text-brand-600 focus:ring-brand-500"
              />
              <span className="font-semibold text-slate-700">In Stock Only</span>
            </label>
          </div>
        </aside>

        {/* Product Grid / List Content */}
        <div className="lg:col-span-3">
          <ProductGrid
            products={filteredProducts}
            viewMode={viewMode}
            onClearFilters={hasActiveFilters ? clearAllFilters : undefined}
          />
        </div>
      </div>
    </div>
  );
};
