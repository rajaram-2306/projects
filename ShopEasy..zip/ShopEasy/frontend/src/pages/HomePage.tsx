import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Sparkles,
  ArrowRight,
  Zap,
  Flame,
  Star,
  ShoppingBag,
  Clock,
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  Award,
  TrendingUp,
  Percent,
  Search
} from 'lucide-react';
import { PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { ProductCard } from '../components/product/ProductCard';
import { ProductGrid } from '../components/product/ProductGrid';
import { useUI } from '../context/UIContext';
import { formatPrice } from '../utils';

export const HomePage: React.FC = () => {
  const { openAIAssistant } = useUI();

  // Filter categorized product collections
  const trendingProducts = PRODUCTS.filter((p) => p.is_trending).slice(0, 8);
  const bestSellers = PRODUCTS.filter((p) => p.is_bestseller).slice(0, 8);
  const todaysDeals = PRODUCTS.filter((p) => p.is_deal).slice(0, 6);
  const recommendedProducts = PRODUCTS.filter((p) => p.is_featured).slice(0, 4);

  // Deal countdown timer mockup
  const [timeLeft, setTimeLeft] = useState({ hours: 14, minutes: 32, seconds: 45 });
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 24, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="space-y-12 sm:space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white py-16 sm:py-24 px-4 sm:px-6">
        {/* Ambient Glows */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-brand-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Hero Left Content */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs font-bold animate-pulse">
              <Sparkles className="w-3.5 h-3.5 text-accent-400" />
              <span>Next-Gen AI Shopping Experience</span>
            </div>

            <h1 className="text-4xl sm:text-6xl font-black font-display tracking-tight text-white leading-tight">
              Discover More. <br />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-brand-400 via-indigo-300 to-accent-400">
                Shop Smarter.
              </span>
            </h1>

            <p className="text-slate-300 text-base sm:text-lg max-w-xl mx-auto lg:mx-0 leading-relaxed font-light">
              Experience the future of e-commerce. Talk to ShopEasy AI in plain English, compare live technical specs, discover verified deals, and track deliveries with WhatsApp OTP security.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
              <Link
                to="/products"
                className="px-7 py-3.5 rounded-2xl bg-brand-600 hover:bg-brand-500 text-white text-sm font-bold shadow-glow hover:scale-[1.02] transition-all duration-200 flex items-center gap-2"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <button
                onClick={() => openAIAssistant()}
                className="px-6 py-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 text-cyan-300 border border-cyan-500/30 hover:border-cyan-400 text-sm font-bold shadow-sm transition-all duration-200 flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-accent-400" />
                <span>Ask ShopEasy AI</span>
              </button>

              <Link
                to="/products"
                className="px-6 py-3.5 rounded-2xl bg-transparent hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-sm font-semibold transition-colors"
              >
                Explore Categories
              </Link>
            </div>

            {/* Mini Trust Highlights */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-800 text-left max-w-lg mx-auto lg:mx-0">
              <div>
                <span className="block text-xl font-extrabold text-white font-display">10,000+</span>
                <span className="text-xs text-slate-400">Verified Products</span>
              </div>
              <div>
                <span className="block text-xl font-extrabold text-accent-400 font-display">100%</span>
                <span className="text-xs text-slate-400">Authentic Sellers</span>
              </div>
              <div>
                <span className="block text-xl font-extrabold text-brand-400 font-display">Instant</span>
                <span className="text-xs text-slate-400">WhatsApp OTP</span>
              </div>
            </div>
          </div>

          {/* Hero Right Interactive AI Spotlight Card */}
          <div className="lg:col-span-5">
            <div className="relative bg-slate-900/90 border border-slate-700/80 rounded-3xl p-6 shadow-2xl backdrop-blur-xl">
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-brand-600/30 text-brand-400 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-accent-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">ShopEasy AI Natural Search</h3>
                    <p className="text-[11px] text-slate-400">Try asking anything</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
                  Online
                </span>
              </div>

              {/* Sample AI Dialogue Preview */}
              <div className="space-y-3 mb-5 text-xs">
                <div className="bg-slate-800/70 p-3 rounded-2xl rounded-tr-none text-slate-200 border border-slate-700">
                  <p className="font-semibold text-accent-400 text-[10px] uppercase mb-1">User Query</p>
                  "Good active noise-cancelling headphones under ₹5000 with high battery life"
                </div>

                <div className="bg-brand-950/60 p-3 rounded-2xl rounded-tl-none text-slate-200 border border-brand-800/40">
                  <p className="font-semibold text-brand-400 text-[10px] uppercase mb-1">AI Recommendation Grounded</p>
                  <div className="flex items-center gap-3">
                    <img
                      src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=150&q=80"
                      alt=""
                      className="w-12 h-12 rounded-xl object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-white text-xs truncate">AeroSound Pro Hybrid ANC</p>
                      <p className="text-accent-400 font-extrabold text-xs">₹3,499 (4.7★ • 65h battery)</p>
                      <span className="text-[10px] text-slate-400 font-mono">ID: SHP-ELE-000001</span>
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => openAIAssistant('good headphones under ₹5000')}
                className="w-full py-3 bg-gradient-to-r from-brand-600 to-accent-600 hover:opacity-95 text-white rounded-xl text-xs font-bold shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Launch AI Shopping Search</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-xs font-bold text-brand-600 uppercase tracking-wider">
              Browse Collections
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              Shop by Category
            </h2>
          </div>
          <Link
            to="/products"
            className="text-xs sm:text-sm font-bold text-brand-600 hover:text-brand-700 flex items-center gap-1 group"
          >
            <span>View All</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 sm:gap-6">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.code}
              to={`/products?category=${cat.code}`}
              className="group relative bg-white rounded-2xl p-4 border border-slate-100 hover:border-brand-200 shadow-sm hover:shadow-soft transition-all duration-300 flex flex-col items-center text-center overflow-hidden"
            >
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden mb-3 bg-slate-50 group-hover:scale-105 transition-transform duration-300">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-800 group-hover:text-brand-600 transition-colors font-display line-clamp-1">
                {cat.name}
              </h3>
              <span className="text-[11px] text-slate-400 mt-0.5">
                {cat.itemCount}+ Items
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Today's Deals with Live Countdown */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-brand-500/10 rounded-3xl p-6 sm:p-8 border border-amber-200/60 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-amber-500 text-white shadow-md">
                <Zap className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-display">
                    Today's Flash Deals
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-500 text-white">
                    Up to 50% OFF
                  </span>
                </div>
                <p className="text-xs text-slate-600">Limited-time discounted prices. Grab before stock ends!</p>
              </div>
            </div>

            {/* Countdown Timer */}
            <div className="flex items-center gap-2 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-2xl border border-amber-200 shadow-sm">
              <Clock className="w-4 h-4 text-amber-600" />
              <span className="text-xs font-semibold text-slate-600">Ends in:</span>
              <div className="flex items-center gap-1 font-mono font-bold text-xs text-slate-900">
                <span className="bg-slate-900 text-white px-1.5 py-0.5 rounded">
                  {String(timeLeft.hours).padStart(2, '0')}
                </span>
                <span>:</span>
                <span className="bg-slate-900 text-white px-1.5 py-0.5 rounded">
                  {String(timeLeft.minutes).padStart(2, '0')}
                </span>
                <span>:</span>
                <span className="bg-slate-900 text-white px-1.5 py-0.5 rounded">
                  {String(timeLeft.seconds).padStart(2, '0')}
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {todaysDeals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Trending Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-rose-600 uppercase tracking-wider">
                Popular Right Now
              </span>
              <Flame className="w-4 h-4 text-rose-500" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              Trending on ShopEasy
            </h2>
          </div>
          <Link
            to="/products?trending=true"
            className="text-xs sm:text-sm font-bold text-brand-600 hover:text-brand-700 flex items-center gap-1 group"
          >
            <span>Explore All</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <ProductGrid products={trendingProducts} />
      </section>

      {/* Smart AI Picks Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="bg-gradient-to-r from-brand-900 via-indigo-950 to-slate-950 rounded-3xl p-8 text-white relative overflow-hidden shadow-xl border border-brand-800/50">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5 space-y-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent-500/20 text-accent-300 text-xs font-bold border border-accent-500/30">
                <Sparkles className="w-3.5 h-3.5 text-accent-400" />
                <span>AI Recommendation Engine</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-black font-display leading-tight">
                Curated Smart Picks <br />
                <span className="text-accent-400">Tailored For Your Taste</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-light">
                ShopEasy AI scans top-reviewed products with verified customer feedback and high value ratings to present daily highlights.
              </p>
              <button
                onClick={() => openAIAssistant('Show me the best rated items across all categories')}
                className="px-6 py-3 bg-white hover:bg-slate-100 text-slate-900 rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2"
              >
                <span>Ask AI to Recommend More</span>
                <ArrowRight className="w-4 h-4 text-brand-600" />
              </button>
            </div>

            <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-3">
              {recommendedProducts.map((p) => (
                <div
                  key={p.id}
                  className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10 flex flex-col justify-between"
                >
                  <img
                    src={p.images[0]}
                    alt={p.product_name}
                    className="w-full aspect-square object-cover rounded-xl mb-2"
                  />
                  <span className="text-[10px] font-mono text-cyan-300">{p.product_id}</span>
                  <p className="text-xs font-bold text-white line-clamp-1">{p.product_name}</p>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/10">
                    <span className="text-xs font-extrabold text-white">{formatPrice(p.price)}</span>
                    <span className="text-[10px] text-amber-300 font-bold">★ {p.rating}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Best Sellers Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-xs font-bold text-brand-600 uppercase tracking-wider">
              Top Customer Choices
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              Best Sellers
            </h2>
          </div>
          <Link
            to="/products?sort=popularity"
            className="text-xs sm:text-sm font-bold text-brand-600 hover:text-brand-700 flex items-center gap-1 group"
          >
            <span>View All</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <ProductGrid products={bestSellers} />
      </section>
    </div>
  );
};
