import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, ArrowLeft, Search } from 'lucide-react';
import { AISearchBar } from '../components/ai/AISearchBar';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-[75vh] flex flex-col items-center justify-center px-4 py-16 text-center space-y-6">
      <div className="w-24 h-24 rounded-3xl bg-brand-50 text-brand-600 flex items-center justify-center shadow-inner">
        <span className="text-4xl font-black font-display">404</span>
      </div>

      <div className="space-y-2 max-w-md">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-display">
          Page Not Found
        </h1>
        <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
          The page or product you're looking for might have been moved, renamed, or is temporarily unavailable.
        </p>
      </div>

      <div className="w-full max-w-md">
        <AISearchBar />
      </div>

      <div className="flex items-center gap-3 pt-2">
        <Link
          to="/"
          className="px-6 py-3 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-2xl text-xs shadow-md flex items-center gap-2 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </Link>
        <Link
          to="/products"
          className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-colors"
        >
          Browse All Products
        </Link>
      </div>
    </div>
  );
};
