import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';
import { ShoppingBag, Sparkles, Lock, Mail, Eye, EyeOff, ArrowRight, Shield, Store, CheckCircle2 } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const { addToast } = useUI();

  const [role, setRole] = useState<'CUSTOMER' | 'SELLER' | 'ADMIN'>('CUSTOMER');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      addToast('Validation Error', 'Please enter both email and password', 'error');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      login(email, role);
      setIsLoading(false);
      addToast('Welcome Back!', `Logged in successfully as ${role}`, 'success');
      navigate('/');
    }, 600);
  };

  const handleDemoLogin = (demoRole: 'CUSTOMER' | 'SELLER' | 'ADMIN', demoEmail: string) => {
    setEmail(demoEmail);
    setPassword('ShopEasy@2026');
    setRole(demoRole);
    login(demoEmail, demoRole);
    addToast('Demo Login Active', `Signed in as ${demoRole} (${demoEmail})`, 'success');
    navigate('/');
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-12 px-4 sm:px-6">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-xl border border-slate-100 p-8 space-y-6">
        {/* Logo & Header */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-brand-600 via-indigo-600 to-accent-500 p-[1.5px] shadow-glow flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
            </div>
            <span className="text-2xl font-black font-display text-slate-900">
              SHOP<span className="text-brand-600">EASY</span>
            </span>
          </Link>
          <h2 className="text-xl font-bold font-display text-slate-900 pt-2">
            Sign In to ShopEasy
          </h2>
          <p className="text-xs text-slate-500">
            Access your verified shopping cart, wishlist, and orders.
          </p>
        </div>

        {/* Role Picker Tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-2xl">
          {(['CUSTOMER', 'SELLER', 'ADMIN'] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`py-2 rounded-xl text-xs font-bold transition-all ${
                role === r
                  ? 'bg-white text-brand-600 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {r === 'CUSTOMER' ? 'Shopper' : r === 'SELLER' ? 'Seller' : 'Admin'}
            </button>
          ))}
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="font-bold text-slate-700 uppercase tracking-wider">
                Password
              </label>
              <a href="#forgot" className="text-brand-600 hover:underline text-[11px] font-semibold">
                Forgot password?
              </a>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-glow flex items-center justify-center gap-2 transition-all disabled:opacity-50"
          >
            <span>{isLoading ? 'Authenticating...' : `Sign In as ${role}`}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Quick Demo Access Pills */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-2">
          <p className="font-bold text-slate-800 text-[11px] uppercase tracking-wider">
            Quick 1-Click Demo Logins:
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => handleDemoLogin('CUSTOMER', 'customer@shopeasy.com')}
              className="px-2.5 py-1 bg-white border border-slate-200 hover:border-brand-300 rounded-lg text-[11px] font-semibold text-slate-700"
            >
              Demo Shopper
            </button>
            <button
              onClick={() => handleDemoLogin('SELLER', 'seller@shopeasy.com')}
              className="px-2.5 py-1 bg-white border border-slate-200 hover:border-brand-300 rounded-lg text-[11px] font-semibold text-slate-700"
            >
              Demo Seller
            </button>
            <button
              onClick={() => handleDemoLogin('ADMIN', 'admin@shopeasy.com')}
              className="px-2.5 py-1 bg-white border border-slate-200 hover:border-brand-300 rounded-lg text-[11px] font-semibold text-slate-700"
            >
              Demo Admin
            </button>
          </div>
        </div>

        {/* Register CTA */}
        <p className="text-center text-xs text-slate-500">
          Don't have an account?{' '}
          <Link to="/register" className="font-bold text-brand-600 hover:underline">
            Create Account with WhatsApp OTP
          </Link>
        </p>
      </div>
    </div>
  );
};
