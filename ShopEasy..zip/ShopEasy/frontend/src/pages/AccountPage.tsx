import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';
import { Order, Address } from '../types';
import { formatPrice } from '../utils';
import { ProductIdBadge } from '../components/common/ProductIdBadge';
import {
  User as UserIcon,
  Package,
  MapPin,
  Settings,
  Shield,
  CheckCircle2,
  Truck,
  RotateCcw,
  Clock,
  ChevronRight,
  Plus,
  Edit2,
  Trash2
} from 'lucide-react';

const MOCK_ORDERS: Order[] = [
  {
    id: 'ORD-2026-000001',
    items: [
      {
        product_id: 'SHP-ELE-000001',
        internal_id: 'prod-ele-01',
        product_name: 'AeroSound Pro Hybrid Active Noise Cancelling Headphones',
        price: 3499,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=400&q=80',
        sku: 'SKU-AERO-ANC-BLK',
        brand: 'AeroSound'
      }
    ],
    subtotal: 3499,
    discount: 0,
    shipping: 0,
    tax: 175,
    total_amount: 3499,
    shipping_address: {
      id: 'addr-1',
      name: 'Alex Johnson',
      mobile: '+91 98765 43210',
      street: '402, High Street Towers, Indiranagar',
      city: 'Bengaluru',
      state: 'Karnataka',
      pin: '560038',
      is_default: true,
      type: 'HOME'
    },
    payment_method: 'UPI',
    payment_status: 'COMPLETED',
    order_status: 'SHIPPED',
    tracking_steps: [
      { status: 'PLACED', label: 'Order Placed', description: 'Received order on 2026-09-22', completed: true },
      { status: 'CONFIRMED', label: 'Confirmed', description: 'Seller verified stock', completed: true },
      { status: 'PACKED', label: 'Packed & Invoiced', description: 'Dispatched from Bengaluru Hub', completed: true },
      { status: 'SHIPPED', label: 'Shipped', description: 'In transit via Express Logistics', completed: true, current: true },
      { status: 'OUT_FOR_DELIVERY', label: 'Out for Delivery', description: 'Expected tomorrow 5:00 PM', completed: false },
      { status: 'DELIVERED', label: 'Delivered', description: 'Pending recipient OTP', completed: false }
    ],
    created_at: '2026-09-22T14:20:00Z'
  },
  {
    id: 'ORD-2026-000002',
    items: [
      {
        product_id: 'SHP-MOB-000002',
        internal_id: 'prod-mob-02',
        product_name: 'VoltSpeed GaN Prime 65W Fast Charger 3-Port',
        price: 1299,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=400&q=80',
        sku: 'SKU-VOLT-65W-GAN',
        brand: 'VoltSpeed'
      }
    ],
    subtotal: 1299,
    discount: 100,
    shipping: 0,
    tax: 60,
    total_amount: 1199,
    shipping_address: {
      id: 'addr-1',
      name: 'Alex Johnson',
      mobile: '+91 98765 43210',
      street: '402, High Street Towers, Indiranagar',
      city: 'Bengaluru',
      state: 'Karnataka',
      pin: '560038',
      is_default: true,
      type: 'HOME'
    },
    payment_method: 'CREDIT_CARD',
    payment_status: 'COMPLETED',
    order_status: 'DELIVERED',
    tracking_steps: [
      { status: 'PLACED', label: 'Order Placed', description: '2026-09-10', completed: true },
      { status: 'CONFIRMED', label: 'Confirmed', description: '2026-09-10', completed: true },
      { status: 'PACKED', label: 'Packed', description: '2026-09-11', completed: true },
      { status: 'SHIPPED', label: 'Shipped', description: '2026-09-11', completed: true },
      { status: 'OUT_FOR_DELIVERY', label: 'Out for Delivery', description: '2026-09-12', completed: true },
      { status: 'DELIVERED', label: 'Delivered', description: 'Handed over on 2026-09-12', completed: true, current: true }
    ],
    created_at: '2026-09-10T09:30:00Z'
  }
];

export const AccountPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab = (searchParams.get('tab') as 'profile' | 'orders' | 'addresses' | 'settings') || 'profile';

  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'addresses' | 'settings'>(initialTab);
  const { user, switchRole } = useAuth();
  const { addToast } = useUI();

  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: 'addr-1',
      name: 'Alex Johnson',
      mobile: '+91 98765 43210',
      street: '402, High Street Towers, Indiranagar',
      city: 'Bengaluru',
      state: 'Karnataka',
      pin: '560038',
      landmark: 'Near Metro Pillar 124',
      is_default: true,
      type: 'HOME'
    },
    {
      id: 'addr-2',
      name: 'Alex Johnson',
      mobile: '+91 98765 43210',
      street: 'Tech Park Block B, Embassy Tech Village, Outer Ring Road',
      city: 'Bengaluru',
      state: 'Karnataka',
      pin: '560103',
      is_default: false,
      type: 'WORK'
    }
  ]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Account Header */}
      <div className="p-6 bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-3xl border border-slate-700 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-brand-500/20 border-2 border-brand-400 p-0.5 overflow-hidden shrink-0">
            <img
              src={user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
              alt={user?.name}
              className="w-full h-full object-cover rounded-[14px]"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold font-display">{user?.name || 'Shopper Account'}</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-brand-500/20 text-brand-300 border border-brand-500/30">
                {user?.role || 'CUSTOMER'}
              </span>
            </div>
            <p className="text-xs text-slate-300">{user?.email}</p>
            <div className="flex items-center gap-2 mt-1 text-[11px] text-emerald-400 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>WhatsApp OTP Verified ({user?.phone})</span>
            </div>
          </div>
        </div>

        {/* Prototype Role Switcher */}
        <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700 text-xs">
          <span className="block text-[10px] uppercase font-bold text-slate-400 mb-1.5">
            Demonstration Role Switcher
          </span>
          <div className="flex gap-2">
            {(['CUSTOMER', 'SELLER', 'ADMIN'] as const).map((r) => (
              <button
                key={r}
                onClick={() => {
                  switchRole(r);
                  addToast('Role Changed', `Switched active role to ${r}`, 'info');
                }}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors ${
                  user?.role === r
                    ? 'bg-brand-600 text-white shadow-sm'
                    : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Tabs Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Navigation Tabs Sidebar */}
        <aside className="lg:col-span-3 bg-white rounded-3xl p-3 border border-slate-100 shadow-sm space-y-1">
          {[
            { id: 'profile', label: 'Personal Profile', icon: <UserIcon className="w-4 h-4" /> },
            { id: 'orders', label: 'My Orders & Tracking', icon: <Package className="w-4 h-4" /> },
            { id: 'addresses', label: 'Saved Addresses', icon: <MapPin className="w-4 h-4" /> },
            { id: 'settings', label: 'Security & Preferences', icon: <Settings className="w-4 h-4" /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setSearchParams({ tab: tab.id });
              }}
              className={`w-full flex items-center justify-between p-3 rounded-2xl text-xs font-bold transition-all ${
                activeTab === tab.id
                  ? 'bg-brand-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3">
                {tab.icon}
                <span>{tab.label}</span>
              </div>
              <ChevronRight className="w-4 h-4 opacity-70" />
            </button>
          ))}
        </aside>

        {/* Tab Content Panel */}
        <main className="lg:col-span-9 bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-sm">
          {/* PROFILE TAB */}
          {activeTab === 'profile' && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-lg font-bold text-slate-900 font-display pb-4 border-b border-slate-100">
                Personal Information
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
                <div>
                  <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">Full Name</label>
                  <p className="p-3 bg-slate-50 rounded-xl border border-slate-200 font-semibold text-slate-900">
                    {user?.name || 'Alex Johnson'}
                  </p>
                </div>
                <div>
                  <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">Email Address</label>
                  <p className="p-3 bg-slate-50 rounded-xl border border-slate-200 font-semibold text-slate-900">
                    {user?.email || 'alex.johnson@example.com'}
                  </p>
                </div>
                <div>
                  <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">Registered Phone (WhatsApp)</label>
                  <p className="p-3 bg-slate-50 rounded-xl border border-slate-200 font-semibold text-slate-900 flex items-center justify-between">
                    <span>{user?.phone || '+91 98765 43210'}</span>
                    <span className="text-emerald-600 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                    </span>
                  </p>
                </div>
                <div>
                  <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">Account Role</label>
                  <p className="p-3 bg-slate-50 rounded-xl border border-slate-200 font-semibold text-slate-900">
                    {user?.role || 'CUSTOMER'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ORDERS & TRACKING TAB */}
          {activeTab === 'orders' && (
            <div className="space-y-8 animate-fade-in">
              <h2 className="text-lg font-bold text-slate-900 font-display pb-4 border-b border-slate-100">
                Order History & Live Delivery Tracking
              </h2>

              <div className="space-y-6">
                {MOCK_ORDERS.map((order) => (
                  <div
                    key={order.id}
                    className="p-6 bg-slate-50/70 rounded-3xl border border-slate-200/80 space-y-6"
                  >
                    {/* Order header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-brand-600">{order.id}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-brand-100 text-brand-800">
                            {order.order_status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Placed on {new Date(order.created_at).toLocaleDateString()}
                        </p>
                      </div>

                      <div className="text-left sm:text-right">
                        <span className="text-xs text-slate-500">Total Amount:</span>
                        <span className="block text-base font-black text-slate-900 font-display">
                          {formatPrice(order.total_amount)}
                        </span>
                      </div>
                    </div>

                    {/* Ordered Items */}
                    <div className="space-y-3">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-4">
                          <img
                            src={item.image}
                            alt={item.product_name}
                            className="w-14 h-14 object-cover rounded-xl border border-slate-200"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <ProductIdBadge productId={item.product_id} size="sm" />
                              <span className="text-[10px] font-bold text-brand-600">{item.brand}</span>
                            </div>
                            <h4 className="text-xs font-bold text-slate-900 truncate">
                              {item.product_name}
                            </h4>
                            <p className="text-xs text-slate-500 font-semibold">
                              Qty: {item.quantity} • {formatPrice(item.price)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Tracking Timeline Bar */}
                    <div className="pt-4 border-t border-slate-200 space-y-3">
                      <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-brand-600" />
                        Shipment Milestones
                      </h4>

                      <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 pt-2">
                        {order.tracking_steps.map((step, idx) => (
                          <div
                            key={idx}
                            className={`p-2.5 rounded-xl border text-center text-xs space-y-1 ${
                              step.completed
                                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                                : 'bg-white border-slate-200 text-slate-400 opacity-60'
                            }`}
                          >
                            <div className="w-2 h-2 rounded-full mx-auto mb-1 bg-current" />
                            <p className="font-bold text-[11px] leading-tight">{step.label}</p>
                            <p className="text-[9px] text-slate-500 leading-tight">{step.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SAVED ADDRESSES TAB */}
          {activeTab === 'addresses' && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <h2 className="text-lg font-bold text-slate-900 font-display">
                  Saved Shipping Addresses
                </h2>
                <button
                  onClick={() => addToast('Add Address', 'Address addition modal available', 'info')}
                  className="px-3.5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 hover:bg-slate-800"
                >
                  <Plus className="w-4 h-4" /> Add New
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {addresses.map((addr) => (
                  <div
                    key={addr.id}
                    className={`p-5 rounded-3xl border text-xs space-y-2 relative ${
                      addr.is_default
                        ? 'border-brand-300 bg-brand-50/40'
                        : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded-md font-bold text-[10px] bg-slate-200 text-slate-800">
                        {addr.type}
                      </span>
                      {addr.is_default && (
                        <span className="text-brand-700 font-bold text-[11px]">Default Address</span>
                      )}
                    </div>
                    <p className="font-bold text-slate-900 text-sm">{addr.name}</p>
                    <p className="text-slate-600">{addr.street}</p>
                    <p className="text-slate-600">{addr.city}, {addr.state} - {addr.pin}</p>
                    <p className="text-slate-500 font-mono">Mobile: {addr.mobile}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SETTINGS TAB */}
          {activeTab === 'settings' && (
            <div className="space-y-6 animate-fade-in text-xs">
              <h2 className="text-lg font-bold text-slate-900 font-display pb-4 border-b border-slate-100">
                Security & Account Preferences
              </h2>

              <div className="space-y-4">
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900">WhatsApp Notification Alerts</h4>
                    <p className="text-slate-500 text-[11px]">Receive OTPs, tracking alerts, and dispatch updates on WhatsApp</p>
                  </div>
                  <input type="checkbox" defaultChecked className="toggle-switch accent-brand-600 w-4 h-4" />
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900">Two-Factor Authentication (2FA)</h4>
                    <p className="text-slate-500 text-[11px]">Enforce WhatsApp OTP verification on every new device login</p>
                  </div>
                  <span className="text-emerald-600 font-bold">Enabled</span>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
