import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Header } from '../components/layout/Header';
import { Navbar } from '../components/layout/Navbar';
import { Footer } from '../components/layout/Footer';
import { MobileNav } from '../components/layout/MobileNav';
import { LoadingScreen } from '../components/common/LoadingScreen';
import { ToastContainer } from '../components/common/ToastContainer';
import { AIAssistantModal } from '../components/ai/AIAssistantModal';
import { QuickViewModal } from '../components/product/QuickViewModal';
import { CompareDrawer } from '../components/product/CompareDrawer';
import { useUI } from '../context/UIContext';

export const RootLayout: React.FC = () => {
  const { isLoadingScreen, dismissLoadingScreen } = useUI();
  const location = useLocation();

  // Scroll to top on route change
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-brand-500 selection:text-white pb-14 md:pb-0">
      {/* 1-2s Brand Loading Screen */}
      {isLoadingScreen && <LoadingScreen onDismiss={dismissLoadingScreen} />}

      {/* Main Header & Navbar */}
      <Header />
      <Navbar />

      {/* Page Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Bottom Navigation */}
      <MobileNav />

      {/* Global Modals & Overlays */}
      <AIAssistantModal />
      <QuickViewModal />
      <CompareDrawer />
      <ToastContainer />
    </div>
  );
};
