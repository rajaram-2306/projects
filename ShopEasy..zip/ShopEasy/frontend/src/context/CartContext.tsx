import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Coupon } from '../types';
import { COUPONS } from '../data/coupons';

interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, variant?: string) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  appliedCoupon: Coupon | null;
  couponError: string | null;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  subtotal: number;
  discountAmount: number;
  couponDiscount: number;
  shippingFee: number;
  taxAmount: number;
  totalAmount: number;
  totalItemsCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('shopeasy_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(() => {
    const saved = localStorage.getItem('shopeasy_coupon');
    return saved ? JSON.parse(saved) : null;
  });

  const [couponError, setCouponError] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('shopeasy_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    if (appliedCoupon) {
      localStorage.setItem('shopeasy_coupon', JSON.stringify(appliedCoupon));
    } else {
      localStorage.removeItem('shopeasy_coupon');
    }
  }, [appliedCoupon]);

  const addToCart = (product: Product, quantity = 1, variant?: string) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + quantity, product.stock_quantity) }
            : item
        );
      }
      return [
        ...prev,
        {
          id: `ci-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          product,
          quantity: Math.min(quantity, product.stock_quantity),
          selected_variant: variant
        }
      ];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId && item.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId || item.id === productId
          ? { ...item, quantity: Math.min(quantity, item.product.stock_quantity) }
          : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  // Calculations
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Free shipping above ₹499
  const shippingFee = subtotal === 0 || subtotal >= 499 ? 0 : 49;
  const taxAmount = Math.round(subtotal * 0.05); // Estimated 5% GST included / broken down

  let couponDiscount = 0;
  if (appliedCoupon && subtotal >= appliedCoupon.minimum_order) {
    if (appliedCoupon.discount_type === 'PERCENT') {
      const calculated = (subtotal * appliedCoupon.discount_value) / 100;
      couponDiscount = Math.min(calculated, appliedCoupon.maximum_discount);
    } else {
      couponDiscount = Math.min(appliedCoupon.discount_value, appliedCoupon.maximum_discount);
    }
  }

  const discountAmount = couponDiscount;
  const totalAmount = Math.max(0, subtotal - discountAmount + shippingFee);

  const applyCoupon = (code: string): boolean => {
    setCouponError(null);
    const upperCode = code.trim().toUpperCase();
    const found = COUPONS.find((c) => c.coupon_code === upperCode);

    if (!found) {
      setCouponError('Invalid coupon code. Try WELCOME10, SAVE20, or FIRSTORDER');
      return false;
    }

    if (subtotal < found.minimum_order) {
      setCouponError(`Minimum cart value of ₹${found.minimum_order} required for ${found.coupon_code}`);
      return false;
    }

    setAppliedCoupon(found);
    return true;
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponError(null);
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        appliedCoupon,
        couponError,
        applyCoupon,
        removeCoupon,
        subtotal,
        discountAmount,
        couponDiscount,
        shippingFee,
        taxAmount,
        totalAmount,
        totalItemsCount
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
