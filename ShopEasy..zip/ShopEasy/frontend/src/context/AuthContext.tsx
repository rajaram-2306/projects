import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, role?: 'CUSTOMER' | 'SELLER' | 'ADMIN') => void;
  logout: () => void;
  register: (userData: Partial<User>) => void;
  switchRole: (role: 'CUSTOMER' | 'SELLER' | 'ADMIN') => void;
  verifyWhatsApp: (phone: string, otp: string) => boolean;
}

const DEFAULT_USER: User = {
  id: 'usr-demo-01',
  name: 'Alex Johnson',
  email: 'alex.johnson@example.com',
  phone: '+91 98765 43210',
  role: 'CUSTOMER',
  whatsapp_verified: true,
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  created_at: '2026-01-01T00:00:00Z'
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('shopeasy_user');
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('shopeasy_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('shopeasy_user');
    }
  }, [user]);

  const login = (email: string, role: 'CUSTOMER' | 'SELLER' | 'ADMIN' = 'CUSTOMER') => {
    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: email.split('@')[0] || 'ShopEasy Shopper',
      email: email,
      phone: '+91 98765 43210',
      role: role,
      whatsapp_verified: true,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      created_at: new Date().toISOString()
    };
    setUser(newUser);
  };

  const logout = () => {
    setUser(null);
  };

  const register = (userData: Partial<User>) => {
    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: userData.name || 'New User',
      email: userData.email || 'user@example.com',
      phone: userData.phone || '+91 90000 00000',
      role: userData.role || 'CUSTOMER',
      whatsapp_verified: userData.whatsapp_verified || false,
      seller_business_name: userData.seller_business_name,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      created_at: new Date().toISOString()
    };
    setUser(newUser);
  };

  const switchRole = (role: 'CUSTOMER' | 'SELLER' | 'ADMIN') => {
    if (user) {
      setUser({ ...user, role });
    }
  };

  const verifyWhatsApp = (phone: string, otp: string): boolean => {
    if (otp === '123456' || otp.length === 6) {
      if (user) {
        setUser({ ...user, phone, whatsapp_verified: true });
      }
      return true;
    }
    return false;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        register,
        switchRole,
        verifyWhatsApp
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
