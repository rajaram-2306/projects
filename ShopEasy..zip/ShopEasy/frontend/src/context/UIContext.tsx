import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, ToastMessage } from '../types';

interface UIContextType {
  // Loading Screen
  isLoadingScreen: boolean;
  dismissLoadingScreen: () => void;
  triggerLoadingScreen: () => void;

  // AI Assistant Modal
  isAIAssistantOpen: boolean;
  aiInitialPrompt: string;
  openAIAssistant: (prompt?: string) => void;
  closeAIAssistant: () => void;

  // Quick View Modal
  quickViewProduct: Product | null;
  openQuickView: (product: Product) => void;
  closeQuickView: () => void;

  // Comparison Dock
  compareList: Product[];
  addToCompare: (product: Product) => boolean;
  removeFromCompare: (productId: string) => void;
  clearCompare: () => void;
  isCompareOpen: boolean;
  setIsCompareOpen: (open: boolean) => void;

  // Toast Notifications
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: 'success' | 'error' | 'info' | 'warning', duration?: number) => void;
  removeToast: (id: string) => void;
}

const UIContext = createContext<UIContextType | undefined>(undefined);

export const UIProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Loading Screen: initial 1.6s display
  const [isLoadingScreen, setIsLoadingScreen] = useState<boolean>(true);

  // AI Assistant
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState<boolean>(false);
  const [aiInitialPrompt, setAiInitialPrompt] = useState<string>('');

  // Quick View
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Comparison
  const [compareList, setCompareList] = useState<Product[]>(() => {
    const saved = localStorage.getItem('shopeasy_compare');
    return saved ? JSON.parse(saved) : [];
  });
  const [isCompareOpen, setIsCompareOpen] = useState<boolean>(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    // Smooth initial loading screen duration
    const timer = setTimeout(() => {
      setIsLoadingScreen(false);
    }, 1600);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    localStorage.setItem('shopeasy_compare', JSON.stringify(compareList));
  }, [compareList]);

  const dismissLoadingScreen = () => setIsLoadingScreen(false);
  const triggerLoadingScreen = () => {
    setIsLoadingScreen(true);
    setTimeout(() => setIsLoadingScreen(false), 1200);
  };

  const openAIAssistant = (prompt = '') => {
    setAiInitialPrompt(prompt);
    setIsAIAssistantOpen(true);
  };

  const closeAIAssistant = () => {
    setIsAIAssistantOpen(false);
    setAiInitialPrompt('');
  };

  const openQuickView = (product: Product) => setQuickViewProduct(product);
  const closeQuickView = () => setQuickViewProduct(null);

  const addToast = (
    title: string,
    message: string,
    type: 'success' | 'error' | 'info' | 'warning' = 'info',
    duration = 3500
  ) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const newToast: ToastMessage = { id, title, message, type, duration };
    setToasts((prev) => [...prev, newToast]);

    if (duration > 0) {
      setTimeout(() => {
        removeToast(id);
      }, duration);
    }
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const addToCompare = (product: Product): boolean => {
    if (compareList.some((p) => p.id === product.id)) {
      addToast('Already in Comparison', `${product.product_name} is already in comparison dock.`, 'info');
      setIsCompareOpen(true);
      return false;
    }
    if (compareList.length >= 4) {
      addToast('Comparison Limit Reached', 'You can compare a maximum of 4 products at once.', 'warning');
      setIsCompareOpen(true);
      return false;
    }
    setCompareList((prev) => [...prev, product]);
    addToast('Added to Compare', `${product.product_name} added to comparison.`, 'success');
    setIsCompareOpen(true);
    return true;
  };

  const removeFromCompare = (productId: string) => {
    setCompareList((prev) => prev.filter((p) => p.id !== productId && p.product_id !== productId));
  };

  const clearCompare = () => {
    setCompareList([]);
    setIsCompareOpen(false);
  };

  return (
    <UIContext.Provider
      value={{
        isLoadingScreen,
        dismissLoadingScreen,
        triggerLoadingScreen,
        isAIAssistantOpen,
        aiInitialPrompt,
        openAIAssistant,
        closeAIAssistant,
        quickViewProduct,
        openQuickView,
        closeQuickView,
        compareList,
        addToCompare,
        removeFromCompare,
        clearCompare,
        isCompareOpen,
        setIsCompareOpen,
        toasts,
        addToast,
        removeToast
      }}
    >
      {children}
    </UIContext.Provider>
  );
};

export const useUI = () => {
  const context = useContext(UIContext);
  if (!context) {
    throw new Error('useUI must be used within a UIProvider');
  }
  return context;
};
