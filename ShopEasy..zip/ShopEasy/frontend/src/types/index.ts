export type ProductCategoryCode = 
  | 'ELE' // Electronics
  | 'MOB' // Mobile & Accessories
  | 'FAS' // Fashion
  | 'BEA' // Beauty
  | 'HOM' // Home & Kitchen
  | 'GRO' // Grocery
  | 'BKS' // Books
  | 'SPT' // Sports
  | 'FTW' // Footwear
  | 'ACC'; // Accessories

export interface Product {
  id: string;
  product_id: string; // e.g. SHP-ELE-000001
  productId?: string; // e.g. SE001
  product_name: string;
  name?: string;
  slug: string;
  category_id: string;
  category_name: string;
  category?: string;
  category_code: ProductCategoryCode;
  subcategory_id: string;
  subcategory_name: string;
  subcategory?: string;
  brand: string;
  description: string;
  aiDescription?: string;
  short_description: string;
  price: number;
  original_price: number;
  originalPrice?: number;
  discount: number; // percentage e.g. 25
  discountPercentage?: number;
  stock_quantity: number;
  stock?: number;
  sku: string;
  images: string[];
  image?: string;
  additionalImages?: string[];
  availableColors?: string[];
  availableSizes?: string[];
  specifications: Record<string, string>;
  rating: number;
  review_count: number;
  reviewCount?: number;
  seller_id: string;
  seller_name: string;
  status: 'ACTIVE' | 'INACTIVE' | 'DRAFT';
  tags: string[];
  is_featured?: boolean;
  isFeatured?: boolean;
  is_trending?: boolean;
  isNew?: boolean;
  is_deal?: boolean;
  is_bestseller?: boolean;
  isBestSeller?: boolean;
  highlights: string[];
  created_at: string;
  createdAt?: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  code: ProductCategoryCode;
  slug: string;
  icon: string;
  image: string;
  itemCount: number;
  description: string;
  subcategories: string[];
}

export interface Review {
  id: string;
  product_id: string;
  user_name: string;
  user_avatar?: string;
  rating: number;
  title: string;
  comment: string;
  verified_purchase: boolean;
  helpful_count: number;
  created_at: string;
}

export interface CartItem {
  id: string;
  product: Product;
  quantity: number;
  selected_variant?: string;
}

export interface WishlistItem {
  id: string;
  product: Product;
  added_at: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'CUSTOMER' | 'SELLER' | 'ADMIN';
  whatsapp_verified: boolean;
  avatar?: string;
  seller_business_name?: string;
  created_at: string;
}

export interface Address {
  id: string;
  name: string;
  mobile: string;
  street: string;
  city: string;
  state: string;
  pin: string;
  landmark?: string;
  is_default: boolean;
  type: 'HOME' | 'WORK' | 'OTHER';
}

export interface OrderItem {
  product_id: string; // Real SHP-xxx product_id
  internal_id: string;
  product_name: string;
  price: number;
  quantity: number;
  image: string;
  sku: string;
  brand: string;
}

export type OrderStatus = 
  | 'PLACED' 
  | 'CONFIRMED' 
  | 'PACKED' 
  | 'SHIPPED' 
  | 'OUT_FOR_DELIVERY' 
  | 'DELIVERED' 
  | 'CANCELLED';

export interface TrackingStep {
  status: OrderStatus;
  label: string;
  description: string;
  date?: string;
  completed: boolean;
  current?: boolean;
}

export interface Order {
  id: string; // e.g. ORD-2026-000001
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total_amount: number;
  shipping_address: Address;
  payment_method: 'UPI' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'NET_BANKING' | 'COD';
  payment_status: 'PENDING' | 'COMPLETED' | 'FAILED';
  order_status: OrderStatus;
  tracking_steps: TrackingStep[];
  created_at: string;
}

export interface Coupon {
  coupon_code: string;
  discount_type: 'PERCENT' | 'FIXED';
  discount_value: number;
  minimum_order: number;
  maximum_discount: number;
  expiry_date: string;
  description: string;
  status: 'ACTIVE' | 'EXPIRED';
}

export interface FilterState {
  category: string;
  subcategories: string[];
  brands: string[];
  minPrice: number;
  maxPrice: number;
  rating: number;
  inStockOnly: boolean;
  discountMin: number;
  sortBy: 'relevance' | 'price_low' | 'price_high' | 'rating' | 'newest' | 'discount';
  searchQuery: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
  duration?: number;
}
