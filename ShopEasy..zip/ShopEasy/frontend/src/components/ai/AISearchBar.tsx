import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Sparkles, X, ArrowRight, Tag, Box } from 'lucide-react';
import { PRODUCTS } from '../../data/products';
import { CATEGORIES } from '../../data/categories';
import { Product } from '../../types';
import { formatPrice } from '../../utils';
import { ProductIdBadge } from '../common/ProductIdBadge';
import { useUI } from '../../context/UIContext';

export const AISearchBar: React.FC = () => {
  const navigate = useNavigate();
  const { openAIAssistant } = useUI();

  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isOpen, setIsOpen] = useState(false);
  const [suggestions, setSuggestions] = useState<Product[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (query.trim().length >= 1) {
      const q = query.toLowerCase().trim();
      const filtered = PRODUCTS.filter((p) => {
        const matchesCategory =
          selectedCategory === 'all' || p.category_code === selectedCategory;
        const matchesText =
          p.product_name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.product_id.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q)) ||
          p.category_name.toLowerCase().includes(q);
        return matchesCategory && matchesText;
      }).slice(0, 5);

      setSuggestions(filtered);
      setIsOpen(true);
    } else {
      setSuggestions([]);
      setIsOpen(false);
    }
  }, [query, selectedCategory]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    // If query looks like a natural language prompt or user wants AI
    const lower = query.toLowerCase();
    if (
      lower.startsWith('find') ||
      lower.startsWith('show') ||
      lower.startsWith('tell') ||
      lower.includes('under') ||
      lower.includes('compare') ||
      lower.includes('best')
    ) {
      openAIAssistant(query);
      setIsOpen(false);
      return;
    }

    setIsOpen(false);
    navigate(`/products?q=${encodeURIComponent(query.trim())}${selectedCategory !== 'all' ? `&category=${selectedCategory}` : ''}`);
  };

  const handleSelectProduct = (productId: string) => {
    setIsOpen(false);
    setQuery('');
    navigate(`/products/${productId}`);
  };

  return (
    <div ref={containerRef} className="relative flex-1 max-w-2xl">
      <form
        onSubmit={handleSearchSubmit}
        className="flex items-center bg-slate-50 hover:bg-white focus-within:bg-white border border-slate-200 focus-within:border-brand-500 rounded-2xl shadow-sm focus-within:shadow-glow transition-all duration-200 overflow-hidden"
      >
        {/* Category selector dropdown */}
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="hidden sm:block text-xs font-semibold text-slate-700 bg-transparent border-r border-slate-200 py-3 pl-3 pr-2 focus:outline-none cursor-pointer"
        >
          <option value="all">All Categories</option>
          {CATEGORIES.map((cat) => (
            <option key={cat.code} value={cat.code}>
              {cat.name}
            </option>
          ))}
        </select>

        {/* Input field */}
        <div className="flex-1 flex items-center px-3 gap-2">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => query.trim().length >= 1 && setIsOpen(true)}
            placeholder="Search products or ask ShopEasy AI..."
            className="w-full bg-transparent text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none py-2.5"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-full"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Ask ShopEasy AI Trigger Button */}
        <button
          type="button"
          onClick={() => openAIAssistant(query || '')}
          title="Open ShopEasy AI Shopping Assistant"
          className="hidden md:flex items-center gap-1.5 px-3 py-1.5 mr-1.5 rounded-xl bg-gradient-to-r from-brand-600 to-accent-600 text-white text-[11px] font-bold shadow-sm hover:shadow-accent-glow transition-all"
        >
          <Sparkles className="w-3 h-3 text-cyan-300 animate-pulse" />
          <span>AI Search</span>
        </button>

        {/* Search Submit button */}
        <button
          type="submit"
          className="px-4 py-3 bg-slate-900 hover:bg-brand-600 text-white transition-colors flex items-center justify-center shrink-0"
        >
          <Search className="w-4 h-4" />
        </button>
      </form>

      {/* Auto-suggest dropdown */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-slate-100 p-3 z-50 animate-slide-up">
          {/* Ask AI quick card */}
          <div
            onClick={() => {
              openAIAssistant(query);
              setIsOpen(false);
            }}
            className="flex items-center justify-between p-2.5 rounded-xl bg-brand-50/70 hover:bg-brand-100/70 border border-brand-100 cursor-pointer transition-colors mb-2 text-xs"
          >
            <div className="flex items-center gap-2 text-brand-900 font-semibold">
              <Sparkles className="w-4 h-4 text-brand-600" />
              <span>Ask ShopEasy AI for: <strong className="text-brand-700 font-bold">"{query}"</strong></span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-brand-600" />
          </div>

          {suggestions.length > 0 ? (
            <div className="space-y-1">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
                Matching Products ({suggestions.length})
              </div>
              {suggestions.map((p) => (
                <div
                  key={p.id}
                  onClick={() => handleSelectProduct(p.product_id)}
                  className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={p.images[0]}
                      alt={p.product_name}
                      className="w-10 h-10 object-cover rounded-lg border border-slate-100 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <ProductIdBadge productId={p.product_id} size="sm" />
                        <span className="text-[10px] font-bold text-brand-600">{p.brand}</span>
                      </div>
                      <p className="text-xs font-semibold text-slate-800 line-clamp-1">
                        {p.product_name}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-extrabold text-slate-900">{formatPrice(p.price)}</span>
                    <span className="block text-[10px] text-emerald-600 font-medium">In Stock</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-xs text-slate-500">
              No direct product name match. Press <kbd className="px-1.5 py-0.5 bg-slate-100 rounded text-slate-700">Enter</kbd> or click <strong>AI Search</strong>.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
