import React, { useState, useEffect, useRef } from 'react';
import { useUI } from '../../context/UIContext';
import { useCart } from '../../context/CartContext';
import { PRODUCTS } from '../../data/products';
import { Product } from '../../types';
import { formatPrice } from '../../utils';
import { ProductIdBadge } from '../common/ProductIdBadge';
import { RatingStars } from '../common/RatingStars';
import {
  Sparkles,
  X,
  Send,
  ShoppingBag,
  Bot,
  User as UserIcon,
  ArrowRight,
  Filter,
  CheckCircle2,
  HelpCircle,
  Flame,
  Search
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  interpretedFilters?: {
    category?: string;
    maxPrice?: number;
    brand?: string;
    features?: string[];
    productIdMatch?: string;
  };
  recommendedProducts?: Product[];
  timestamp: string;
}

const SAMPLE_QUERIES = [
  'black shoes for college',
  'phone under ₹20000',
  'good headphones under ₹3000',
  'gift for my brother',
  'kitchen mixer with good reviews',
  'Tell me about SHP-ELE-000001',
  'Compare SHP-ELE-000001 and SHP-ELE-000002'
];

export const AIAssistantModal: React.FC = () => {
  const { isAIAssistantOpen, closeAIAssistant, aiInitialPrompt, addToast } = useUI();
  const { addToCart } = useCart();

  const [inputQuery, setInputQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-welcome',
      sender: 'ai',
      text: "Hello! I'm ShopEasy AI, your smart personal shopping assistant. Tell me what you're looking for, ask for product recommendations, or type any Product ID (like SHP-ELE-000001) to explore live specs and reviews!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (aiInitialPrompt && isAIAssistantOpen) {
      handleSend(aiInitialPrompt);
    }
  }, [aiInitialPrompt, isAIAssistantOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  if (!isAIAssistantOpen) return null;

  const handleSend = (textToSend?: string) => {
    const query = (textToSend || inputQuery).trim();
    if (!query) return;

    const userMessage: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputQuery('');
    setIsTyping(true);

    // AI Natural Language Reasoning Engine (Client + Grounded in Real Catalog)
    setTimeout(() => {
      const lower = query.toLowerCase();
      let recommended: Product[] = [];
      let filters: Message['interpretedFilters'] = {};
      let responseText = '';

      // 1. Check for specific Product ID lookup (e.g. SHP-ELE-000001)
      const productIdMatch = query.match(/SHP-[A-Z]{3}-\d{6}/i);

      if (productIdMatch) {
        const pId = productIdMatch[0].toUpperCase();
        const found = PRODUCTS.find((p) => p.product_id === pId);
        if (found) {
          filters.productIdMatch = pId;
          recommended = [found];
          responseText = `Found database record for **${pId}** (${found.product_name}). It is in stock at ${formatPrice(found.price)} with a **${found.rating}★** rating based on ${found.review_count} verified reviews.`;
        } else {
          responseText = `I searched the ShopEasy product database for **${pId}**, but I couldn't verify that specific Product ID. Please verify the ID code.`;
        }
      }
      // 2. Budget / Price detection
      else {
        let maxPrice = 999999;
        const priceMatch = lower.match(/(?:under|below|less than|within)\s*(?:₹|rs\.?|inr)?\s*(\d+)/i);
        if (priceMatch && priceMatch[1]) {
          maxPrice = parseInt(priceMatch[1], 10);
          filters.maxPrice = maxPrice;
        }

        // Category matching
        if (lower.includes('shoe') || lower.includes('footwear') || lower.includes('sneaker')) {
          filters.category = 'Footwear';
        } else if (lower.includes('headphone') || lower.includes('audio') || lower.includes('laptop') || lower.includes('electronics')) {
          filters.category = 'Electronics';
        } else if (lower.includes('phone') || lower.includes('mobile') || lower.includes('charger') || lower.includes('powerbank')) {
          filters.category = 'Mobile & Accessories';
        } else if (lower.includes('mixer') || lower.includes('cookware') || lower.includes('kitchen') || lower.includes('air fryer')) {
          filters.category = 'Home & Kitchen';
        } else if (lower.includes('shirt') || lower.includes('dress') || lower.includes('fashion') || lower.includes('jacket')) {
          filters.category = 'Fashion';
        } else if (lower.includes('book') || lower.includes('journal') || lower.includes('diary')) {
          filters.category = 'Books & Stationery';
        } else if (lower.includes('serum') || lower.includes('beauty') || lower.includes('skincare')) {
          filters.category = 'Beauty & Personal Care';
        } else if (lower.includes('watch') || lower.includes('wallet') || lower.includes('accessories')) {
          filters.category = 'Accessories & Watches';
        } else if (lower.includes('gym') || lower.includes('yoga') || lower.includes('sports') || lower.includes('dumbbell')) {
          filters.category = 'Sports & Fitness';
        }

        // Gift queries
        if (lower.includes('gift') || lower.includes('brother')) {
          filters.features = ['Top Rated', 'Popular Gift Choices'];
          recommended = PRODUCTS.filter((p) => p.tags.some((t) => t.includes('gift')) || p.rating >= 4.7).slice(0, 3);
          responseText = `Here are the top-rated gift picks curated for brothers and special occasions from our verified catalog:`;
        } else {
          // Standard intelligent filter match
          recommended = PRODUCTS.filter((p) => {
            let matches = true;
            if (filters?.category && p.category_name !== filters.category && p.category_code !== 'ELE') {
              if (!p.category_name.toLowerCase().includes(filters.category.toLowerCase())) {
                matches = false;
              }
            }
            if (filters?.maxPrice && p.price > filters.maxPrice) {
              matches = false;
            }
            if (lower.includes('black') && !p.product_name.toLowerCase().includes('black') && !p.description.toLowerCase().includes('black') && !p.tags.includes('black')) {
              matches = false;
            }
            if (lower.includes('good reviews') && p.rating < 4.5) {
              matches = false;
            }
            return matches;
          });

          if (recommended.length === 0) {
            // Fallback to keyword match
            recommended = PRODUCTS.filter((p) =>
              p.tags.some((t) => lower.includes(t)) ||
              p.product_name.toLowerCase().includes(lower)
            ).slice(0, 3);
          } else {
            recommended = recommended.slice(0, 3);
          }

          if (recommended.length > 0) {
            responseText = `I analyzed our product database with your requirements. Here are the top matched products:`;
          } else {
            responseText = `I couldn't find exact matches for "${query}". Try searching with a broader category or exploring our trending deals!`;
          }
        }
      }

      const aiResponse: Message = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: responseText,
        interpretedFilters: Object.keys(filters).length > 0 ? filters : undefined,
        recommendedProducts: recommended.length > 0 ? recommended : undefined,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, aiResponse]);
      setIsTyping(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-md animate-fade-in">
      <div className="bg-white w-full max-w-2xl h-[92vh] sm:h-[650px] rounded-3xl shadow-2xl border border-slate-100 flex flex-col overflow-hidden relative animate-slide-up">
        {/* Header */}
        <div className="p-4 sm:px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-brand-500 to-accent-400 p-[1.5px] flex items-center justify-center shadow-accent-glow">
              <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-accent-400 animate-spin" style={{ animationDuration: '6s' }} />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold font-display tracking-tight text-white">
                  ShopEasy AI Assistant
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-accent-500/20 text-accent-400 border border-accent-500/30">
                  Live Grounded Catalog
                </span>
              </div>
              <p className="text-xs text-slate-400">Natural language search & Product ID intelligence</p>
            </div>
          </div>

          <button
            onClick={closeAIAssistant}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Messages Body */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-slate-50/50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-brand-600 text-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-brand-600 text-white rounded-tr-none shadow-sm'
                    : 'bg-white text-slate-800 border border-slate-200/80 rounded-tl-none shadow-sm'
                }`}
              >
                <p className="whitespace-pre-line">{msg.text}</p>

                {/* Interpreted Filters Chip */}
                {msg.interpretedFilters && (
                  <div className="mt-3 p-2.5 bg-brand-50/80 border border-brand-100 rounded-xl text-xs space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-brand-900">
                      <Filter className="w-3.5 h-3.5 text-brand-600" />
                      <span>Interpreted Filters:</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {msg.interpretedFilters.category && (
                        <span className="px-2 py-0.5 bg-white text-brand-700 rounded-md font-medium border border-brand-200">
                          Category: {msg.interpretedFilters.category}
                        </span>
                      )}
                      {msg.interpretedFilters.maxPrice && (
                        <span className="px-2 py-0.5 bg-white text-emerald-700 rounded-md font-medium border border-emerald-200">
                          Max Price: {formatPrice(msg.interpretedFilters.maxPrice)}
                        </span>
                      )}
                      {msg.interpretedFilters.productIdMatch && (
                        <span className="px-2 py-0.5 bg-white text-purple-700 rounded-md font-medium border border-purple-200">
                          ID: {msg.interpretedFilters.productIdMatch}
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {/* Embedded Product Cards in AI response */}
                {msg.recommendedProducts && msg.recommendedProducts.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {msg.recommendedProducts.map((p) => (
                      <div
                        key={p.id}
                        className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200 rounded-xl hover:border-brand-300 transition-colors"
                      >
                        <img
                          src={p.images[0]}
                          alt={p.product_name}
                          className="w-14 h-14 object-cover rounded-lg shrink-0 border border-slate-100"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <ProductIdBadge productId={p.product_id} size="sm" />
                            <span className="text-[10px] font-bold text-brand-600 truncate">{p.brand}</span>
                          </div>
                          <Link
                            to={`/products/${p.product_id}`}
                            onClick={closeAIAssistant}
                            className="text-xs font-bold text-slate-900 hover:text-brand-600 transition-colors truncate block"
                          >
                            {p.product_name}
                          </Link>
                          <div className="flex items-center justify-between gap-2 mt-1">
                            <span className="text-xs font-extrabold text-slate-900">{formatPrice(p.price)}</span>
                            <RatingStars rating={p.rating} size="xs" />
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            addToCart(p, 1);
                            addToast('Added to Cart', `${p.product_name} added to cart`, 'success');
                          }}
                          className="p-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white shadow-sm shrink-0"
                          title="Quick Add to Cart"
                        >
                          <ShoppingBag className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div
                  className={`text-[10px] mt-1.5 ${
                    msg.sender === 'user' ? 'text-brand-200 text-right' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                  <UserIcon className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3 justify-start items-center">
              <div className="w-8 h-8 rounded-xl bg-brand-600 text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3 bg-white rounded-2xl rounded-tl-none border border-slate-200 shadow-sm flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-brand-500 animate-bounce" />
                <div className="w-2 h-2 rounded-full bg-brand-500 animate-bounce [animation-delay:0.2s]" />
                <div className="w-2 h-2 rounded-full bg-brand-500 animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Query Pills */}
        <div className="p-2.5 bg-white border-t border-slate-100 overflow-x-auto flex items-center gap-2 shrink-0">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1 shrink-0 pl-2">
            <Sparkles className="w-3 h-3 text-brand-600" /> Try:
          </span>
          {SAMPLE_QUERIES.map((query, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(query)}
              className="px-3 py-1 bg-slate-100 hover:bg-brand-50 hover:text-brand-700 hover:border-brand-200 border border-slate-200 text-slate-600 rounded-full text-xs shrink-0 transition-all"
            >
              {query}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-white border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask ShopEasy AI (e.g., 'phone under ₹20000', 'SHP-ELE-000001')..."
              className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all"
            />
            <button
              type="submit"
              disabled={!inputQuery.trim()}
              className="p-3 bg-brand-600 hover:bg-brand-700 disabled:opacity-40 text-white rounded-2xl shadow-md hover:shadow-glow transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
