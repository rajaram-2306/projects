import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShoppingBag,
  Heart,
  User as UserIcon,
  Sparkles,
  Menu,
  X,
  LogOut,
  Shield,
  Store,
  ChevronDown,
  CheckCircle2,
  PackageCheck
} from 'lucide-react';
import { AISearchBar } from '../ai/AISearchBar';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useUI } from '../../context/UIContext';
import { formatPrice } from '../../utils';

export const Header: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, logout, switchRole } = useAuth();
  const { totalItemsCount, subtotal } = useCart();
  const { wishlist } = useWishlist();
  const { openAIAssistant, addToast } = useUI();

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setIsUserMenuOpen(false);
    addToast('Logged Out', 'You have been safely logged out.', 'info');
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-sm transition-all">
      {/* Top Announcement Bar */}
      <div className="bg-slate-900 text-slate-300 text-[11px] py-1.5 px-4 hidden sm:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="bg-brand-600 text-white font-bold px-1.5 py-0.5 rounded text-[10px]">
              SPECIAL OFFER
            </span>
            <span>Use code <strong className="text-white font-mono">WELCOME10</strong> for 10% OFF on your first order!</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" /> WhatsApp Verified Checkout
            </span>
            <span>•</span>
            <Link to="/account" className="hover:text-white transition-colors">
              Order Tracking
            </Link>
            <span>•</span>
            <button
              onClick={() => {
                const nextRole = user?.role === 'CUSTOMER' ? 'SELLER' : user?.role === 'SELLER' ? 'ADMIN' : 'CUSTOMER';
                switchRole(nextRole);
                addToast('Role Switched (Demo)', `Active Role: ${nextRole}`, 'info');
              }}
              className="text-[10px] px-2 py-0.5 bg-slate-800 text-accent-400 hover:bg-slate-700 rounded font-semibold border border-slate-700 transition-colors"
              title="Click to cycle role for prototype demonstration"
            >
              Role: {user?.role || 'GUEST'} 🔄
            </button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <Link to="/" className="flex items-center gap-2.5 shrink-0 group">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-brand-600 via-indigo-600 to-accent-500 p-[1.5px] shadow-glow flex items-center justify-center group-hover:scale-105 transition-transform duration-300">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center relative overflow-hidden">
              <ShoppingBag className="w-5 h-5 text-white stroke-[2.2]" />
              <Sparkles className="w-2.5 h-2.5 text-accent-400 absolute top-1.5 right-1.5" />
            </div>
          </div>
          <div>
            <span className="text-xl font-black font-display tracking-tight text-slate-900 block leading-none">
              SHOP<span className="text-brand-600">EASY</span>
            </span>
            <span className="text-[9px] font-bold text-slate-600 tracking-wider block uppercase">
              One Easy Shop
            </span>
          </div>
        </Link>

        {/* AI Smart Search Bar */}
        <AISearchBar />

        {/* Action Icons / User CTA */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* AI Assistant Floating Trigger Button */}
          <button
            onClick={() => openAIAssistant()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-brand-50 to-accent-50 hover:from-brand-100 hover:to-accent-100 text-brand-700 border border-brand-200/80 shadow-sm transition-all duration-200 text-xs font-bold"
            title="Open ShopEasy AI Assistant"
          >
            <Sparkles className="w-4 h-4 text-brand-600 animate-pulse" />
            <span className="hidden lg:inline">Ask AI</span>
          </button>

          {/* Wishlist Link */}
          <Link
            to="/wishlist"
            className="relative p-2.5 rounded-xl hover:bg-slate-100 text-slate-700 hover:text-rose-600 transition-colors"
            title="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlist.length > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center shadow-sm">
                {wishlist.length}
              </span>
            )}
          </Link>

          {/* Cart Link */}
          <Link
            to="/cart"
            className="relative flex items-center gap-2 p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-900 hover:bg-brand-600 text-white shadow-sm hover:shadow-glow transition-all duration-200"
            title="Shopping Cart"
          >
            <div className="relative">
              <ShoppingBag className="w-5 h-5" />
              {totalItemsCount > 0 && (
                <span className="absolute -top-2 -right-2.5 w-4 h-4 rounded-full bg-accent-400 text-slate-950 text-[10px] font-black flex items-center justify-center shadow">
                  {totalItemsCount}
                </span>
              )}
            </div>
            <div className="hidden md:flex flex-col text-left text-xs leading-none">
              <span className="text-[10px] text-slate-300">Cart</span>
              <span className="font-bold text-white mt-0.5">{formatPrice(subtotal)}</span>
            </div>
          </Link>

          {/* Account Dropdown */}
          <div className="relative">
            {isAuthenticated ? (
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-1.5 p-1.5 sm:px-2.5 rounded-xl hover:bg-slate-100 border border-slate-200/80 transition-colors text-xs font-semibold text-slate-800"
              >
                {user?.avatar ? (
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-7 h-7 rounded-lg object-cover border border-slate-200"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-lg bg-brand-100 text-brand-700 flex items-center justify-center font-bold">
                    {user?.name.charAt(0) || 'U'}
                  </div>
                )}
                <span className="hidden md:inline max-w-[80px] truncate">{user?.name}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>
            ) : (
              <div className="flex items-center gap-1.5">
                <Link
                  to="/login"
                  className="px-3.5 py-2 rounded-xl text-xs font-bold text-brand-600 hover:bg-brand-50 border border-brand-200 transition-colors"
                >
                  Sign In
                </Link>
              </div>
            )}

            {/* Dropdown Menu */}
            {isUserMenuOpen && isAuthenticated && (
              <div
                className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 py-2 z-50 animate-slide-up"
                onClick={() => setIsUserMenuOpen(false)}
              >
                <div className="px-4 py-2 border-b border-slate-100">
                  <p className="text-xs font-bold text-slate-900 truncate">{user?.name}</p>
                  <p className="text-[11px] text-slate-500 truncate">{user?.email}</p>
                  <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-600 font-semibold">
                    <CheckCircle2 className="w-3 h-3" /> WhatsApp Verified
                  </div>
                </div>

                <div className="py-1 text-xs">
                  <Link
                    to="/account"
                    className="flex items-center gap-2 px-4 py-2 text-slate-700 hover:bg-slate-50 hover:text-brand-600"
                  >
                    <UserIcon className="w-4 h-4 text-slate-400" /> My Account & Profile
                  </Link>
                  <Link
                    to="/account?tab=orders"
                    className="flex items-center gap-2 px-4 py-2 text-slate-700 hover:bg-slate-50 hover:text-brand-600"
                  >
                    <PackageCheck className="w-4 h-4 text-slate-400" /> My Orders & Tracking
                  </Link>
                  <Link
                    to="/wishlist"
                    className="flex items-center gap-2 px-4 py-2 text-slate-700 hover:bg-slate-50 hover:text-brand-600"
                  >
                    <Heart className="w-4 h-4 text-slate-400" /> Wishlist ({wishlist.length})
                  </Link>

                  {user?.role === 'SELLER' && (
                    <div className="px-4 py-2 bg-amber-50 text-amber-900 font-semibold flex items-center gap-2 my-1">
                      <Store className="w-4 h-4 text-amber-600" /> Seller Dashboard Active
                    </div>
                  )}

                  {user?.role === 'ADMIN' && (
                    <div className="px-4 py-2 bg-purple-50 text-purple-900 font-semibold flex items-center gap-2 my-1">
                      <Shield className="w-4 h-4 text-purple-600" /> Admin Access Mode
                    </div>
                  )}
                </div>

                <div className="pt-1 border-t border-slate-100">
                  <button
                    onClick={handleLogout}
                    className="w-full text-left flex items-center gap-2 px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 font-semibold"
                  >
                    <LogOut className="w-4 h-4" /> Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Mobile Hamburger Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-slate-600 hover:text-slate-900 md:hidden"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-3 animate-fade-in">
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            <Link
              to="/"
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-brand-50 text-slate-800 hover:text-brand-600 text-center"
            >
              Home
            </Link>
            <Link
              to="/products"
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-brand-50 text-slate-800 hover:text-brand-600 text-center"
            >
              All Products
            </Link>
            <Link
              to="/products?deal=true"
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-brand-50 text-slate-800 hover:text-brand-600 text-center"
            >
              Today's Deals
            </Link>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                openAIAssistant();
              }}
              className="p-2.5 rounded-xl bg-brand-50 text-brand-700 text-center font-bold flex items-center justify-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-brand-600" /> Ask AI
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
