import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { CATEGORIES } from '../../data/categories';
import {
  Sparkles,
  Flame,
  Zap,
  Grid,
  Laptop,
  Smartphone,
  Shirt,
  HeartHandshake,
  Home,
  ShoppingBag,
  BookOpen,
  Trophy,
  Footprints,
  Watch
} from 'lucide-react';
import { useUI } from '../../context/UIContext';

const ICON_MAP: Record<string, React.ReactNode> = {
  Laptop: <Laptop className="w-3.5 h-3.5" />,
  Smartphone: <Smartphone className="w-3.5 h-3.5" />,
  Shirt: <Shirt className="w-3.5 h-3.5" />,
  Sparkles: <Sparkles className="w-3.5 h-3.5" />,
  Home: <Home className="w-3.5 h-3.5" />,
  ShoppingBag: <ShoppingBag className="w-3.5 h-3.5" />,
  BookOpen: <BookOpen className="w-3.5 h-3.5" />,
  Trophy: <Trophy className="w-3.5 h-3.5" />,
  Footprints: <Footprints className="w-3.5 h-3.5" />,
  Watch: <Watch className="w-3.5 h-3.5" />
};

export const Navbar: React.FC = () => {
  const location = useLocation();
  const { openAIAssistant } = useUI();

  return (
    <nav className="bg-slate-900 text-white text-xs border-b border-slate-800 overflow-x-auto scrollbar-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-1 sm:gap-2 py-2 whitespace-nowrap">
        {/* All Products Link */}
        <Link
          to="/products"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold hover:bg-slate-800 text-slate-200 hover:text-white transition-colors"
        >
          <Grid className="w-3.5 h-3.5 text-brand-400" />
          <span>All Products</span>
        </Link>

        {/* AI Assistant Special Chip */}
        <button
          onClick={() => openAIAssistant()}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold bg-gradient-to-r from-brand-600/60 to-accent-600/60 hover:from-brand-600 hover:to-accent-600 text-cyan-200 hover:text-white border border-cyan-500/30 transition-all"
        >
          <Sparkles className="w-3.5 h-3.5 text-accent-400 animate-pulse" />
          <span>AI Assistant</span>
        </button>

        {/* Deals */}
        <Link
          to="/products?deal=true"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold text-amber-400 hover:bg-slate-800 transition-colors"
        >
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>Today's Deals</span>
        </Link>

        {/* Trending */}
        <Link
          to="/products?trending=true"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold text-rose-400 hover:bg-slate-800 transition-colors"
        >
          <Flame className="w-3.5 h-3.5 text-rose-400" />
          <span>Trending</span>
        </Link>

        <span className="text-slate-700">|</span>

        {/* Dynamic Category Chips */}
        {CATEGORIES.map((cat) => {
          const isActive = location.search.includes(`category=${cat.code}`);
          return (
            <Link
              key={cat.code}
              to={`/products?category=${cat.code}`}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-colors font-medium ${
                isActive
                  ? 'bg-brand-600 text-white font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span className="text-slate-400">{ICON_MAP[cat.icon] || <ShoppingBag className="w-3.5 h-3.5" />}</span>
              <span>{cat.name}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};
