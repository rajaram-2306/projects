import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Grid, Sparkles, Heart, ShoppingBag, User } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useUI } from '../../context/UIContext';

export const MobileNav: React.FC = () => {
  const location = useLocation();
  const { totalItemsCount } = useCart();
  const { wishlist } = useWishlist();
  const { openAIAssistant } = useUI();

  const navItems = [
    { label: 'Home', path: '/', icon: <Home className="w-5 h-5" /> },
    { label: 'Explore', path: '/products', icon: <Grid className="w-5 h-5" /> },
    { label: 'Wishlist', path: '/wishlist', icon: <Heart className="w-5 h-5" />, badge: wishlist.length },
    { label: 'Cart', path: '/cart', icon: <ShoppingBag className="w-5 h-5" />, badge: totalItemsCount },
    { label: 'Account', path: '/account', icon: <User className="w-5 h-5" /> },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-slate-200 py-1.5 px-3 flex items-center justify-around shadow-2xl">
      {navItems.map((item, index) => {
        const isActive = location.pathname === item.path;

        return (
          <Link
            key={index}
            to={item.path}
            className={`flex flex-col items-center justify-center py-1 px-2 relative transition-colors ${
              isActive ? 'text-brand-600 font-bold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <div className="relative">
              {item.icon}
              {Boolean(item.badge && item.badge > 0) && (
                <span className="absolute -top-1 -right-2 bg-rose-500 text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {item.badge}
                </span>
              )}
            </div>
            <span className="text-[10px] mt-0.5">{item.label}</span>
          </Link>
        );
      })}

      {/* Floating Center AI Action Button on mobile */}
      <button
        onClick={() => openAIAssistant()}
        className="flex flex-col items-center justify-center py-1 px-2 text-brand-600"
        title="Ask ShopEasy AI"
      >
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-brand-600 to-accent-500 text-white flex items-center justify-center shadow-md">
          <Sparkles className="w-4 h-4" />
        </div>
        <span className="text-[10px] mt-0.5 font-bold">Ask AI</span>
      </button>
    </div>
  );
};
