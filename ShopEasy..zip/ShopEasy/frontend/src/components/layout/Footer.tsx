import React from 'react';
import { Link } from 'react-router-dom';
import {
  ShoppingBag,
  Sparkles,
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  CheckCircle2,
  Lock,
  Mail,
  ArrowRight
} from 'lucide-react';
import { CATEGORIES } from '../../data/categories';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      {/* Trust Badges Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 mb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-6 sm:p-8 bg-slate-900/80 rounded-3xl border border-slate-800 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-brand-500/10 text-brand-400 flex items-center justify-center shrink-0 border border-brand-500/20">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Free & Fast Delivery</h4>
              <p className="text-xs text-slate-400">On all eligible orders over ₹499</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/20">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">WhatsApp OTP Verified</h4>
              <p className="text-xs text-slate-400">Instant secure mobile verification</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-accent-500/10 text-accent-400 flex items-center justify-center shrink-0 border border-accent-500/20">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">ShopEasy AI Assistant</h4>
              <p className="text-xs text-slate-400">Smart comparison & live search</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0 border border-purple-500/20">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">7 Days Easy Return</h4>
              <p className="text-xs text-slate-400">Hassle-free replacement policy</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800/80">
        {/* Brand Information */}
        <div className="lg:col-span-2 space-y-4">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-brand-500 via-indigo-600 to-accent-400 p-[1.5px] flex items-center justify-center shadow-glow">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
            </div>
            <div>
              <span className="text-2xl font-black font-display tracking-tight text-white block leading-none">
                SHOP<span className="text-brand-400">EASY</span>
              </span>
              <span className="text-[10px] font-bold text-slate-500 tracking-wider block uppercase">
                One Easy Shop
              </span>
            </div>
          </Link>

          <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-sm">
            Everything You Need. One Easy Shop. ShopEasy is a modern AI-powered e-commerce ecosystem bringing you intelligent recommendations, natural search, verified authentic sellers, and instant order tracking.
          </p>

          <div className="pt-2">
            <p className="text-xs font-semibold text-slate-300 mb-2">Subscribe for Exclusive Deals</p>
            <form onSubmit={(e) => e.preventDefault()} className="flex items-center max-w-sm gap-2">
              <div className="relative flex-1">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-brand-500"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold transition-colors"
              >
                Join
              </button>
            </form>
          </div>
        </div>

        {/* Quick Categories */}
        <div>
          <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 font-display">
            Top Categories
          </h4>
          <ul className="space-y-2 text-xs text-slate-400">
            {CATEGORIES.slice(0, 6).map((cat) => (
              <li key={cat.code}>
                <Link
                  to={`/products?category=${cat.code}`}
                  className="hover:text-brand-400 transition-colors"
                >
                  {cat.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Customer Care */}
        <div>
          <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 font-display">
            Customer Care
          </h4>
          <ul className="space-y-2 text-xs text-slate-400">
            <li>
              <Link to="/account?tab=orders" className="hover:text-brand-400 transition-colors">
                Track My Order
              </Link>
            </li>
            <li>
              <Link to="/account" className="hover:text-brand-400 transition-colors">
                Manage Account
              </Link>
            </li>
            <li>
              <Link to="/cart" className="hover:text-brand-400 transition-colors">
                Shopping Cart
              </Link>
            </li>
            <li>
              <Link to="/wishlist" className="hover:text-brand-400 transition-colors">
                Wishlist
              </Link>
            </li>
            <li>
              <span className="hover:text-brand-400 cursor-pointer">Help Center & FAQs</span>
            </li>
            <li>
              <span className="hover:text-brand-400 cursor-pointer">Return Policy</span>
            </li>
          </ul>
        </div>

        {/* Business & Legal */}
        <div>
          <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 font-display">
            Seller & Partner
          </h4>
          <ul className="space-y-2 text-xs text-slate-400">
            <li>
              <Link to="/register?type=seller" className="text-brand-400 font-semibold hover:underline">
                Become a Seller (Portal)
              </Link>
            </li>
            <li>
              <Link to="/login" className="hover:text-brand-400 transition-colors">
                Seller Login
              </Link>
            </li>
            <li>
              <span className="hover:text-brand-400 cursor-pointer">Affiliate Program</span>
            </li>
            <li>
              <span className="hover:text-brand-400 cursor-pointer">Privacy Policy</span>
            </li>
            <li>
              <span className="hover:text-brand-400 cursor-pointer">Terms of Service</span>
            </li>
            <li>
              <span className="hover:text-brand-400 cursor-pointer">Security Standards</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Copyright Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <p>© {new Date().getFullYear()} ShopEasy Inc. All Rights Reserved. Everything You Need. One Easy Shop.</p>
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-1">
            <Lock className="w-3.5 h-3.5 text-emerald-500" /> 256-Bit SSL Encrypted
          </span>
          <span>•</span>
          <span>Unique Product ID Integrity (SHP-CAT-XXXXXX)</span>
        </div>
      </div>
    </footer>
  );
};
