import React, { useState } from 'react';
import { X, ShoppingBag, Heart, Check, ArrowRight, ShieldCheck, Truck, RotateCcw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useUI } from '../../context/UIContext';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { formatPrice } from '../../utils';
import { RatingStars } from '../common/RatingStars';
import { ProductIdBadge } from '../common/ProductIdBadge';
import { Badge } from '../common/Badge';

export const QuickViewModal: React.FC = () => {
  const { quickViewProduct, closeQuickView, addToast } = useUI();
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);

  if (!quickViewProduct) return null;

  const isWishlisted = isInWishlist(quickViewProduct.id);

  const handleAddToCart = () => {
    addToCart(quickViewProduct, quantity);
    addToast('Added to Cart', `${quantity}x ${quickViewProduct.product_name} added to cart`, 'success');
    closeQuickView();
  };

  const handleWishlist = () => {
    toggleWishlist(quickViewProduct);
    if (!isWishlisted) {
      addToast('Saved to Wishlist', `${quickViewProduct.product_name} saved to wishlist`, 'info');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div
        className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col md:flex-row max-h-[90vh] relative animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={closeQuickView}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors shadow-sm"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Media Gallery */}
        <div className="w-full md:w-1/2 p-6 bg-slate-50 flex flex-col justify-between">
          <div className="aspect-square rounded-2xl overflow-hidden bg-white border border-slate-100 mb-3 shadow-inner">
            <img
              src={quickViewProduct.images[selectedImageIndex] || quickViewProduct.images[0]}
              alt={quickViewProduct.product_name}
              className="w-full h-full object-cover"
            />
          </div>

          {quickViewProduct.images.length > 1 && (
            <div className="flex gap-2 justify-center">
              {quickViewProduct.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-14 h-14 rounded-xl overflow-hidden border-2 transition-all ${
                    selectedImageIndex === idx
                      ? 'border-brand-600 shadow-sm scale-105'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Information */}
        <div className="w-full md:w-1/2 p-6 flex flex-col overflow-y-auto">
          {/* Category, Brand & ID */}
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs font-bold text-brand-600 uppercase tracking-wider">
              {quickViewProduct.brand}
            </span>
            <ProductIdBadge productId={quickViewProduct.product_id} size="sm" />
          </div>

          <h2 className="text-lg font-bold text-slate-900 font-display leading-snug mb-2">
            {quickViewProduct.product_name}
          </h2>

          <div className="flex items-center gap-3 mb-4">
            <RatingStars rating={quickViewProduct.rating} reviewCount={quickViewProduct.review_count} showCount size="sm" />
            <span className="text-slate-300">•</span>
            <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
              <Check className="w-3.5 h-3.5" /> In Stock ({quickViewProduct.stock_quantity})
            </span>
          </div>

          {/* Price Block */}
          <div className="p-3.5 bg-slate-50 rounded-2xl mb-4 border border-slate-100">
            <div className="flex items-baseline gap-2.5">
              <span className="text-2xl font-extrabold text-slate-900 font-display">
                {formatPrice(quickViewProduct.price)}
              </span>
              {quickViewProduct.original_price > quickViewProduct.price && (
                <span className="text-sm text-slate-400 line-through">
                  {formatPrice(quickViewProduct.original_price)}
                </span>
              )}
              {quickViewProduct.discount > 0 && (
                <Badge variant="discount" discountPercent={quickViewProduct.discount} />
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">Inclusive of all taxes. Free delivery on orders over ₹499.</p>
          </div>

          <p className="text-xs text-slate-600 line-clamp-3 mb-4 leading-relaxed">
            {quickViewProduct.short_description || quickViewProduct.description}
          </p>

          {/* Highlights */}
          {quickViewProduct.highlights && quickViewProduct.highlights.length > 0 && (
            <div className="mb-4">
              <h4 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">Key Highlights</h4>
              <ul className="space-y-1">
                {quickViewProduct.highlights.slice(0, 3).map((item, index) => (
                  <li key={index} className="text-xs text-slate-600 flex items-start gap-1.5">
                    <Check className="w-3.5 h-3.5 text-brand-600 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Quantity & Actions */}
          <div className="mt-auto space-y-3 pt-4 border-t border-slate-100">
            <div className="flex items-center gap-3">
              <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 transition-colors font-bold text-sm"
                >
                  -
                </button>
                <span className="px-3 py-1.5 text-xs font-bold text-slate-900">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => Math.min(quickViewProduct.stock_quantity, q + 1))}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 transition-colors font-bold text-sm"
                >
                  +
                </button>
              </div>

              <button
                onClick={handleAddToCart}
                className="flex-1 py-2.5 px-4 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-md hover:shadow-glow flex items-center justify-center gap-2 transition-all"
              >
                <ShoppingBag className="w-4 h-4" /> Add to Cart
              </button>

              <button
                onClick={handleWishlist}
                className={`p-2.5 rounded-xl border transition-colors ${
                  isWishlisted ? 'bg-rose-50 border-rose-200 text-rose-500' : 'border-slate-200 text-slate-600 hover:border-rose-200 hover:text-rose-500'
                }`}
                title="Wishlist"
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            <Link
              to={`/products/${quickViewProduct.product_id}`}
              onClick={closeQuickView}
              className="flex items-center justify-center gap-1.5 text-xs font-semibold text-brand-600 hover:text-brand-700 transition-colors py-1"
            >
              <span>View Full Product Specifications & Reviews</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
