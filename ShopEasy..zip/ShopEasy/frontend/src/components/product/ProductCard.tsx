import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, Eye, Scale, Check } from 'lucide-react';
import { Product } from '../../types';
import { formatPrice } from '../../utils';
import { RatingStars } from '../common/RatingStars';
import { ProductIdBadge } from '../common/ProductIdBadge';
import { Badge } from '../common/Badge';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useUI } from '../../context/UIContext';

interface ProductCardProps {
  product: Product;
  viewMode?: 'grid' | 'list';
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, viewMode = 'grid' }) => {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { openQuickView, addToCompare, compareList, addToast } = useUI();

  const isWishlisted = isInWishlist(product.id);
  const isCompared = compareList.some((p) => p.id === product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
    addToast('Added to Cart', `${product.product_name} added to your shopping cart`, 'success');
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product);
    if (!isWishlisted) {
      addToast('Saved to Wishlist', `${product.product_name} saved to wishlist`, 'info');
    }
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    openQuickView(product);
  };

  const handleCompare = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCompare(product);
  };

  if (viewMode === 'list') {
    return (
      <div className="group bg-white rounded-2xl border border-slate-100 hover:border-brand-200 p-4 shadow-sm hover:shadow-soft transition-all duration-300 flex flex-col md:flex-row gap-5">
        {/* Product Image */}
        <div className="relative w-full md:w-48 aspect-square md:aspect-auto rounded-xl overflow-hidden bg-slate-50 shrink-0">
          <Link to={`/products/${product.product_id}`}>
            <img
              src={product.images[0]}
              alt={product.product_name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              loading="lazy"
            />
          </Link>
          {product.discount > 0 && (
            <div className="absolute top-2.5 left-2.5">
              <Badge variant="discount" discountPercent={product.discount} />
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-1.5 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-brand-600 uppercase tracking-wider">
                  {product.brand}
                </span>
                <span className="text-slate-300">•</span>
                <span className="text-xs text-slate-500">{product.category_name}</span>
              </div>
              <ProductIdBadge productId={product.product_id} size="sm" />
            </div>

            <Link
              to={`/products/${product.product_id}`}
              className="text-base font-bold text-slate-900 hover:text-brand-600 transition-colors line-clamp-2 mb-2 font-display"
            >
              {product.product_name}
            </Link>

            <p className="text-xs text-slate-500 line-clamp-2 mb-3 leading-relaxed">
              {product.short_description}
            </p>

            <div className="flex items-center gap-4 mb-3">
              <RatingStars rating={product.rating} reviewCount={product.review_count} showCount size="sm" />
              {product.stock_quantity <= 5 ? (
                <span className="text-xs font-semibold text-rose-600">
                  Only {product.stock_quantity} left in stock!
                </span>
              ) : (
                <span className="text-xs font-medium text-emerald-600 flex items-center gap-1">
                  <Check className="w-3 h-3" /> In Stock
                </span>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-extrabold text-slate-900">
                {formatPrice(product.price)}
              </span>
              {product.original_price > product.price && (
                <span className="text-sm text-slate-400 line-through">
                  {formatPrice(product.original_price)}
                </span>
              )}
              <span className="text-xs font-bold text-emerald-600">
                {product.discount}% OFF
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCompare}
                className={`p-2.5 rounded-xl border transition-colors ${
                  isCompared ? 'bg-brand-50 border-brand-300 text-brand-600' : 'border-slate-200 text-slate-600 hover:border-brand-300 hover:text-brand-600'
                }`}
                title="Add to Compare"
              >
                <Scale className="w-4 h-4" />
              </button>
              <button
                onClick={handleWishlist}
                className={`p-2.5 rounded-xl border transition-colors ${
                  isWishlisted ? 'bg-rose-50 border-rose-200 text-rose-500' : 'border-slate-200 text-slate-600 hover:border-rose-200 hover:text-rose-500'
                }`}
                title="Save to Wishlist"
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
              <button
                onClick={handleAddToCart}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-sm hover:shadow-glow transition-all"
              >
                <ShoppingBag className="w-4 h-4" /> Add to Cart
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group bg-white rounded-2xl border border-slate-100 hover:border-brand-200 p-3.5 shadow-sm hover:shadow-soft transition-all duration-300 flex flex-col h-full relative">
      {/* Top badges & action buttons container */}
      <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-slate-50 mb-3">
        <Link to={`/products/${product.product_id}`} className="block w-full h-full">
          <img
            src={product.images[0]}
            alt={product.product_name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        </Link>

        {/* Floating tags */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {product.discount > 0 && (
            <Badge variant="discount" discountPercent={product.discount} />
          )}
          {product.is_bestseller && (
            <Badge variant="bestseller">Bestseller</Badge>
          )}
          {product.is_deal && (
            <Badge variant="deal">Hot Deal</Badge>
          )}
        </div>

        {/* Top Right Wishlist & Quick action buttons */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-10">
          <button
            onClick={handleWishlist}
            className={`p-2 rounded-full backdrop-blur-md transition-all duration-200 shadow-sm ${
              isWishlisted
                ? 'bg-rose-500 text-white'
                : 'bg-white/80 hover:bg-white text-slate-600 hover:text-rose-500'
            }`}
            title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
          </button>
          <button
            onClick={handleQuickView}
            className="p-2 rounded-full bg-white/80 hover:bg-white text-slate-600 hover:text-brand-600 backdrop-blur-md transition-all duration-200 shadow-sm opacity-0 group-hover:opacity-100 hidden sm:block"
            title="Quick View"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Brand & Product ID Bar */}
      <div className="flex items-center justify-between gap-1.5 mb-1.5">
        <span className="text-[11px] font-bold text-brand-600 uppercase tracking-wider truncate">
          {product.brand}
        </span>
        <ProductIdBadge productId={product.product_id} size="sm" />
      </div>

      {/* Product Title */}
      <Link
        to={`/products/${product.product_id}`}
        className="text-sm font-bold text-slate-800 hover:text-brand-600 transition-colors line-clamp-2 mb-2 leading-snug font-display flex-grow"
        title={product.product_name}
      >
        {product.product_name}
      </Link>

      {/* Rating & Reviews */}
      <div className="mb-3">
        <RatingStars rating={product.rating} reviewCount={product.review_count} showCount size="xs" />
      </div>

      {/* Price & Stock Section */}
      <div className="mt-auto pt-2.5 border-t border-slate-100">
        <div className="flex items-baseline gap-1.5 mb-2.5">
          <span className="text-lg font-extrabold text-slate-900">
            {formatPrice(product.price)}
          </span>
          {product.original_price > product.price && (
            <span className="text-xs text-slate-400 line-through">
              {formatPrice(product.original_price)}
            </span>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleAddToCart}
            className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-900 hover:bg-brand-600 text-white text-xs font-semibold shadow-sm hover:shadow-glow transition-all duration-200"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            Add to Cart
          </button>
          <button
            onClick={handleCompare}
            className={`p-2 rounded-xl border transition-colors ${
              isCompared
                ? 'bg-brand-50 border-brand-300 text-brand-600'
                : 'border-slate-200 hover:border-brand-300 text-slate-500 hover:text-brand-600'
            }`}
            title="Compare Product"
          >
            <Scale className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
