import React from 'react';
import { Product } from '../../types';
import { ProductCard } from './ProductCard';
import { SkeletonCard } from '../common/SkeletonCard';
import { EmptyState } from '../common/EmptyState';

interface ProductGridProps {
  products: Product[];
  isLoading?: boolean;
  skeletonCount?: number;
  viewMode?: 'grid' | 'list';
  emptyTitle?: string;
  emptyDescription?: string;
  onClearFilters?: () => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  isLoading = false,
  skeletonCount = 8,
  viewMode = 'grid',
  emptyTitle = 'No Products Found',
  emptyDescription = 'We couldn’t find any products matching your selected criteria. Try adjusting your filters or search terms.',
  onClearFilters,
}) => {
  if (isLoading) {
    return (
      <div className={`grid gap-4 md:gap-6 ${
        viewMode === 'list'
          ? 'grid-cols-1'
          : 'grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4'
      }`}>
        {Array.from({ length: skeletonCount }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <EmptyState
        title={emptyTitle}
        description={emptyDescription}
        actionText={onClearFilters ? 'Clear All Filters' : 'Browse All Products'}
        actionHref={onClearFilters ? undefined : '/products'}
        onAction={onClearFilters}
      />
    );
  }

  return (
    <div className={`grid gap-4 md:gap-6 ${
      viewMode === 'list'
        ? 'grid-cols-1'
        : 'grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4'
    }`}>
      {products.map((product) => (
        <ProductCard key={product.id} product={product} viewMode={viewMode} />
      ))}
    </div>
  );
};
