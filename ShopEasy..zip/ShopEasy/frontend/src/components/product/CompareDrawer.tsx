import React, { useState } from 'react';
import { useUI } from '../../context/UIContext';
import { useCart } from '../../context/CartContext';
import { X, Scale, ShoppingBag, ArrowRight, Check } from 'lucide-react';
import { formatPrice } from '../../utils';
import { ProductIdBadge } from '../common/ProductIdBadge';
import { RatingStars } from '../common/RatingStars';

export const CompareDrawer: React.FC = () => {
  const { compareList, removeFromCompare, clearCompare, isCompareOpen, setIsCompareOpen, addToast } = useUI();
  const { addToCart } = useCart();
  const [showFullModal, setShowFullModal] = useState(false);

  if (compareList.length === 0) return null;

  // Extract all unique specification keys across compared products
  const allSpecKeys = Array.from(
    new Set(compareList.flatMap((p) => Object.keys(p.specifications || {})))
  );

  return (
    <>
      {/* Floating Bottom Comparison Bar */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 bg-slate-900/95 text-white backdrop-blur-md px-5 py-3 rounded-2xl shadow-2xl border border-slate-700/60 flex items-center gap-4 max-w-4xl w-[92%] sm:w-auto animate-slide-up">
        <div className="flex items-center gap-2 pr-3 border-r border-slate-700">
          <div className="p-2 rounded-xl bg-brand-600/30 text-brand-400">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold font-display">Compare ({compareList.length}/4)</h4>
            <p className="text-[10px] text-slate-400 hidden sm:block">Side-by-side specs</p>
          </div>
        </div>

        {/* Mini Product Thumbnails */}
        <div className="flex items-center gap-2 overflow-x-auto py-1">
          {compareList.map((product) => (
            <div
              key={product.id}
              className="relative group bg-slate-800 rounded-xl p-1 border border-slate-700 flex items-center gap-2 pr-3 shrink-0"
            >
              <img
                src={product.images[0]}
                alt={product.product_name}
                className="w-9 h-9 object-cover rounded-lg"
              />
              <div className="max-w-[100px] hidden md:block">
                <p className="text-[10px] font-semibold truncate">{product.product_name}</p>
                <p className="text-[10px] text-brand-400 font-bold">{formatPrice(product.price)}</p>
              </div>
              <button
                onClick={() => removeFromCompare(product.id)}
                className="p-1 text-slate-400 hover:text-rose-400 transition-colors"
                title="Remove"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Action CTAs */}
        <div className="flex items-center gap-2 ml-auto">
          <button
            onClick={() => setShowFullModal(true)}
            className="px-3.5 py-1.5 bg-gradient-to-r from-brand-500 to-accent-500 hover:opacity-95 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition-all"
          >
            <span>Compare Now</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={clearCompare}
            className="text-xs text-slate-400 hover:text-slate-200 p-1.5 transition-colors"
            title="Clear all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Full Comparison Table Modal */}
      {showFullModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-brand-100 text-brand-600">
                  <Scale className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 font-display">
                    Product Specification Comparison
                  </h3>
                  <p className="text-xs text-slate-500">
                    Comparing {compareList.length} items side-by-side with live database specs
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowFullModal(false)}
                className="p-2 rounded-full hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Table Content */}
            <div className="p-6 overflow-auto flex-1">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="p-4 w-1/4 text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Feature
                    </th>
                    {compareList.map((product) => (
                      <th key={product.id} className="p-4 w-1/4 align-top">
                        <div className="flex flex-col items-start gap-2">
                          <img
                            src={product.images[0]}
                            alt={product.product_name}
                            className="w-24 h-24 object-cover rounded-xl border border-slate-100 mb-1"
                          />
                          <ProductIdBadge productId={product.product_id} size="sm" />
                          <span className="text-xs font-bold text-brand-600">{product.brand}</span>
                          <h4 className="text-sm font-bold text-slate-900 line-clamp-2 leading-snug">
                            {product.product_name}
                          </h4>
                          <div className="text-base font-extrabold text-slate-900">
                            {formatPrice(product.price)}
                          </div>
                          <button
                            onClick={() => {
                              addToCart(product, 1);
                              addToast('Added to Cart', `${product.product_name} added to cart`, 'success');
                            }}
                            className="w-full py-2 px-3 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" /> Add to Cart
                          </button>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  <tr>
                    <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Rating & Reviews</td>
                    {compareList.map((p) => (
                      <td key={p.id} className="p-4">
                        <RatingStars rating={p.rating} reviewCount={p.review_count} showCount size="xs" />
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Category</td>
                    {compareList.map((p) => (
                      <td key={p.id} className="p-4 text-slate-600">
                        {p.category_name} ({p.subcategory_name})
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Availability</td>
                    {compareList.map((p) => (
                      <td key={p.id} className="p-4 font-medium text-emerald-600">
                        {p.stock_quantity > 0 ? `In Stock (${p.stock_quantity})` : 'Out of Stock'}
                      </td>
                    ))}
                  </tr>
                  {/* Dynamic Specifications */}
                  {allSpecKeys.map((key) => (
                    <tr key={key}>
                      <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">{key}</td>
                      {compareList.map((p) => (
                        <td key={p.id} className="p-4 text-slate-600">
                          {p.specifications?.[key] || '—'}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
