import React from 'react';
import { PackageOpen } from 'lucide-react';
import { Button } from './Button';
import { useNavigate } from 'react-router-dom';

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  actionText?: string;
  actionHref?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionText,
  actionHref,
  onAction
}) => {
  const navigate = useNavigate();

  const handleAction = () => {
    if (onAction) {
      onAction();
    } else if (actionHref) {
      navigate(actionHref);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-12 text-center bg-white rounded-3xl border border-slate-100 shadow-sm max-w-lg mx-auto my-8">
      <div className="w-20 h-20 bg-brand-50 text-brand-600 rounded-3xl flex items-center justify-center mb-6 shadow-inner">
        {icon || <PackageOpen className="w-10 h-10 stroke-[1.5]" />}
      </div>
      <h3 className="text-xl font-bold text-slate-900 font-display mb-2">{title}</h3>
      <p className="text-slate-500 text-sm mb-6 max-w-sm leading-relaxed">{description}</p>
      {actionText && (
        <Button variant="primary" onClick={handleAction}>
          {actionText}
        </Button>
      )}
    </div>
  );
};
