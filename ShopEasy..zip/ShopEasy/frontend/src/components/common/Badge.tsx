import React from 'react';
import { Sparkles, Zap, Flame, ShieldCheck } from 'lucide-react';

interface BadgeProps {
  variant?: 'discount' | 'stock' | 'low-stock' | 'out-of-stock' | 'deal' | 'trending' | 'bestseller' | 'ai' | 'verified';
  children?: React.ReactNode;
  discountPercent?: number;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  variant = 'deal',
  children,
  discountPercent,
  className = '',
}) => {
  if (variant === 'discount' && discountPercent) {
    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-rose-500 text-white shadow-sm ${className}`}>
        {discountPercent}% OFF
      </span>
    );
  }

  const styles = {
    'deal': 'bg-amber-100 text-amber-900 border-amber-200',
    'trending': 'bg-purple-100 text-purple-900 border-purple-200',
    'bestseller': 'bg-brand-100 text-brand-900 border-brand-200',
    'ai': 'bg-gradient-to-r from-brand-600 to-accent-600 text-white border-transparent shadow-sm',
    'verified': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'stock': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'low-stock': 'bg-rose-50 text-rose-700 border-rose-200',
    'out-of-stock': 'bg-slate-100 text-slate-500 border-slate-200',
    'discount': 'bg-rose-500 text-white border-transparent'
  };

  let icon = null;
  if (variant === 'deal') icon = <Zap className="w-3 h-3 text-amber-600 mr-1" />;
  if (variant === 'trending') icon = <Flame className="w-3 h-3 text-rose-500 mr-1" />;
  if (variant === 'ai') icon = <Sparkles className="w-3 h-3 text-white mr-1 animate-pulse" />;
  if (variant === 'verified') icon = <ShieldCheck className="w-3 h-3 text-emerald-600 mr-1" />;

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-[11px] font-semibold border ${styles[variant]} ${className}`}>
      {icon}
      {children}
    </span>
  );
};
