import React from 'react';

export const SkeletonCard: React.FC = () => {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm flex flex-col h-full animate-pulse">
      {/* Image box skeleton */}
      <div className="w-full aspect-square bg-slate-200 rounded-xl mb-4" />

      {/* Product ID & Brand skeleton */}
      <div className="flex items-center justify-between mb-2">
        <div className="h-4 w-20 bg-slate-200 rounded" />
        <div className="h-4 w-16 bg-slate-200 rounded" />
      </div>

      {/* Product Name skeleton */}
      <div className="h-4 bg-slate-200 rounded w-full mb-2" />
      <div className="h-4 bg-slate-200 rounded w-2/3 mb-3" />

      {/* Rating skeleton */}
      <div className="h-4 w-24 bg-slate-200 rounded mb-4" />

      {/* Price & button skeleton */}
      <div className="mt-auto pt-3 border-t border-slate-100 flex items-center justify-between">
        <div className="h-6 w-20 bg-slate-200 rounded" />
        <div className="h-9 w-24 bg-slate-200 rounded-xl" />
      </div>
    </div>
  );
};
