import React from 'react';
import { Sparkles, ShoppingBag } from 'lucide-react';

interface LoadingScreenProps {
  onDismiss?: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onDismiss }) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-white overflow-hidden transition-opacity duration-500">
      {/* Dynamic Background Glow Elements */}
      <div className="absolute w-96 h-96 bg-brand-600/20 rounded-full blur-3xl animate-pulse pointer-events-none -top-20 -left-20" />
      <div className="absolute w-96 h-96 bg-accent-500/15 rounded-full blur-3xl animate-pulse pointer-events-none -bottom-20 -right-20" />
      
      {/* Center Branding Card */}
      <div className="relative z-10 flex flex-col items-center max-w-md px-6 text-center animate-fade-in">
        {/* Animated Brand Logo Icon */}
        <div className="relative mb-6">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-brand-600 via-indigo-600 to-accent-500 p-[2px] shadow-glow flex items-center justify-center animate-bounce">
            <div className="w-full h-full bg-slate-900 rounded-[22px] flex items-center justify-center relative overflow-hidden">
              <ShoppingBag className="w-11 h-11 text-white stroke-[2.2]" />
              <div className="absolute top-2 right-2 p-1 bg-accent-500/20 rounded-full">
                <Sparkles className="w-4 h-4 text-accent-400 animate-spin" style={{ animationDuration: '4s' }} />
              </div>
            </div>
          </div>
          {/* Pulsing ring around logo */}
          <div className="absolute -inset-2 rounded-[28px] border border-brand-500/30 animate-ping pointer-events-none" style={{ animationDuration: '2.5s' }} />
        </div>

        {/* Brand Name */}
        <h1 className="text-4xl font-extrabold tracking-tight font-display text-white mb-2 flex items-center gap-2">
          SHOP <span className="bg-clip-text text-transparent bg-gradient-to-r from-accent-400 to-brand-400">EASY</span>
        </h1>

        {/* Tagline */}
        <p className="text-slate-300 font-medium text-base mb-8 tracking-wide">
          Everything You Need. <span className="text-accent-400 font-semibold">One Easy Shop.</span>
        </p>

        {/* Animated Progress Bar */}
        <div className="w-64 h-1.5 bg-slate-800 rounded-full overflow-hidden mb-4 relative">
          <div className="h-full bg-gradient-to-r from-brand-500 via-accent-400 to-indigo-400 rounded-full animate-pulse transition-all duration-1000 w-full" />
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
          <Sparkles className="w-3.5 h-3.5 text-accent-400 animate-pulse" />
          <span>Initializing AI Shopping Engine & Catalog...</span>
        </div>

        {onDismiss && (
          <button
            onClick={onDismiss}
            className="mt-6 text-xs text-slate-500 hover:text-slate-300 underline underline-offset-4 transition-colors"
          >
            Skip Intro
          </button>
        )}
      </div>
    </div>
  );
};
