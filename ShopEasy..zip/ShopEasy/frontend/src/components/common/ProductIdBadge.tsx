import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { copyToClipboard } from '../../utils';
import { useUI } from '../../context/UIContext';

interface ProductIdBadgeProps {
  productId: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showIcon?: boolean;
}

export const ProductIdBadge: React.FC<ProductIdBadgeProps> = ({
  productId,
  size = 'sm',
  className = '',
  showIcon = true
}) => {
  const [copied, setCopied] = useState(false);
  const { addToast } = useUI();

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const success = await copyToClipboard(productId);
    if (success) {
      setCopied(true);
      addToast('Product ID Copied', `Copied ${productId} to clipboard`, 'success', 2000);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2 font-mono font-medium',
  };

  return (
    <button
      onClick={handleCopy}
      type="button"
      title="Click to copy ShopEasy Product ID"
      className={`inline-flex items-center font-mono font-semibold rounded-md border transition-all duration-200 group cursor-pointer select-none ${
        copied
          ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
          : 'bg-slate-50 hover:bg-brand-50 border-slate-200 hover:border-brand-200 text-slate-600 hover:text-brand-700'
      } ${sizeClasses[size]} ${className}`}
    >
      <span className="tracking-wider">{productId}</span>
      {showIcon && (
        <span className="text-slate-400 group-hover:text-brand-600 transition-colors">
          {copied ? <Check className="w-3 h-3 text-emerald-600 animate-fade-in" /> : <Copy className="w-3 h-3" />}
        </span>
      )}
    </button>
  );
};
