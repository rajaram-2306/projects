import express from 'express';
import http from 'http';
import path from 'path';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

import { initDB } from './src/server/db.js';
import { initSocketServer } from './src/server/socket.js';
import authRoutes from './src/server/routes/authRoutes.js';
import driverRoutes from './src/server/routes/driverRoutes.js';
import bookingRoutes from './src/server/routes/bookingRoutes.js';
import adminRoutes from './src/server/routes/adminRoutes.js';
import feedbackRoutes from './src/server/routes/feedbackRoutes.js';
import * as db from './src/server/db.js';

dotenv.config();

const PORT = 3000;

async function startServer() {
  const app = express();
  const server = http.createServer(app);

  // 1. Initialize database (SQLite) & Socket.IO server
  await initDB();
  const io = initSocketServer(server);

  // 2. Middleware
  app.use(cors());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));
  app.use(cookieParser());

  // 3. API Routes FIRST
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'DriveMate API',
      timestamp: new Date().toISOString()
    });
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/drivers', driverRoutes);
  app.use('/api/bookings', bookingRoutes);
  app.use('/api/admin', adminRoutes);
  app.use('/api/feedback', feedbackRoutes);

  // Public Testimonials & FAQs
  app.get('/api/public/testimonials', (req, res) => {
    res.json({ testimonials: db.getAllTestimonials() });
  });

  app.get('/api/public/faqs', (req, res) => {
    res.json({ faqs: db.getAllFAQs() });
  });

  // 4. Vite middleware setup for Development & Production fallback
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // 5. Start HTTP + Socket.IO Server
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`DriveMate Full-Stack Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start DriveMate server:', err);
});
