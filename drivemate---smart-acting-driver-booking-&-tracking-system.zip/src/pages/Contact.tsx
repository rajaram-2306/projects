import React, { useState } from 'react';
import { Phone, Mail, MapPin, Send, CheckCircle2, ShieldAlert, Clock, MessageSquare } from 'lucide-react';

export const Contact: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('General Enquiry');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setName('');
    setEmail('');
    setPhone('');
    setMessage('');
    setTimeout(() => setIsSubmitted(false), 6000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-extrabold uppercase tracking-widest text-blue-600 bg-blue-50 px-3.5 py-1.5 rounded-full">
          Get in Touch
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
          We&apos;re Here to Help 24/7
        </h1>
        <p className="text-sm text-slate-600">
          Have an urgent booking question, driver feedback, or corporate acting driver requirement? Contact our team.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Contact info cards */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-lg text-slate-900">24/7 Emergency SOS Helpline</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              If you or your acting driver encounter a mechanical breakdown, medical emergency, or security concern during a trip:
            </p>
            <a
              href="tel:+919840012345"
              className="block w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-sm text-center shadow-md shadow-red-500/20 transition-all"
            >
              Call Emergency Support: +91 98400 12345
            </a>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-extrabold text-base text-slate-900">Headquarters & Support Hub</h3>
            <ul className="space-y-4 text-xs text-slate-600">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>DriveMate Technologies Hub, #45, Venkatanarayana Road, T. Nagar, Chennai, Tamil Nadu 600017</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-blue-600 shrink-0" />
                <span>+91 44 2434 5678 (General Queries)</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-blue-600 shrink-0" />
                <span>support@drivemate.com</span>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Support Operations: 24 hours a day, 7 days a week</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-7 bg-white p-8 rounded-3xl border border-slate-200/80 shadow-sm">
          <h3 className="font-extrabold text-xl text-slate-900 mb-6">Send Us a Message</h3>

          {isSubmitted && (
            <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <p className="text-xs font-bold">
                Thank you! Your message has been received. Our support agent will respond within 30 minutes.
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="contact-name-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                  Your Full Name *
                </label>
                <input
                  id="contact-name-input"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Karthik Sunder"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label htmlFor="contact-email-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                  Email Address *
                </label>
                <input
                  id="contact-email-input"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="karthik@example.com"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="contact-mobile-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                  Mobile Number *
                </label>
                <input
                  id="contact-mobile-input"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="98400 12345"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label htmlFor="contact-subject-select" className="block text-xs font-bold text-slate-700 mb-1.5">
                  Subject *
                </label>
                <select
                  id="contact-subject-select"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  <option value="General Enquiry">General Enquiry</option>
                  <option value="Booking Assistance">Booking or Billing Assistance</option>
                  <option value="Driver Partner Application">Driver Partner Onboarding</option>
                  <option value="Corporate Booking">Corporate Acting Driver Contract</option>
                  <option value="Safety Report">Safety / Feedback Report</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="contact-msg-textarea" className="block text-xs font-bold text-slate-700 mb-1.5">
                Your Message *
              </label>
              <textarea
                id="contact-msg-textarea"
                required
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="How can we help you?"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Submit Enquiry</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
