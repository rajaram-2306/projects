import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter, SlidersHorizontal, Shield, Star, Car, CheckCircle2, MapPin, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import { User } from '../types';
import { DriverCard } from '../components/DriverCard';
import { BookingModal } from '../components/BookingModal';
import { useAuth } from '../context/AuthContext';

export const DriverListing: React.FC = () => {
  const [searchParams] = useSearchParams();
  const { user } = useAuth();

  const [drivers, setDrivers] = useState<User[]>([]);
  const [filteredDrivers, setFilteredDrivers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [searchTerm, setSearchTerm] = useState(searchParams.get('city') || '');
  const [vehicleFilter, setVehicleFilter] = useState(searchParams.get('vehicle') || 'All');
  const [minRating, setMinRating] = useState(0);
  const [onlyOnline, setOnlyOnline] = useState(false);
  const [sortBy, setSortBy] = useState<'rating' | 'experience' | 'price_low'>('rating');

  // Booking Modal State
  const [selectedDriver, setSelectedDriver] = useState<User | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingSuccessMessage, setBookingSuccessMessage] = useState('');

  const fetchDrivers = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/drivers');
      if (res.ok) {
        const data = await res.json();
        setDrivers(data.drivers);
      }
    } catch (err) {
      console.error('Error fetching drivers:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDrivers();
  }, []);

  // Filter & sort logic
  useEffect(() => {
    let result = [...drivers];

    if (searchTerm.trim()) {
      const query = searchTerm.toLowerCase();
      result = result.filter(
        (d) =>
          d.name.toLowerCase().includes(query) ||
          (d.address && d.address.toLowerCase().includes(query))
      );
    }

    if (vehicleFilter && vehicleFilter !== 'All') {
      result = result.filter(
        (d) => d.vehicleType === vehicleFilter || d.vehicleType === 'All'
      );
    }

    if (minRating > 0) {
      result = result.filter((d) => (d.rating || 0) >= minRating);
    }

    if (onlyOnline) {
      result = result.filter((d) => d.isOnline);
    }

    if (sortBy === 'rating') {
      result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    } else if (sortBy === 'experience') {
      result.sort((a, b) => (b.experience || 0) - (a.experience || 0));
    } else if (sortBy === 'price_low') {
      result.sort((a, b) => (a.hourlyRate || 180) - (b.hourlyRate || 180));
    }

    setFilteredDrivers(result);
  }, [drivers, searchTerm, vehicleFilter, minRating, onlyOnline, sortBy]);

  const handleBookNowTrigger = (driver: User) => {
    setSelectedDriver(driver);
    setIsBookingModalOpen(true);
  };

  const handleBookingSuccess = (booking: any) => {
    setBookingSuccessMessage(
      `Booking Request #${booking.id.slice(0, 8)} created! Driver ${booking.driverName} has been notified via SMS/Push.`
    );
    setTimeout(() => {
      setBookingSuccessMessage('');
    }, 6000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-950 rounded-3xl p-8 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-lg">
        <div className="space-y-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-400/30">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Verified Acting Drivers</span>
          </span>
          <h1 className="text-3xl font-extrabold text-white">
            Find & Book Professional Acting Drivers
          </h1>
          <p className="text-sm text-slate-300">
            All drivers are Aadhaar-verified, RTO-checked, and trained in defensive driving for your own car.
          </p>
        </div>

        <button
          onClick={fetchDrivers}
          className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-2 border border-white/20 transition-all cursor-pointer shrink-0"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Refresh Availability</span>
        </button>
      </div>

      {/* Success Banner */}
      {bookingSuccessMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3 animate-in fade-in duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-sm font-bold">{bookingSuccessMessage}</p>
        </div>
      )}

      {/* Search & Filter Bar */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Search box */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by driver name or location (e.g. Chennai, T. Nagar)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Vehicle Type Filter */}
          <div className="md:col-span-3">
            <select
              value={vehicleFilter}
              onChange={(e) => setVehicleFilter(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            >
              <option value="All">All Car Specializations</option>
              <option value="Sedan">Sedan Specialists</option>
              <option value="SUV">SUV Specialists</option>
              <option value="Luxury">Luxury / EV Specialists</option>
            </select>
          </div>

          {/* Sort Select */}
          <div className="md:col-span-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            >
              <option value="rating">Sort: Top Rated</option>
              <option value="experience">Sort: Experience</option>
              <option value="price_low">Sort: Lowest Hourly Rate</option>
            </select>
          </div>

          {/* Rating filter */}
          <div className="md:col-span-2">
            <select
              value={minRating}
              onChange={(e) => setMinRating(Number(e.target.value))}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            >
              <option value={0}>All Ratings</option>
              <option value={4.8}>★ 4.8 & Above</option>
              <option value={4.5}>★ 4.5 & Above</option>
              <option value={4.0}>★ 4.0 & Above</option>
            </select>
          </div>
        </div>

        {/* Quick filter pills */}
        <div className="flex flex-wrap items-center justify-between pt-3 border-t border-slate-100 gap-4">
          <div className="flex items-center gap-4">
            <label className="inline-flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={onlyOnline}
                onChange={(e) => setOnlyOnline(e.target.checked)}
                className="w-4 h-4 rounded-md text-blue-600 focus:ring-blue-500 border-slate-300"
              />
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span>Show Online Drivers Only</span>
              </span>
            </label>
          </div>

          <span className="text-xs font-bold text-slate-500">
            Showing <strong className="text-slate-900">{filteredDrivers.length}</strong> available acting drivers
          </span>
        </div>
      </div>

      {/* Driver Cards Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-80 rounded-3xl bg-slate-200" />
          ))}
        </div>
      ) : filteredDrivers.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center max-w-lg mx-auto space-y-3">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="font-extrabold text-lg text-slate-800">No Drivers Found</h3>
          <p className="text-xs text-slate-500">
            We couldn&apos;t find any acting drivers matching your selected filters. Try changing your search filters or resetting location.
          </p>
          <button
            onClick={() => {
              setSearchTerm('');
              setVehicleFilter('All');
              setMinRating(0);
              setOnlyOnline(false);
            }}
            className="mt-2 px-4 py-2 text-xs font-bold bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDrivers.map((driver) => (
            <DriverCard
              key={driver.id}
              driver={driver}
              onBookNow={handleBookNowTrigger}
            />
          ))}
        </div>
      )}

      {/* Booking Modal */}
      <BookingModal
        driver={selectedDriver}
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        onBookingSuccess={handleBookingSuccess}
      />
    </div>
  );
};
