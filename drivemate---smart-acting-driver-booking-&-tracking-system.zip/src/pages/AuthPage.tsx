import React, { useState } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { Shield, Car, User as UserIcon, Lock, Mail, Phone, Upload, CheckCircle2, Sparkles, ArrowRight, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

interface AuthPageProps {
  initialMode?: 'login' | 'register';
}

export const AuthPage: React.FC<AuthPageProps> = ({ initialMode = 'login' }) => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { login, register, demoSwitch } = useAuth();

  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [role, setRole] = useState<UserRole>((searchParams.get('role') as UserRole) || 'customer');

  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('password123');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [address, setAddress] = useState('');

  // Driver fields
  const [aadhaarNumber, setAadhaarNumber] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [vehicleType, setVehicleType] = useState('Sedan');
  const [experience, setExperience] = useState(5);
  const [uploadedDocs, setUploadedDocs] = useState<{ [key: string]: boolean }>({});

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleDocUpload = (docKey: string) => {
    setUploadedDocs((prev) => ({ ...prev, [docKey]: true }));
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      if (mode === 'login') {
        const res = await login(email, password);
        if (res.success) {
          navigate('/');
        } else {
          setError(res.error || 'Invalid credentials');
        }
      } else {
        const res = await register({
          name,
          email,
          password,
          role,
          mobile,
          address,
          aadhaarNumber,
          licenseNumber,
          vehicleType,
          experience,
          documentUrls: {
            photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
            license: 'uploaded_dl.png',
            aadhaar: 'uploaded_aadhaar.png',
            rcBook: 'uploaded_rc.png',
            insurance: 'uploaded_ins.png'
          }
        });
        if (res.success) {
          navigate('/');
        } else {
          setError(res.error || 'Registration failed');
        }
      }
    } catch (err: any) {
      setError(err.message || 'Error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoSwitchRole = async (targetRole: UserRole, status?: string) => {
    await demoSwitch(targetRole, status);
    navigate('/');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Demo Quick Switch Bar */}
      <div className="mb-8 p-6 rounded-3xl bg-gradient-to-r from-amber-50 via-amber-100/60 to-orange-50 border border-amber-200 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500 text-white shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-amber-950">Instant Demo Test Accounts (No Password Required)</h3>
              <p className="text-xs text-amber-800">Jump straight into any role with pre-loaded bookings & live GPS data</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => handleDemoSwitchRole('customer')}
              className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
            >
              Test as Customer
            </button>
            <button
              onClick={() => handleDemoSwitchRole('driver', 'active')}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
            >
              Test as Driver
            </button>
            <button
              onClick={() => handleDemoSwitchRole('admin')}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
            >
              Test as Admin
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-12">
        {/* Left Side Banner */}
        <div className="md:col-span-5 bg-gradient-to-br from-blue-900 to-slate-900 text-white p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-8">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white">
                <Car className="w-5 h-5" />
              </div>
              <span className="font-extrabold text-xl tracking-tight">DriveMate</span>
            </div>

            <h2 className="text-2xl font-extrabold text-white leading-snug">
              {mode === 'login' ? 'Welcome Back to DriveMate' : 'Join the Trusted Acting Driver Network'}
            </h2>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              India&apos;s most reliable platform connecting car owners with verified acting drivers.
            </p>

            <div className="mt-8 space-y-3">
              <div className="flex items-center gap-3 text-xs text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>100% Background & Police Verified Drivers</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>24/7 Live GPS Movement & Emergency SOS</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Transparent Hourly Pricing from ₹180/hr</span>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800 text-xs text-slate-400">
            <span>By continuing, you agree to DriveMate Safety Policy & Terms.</span>
          </div>
        </div>

        {/* Form Container */}
        <div className="md:col-span-7 p-8">
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
            <h3 className="font-extrabold text-xl text-slate-900">
              {mode === 'login' ? 'Sign In to Your Account' : 'Create a New Account'}
            </h3>
            <button
              onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
              className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
            >
              {mode === 'login' ? 'Create an account?' : 'Already have an account? Sign in'}
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-700 text-xs font-semibold border border-red-200">
              {error}
            </div>
          )}

          {/* Role selector if registering */}
          {mode === 'register' && (
            <div className="mb-6">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                I am signing up as:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('customer')}
                  className={`p-3 rounded-2xl border text-left font-bold text-xs flex items-center gap-2 cursor-pointer ${
                    role === 'customer'
                      ? 'border-blue-600 bg-blue-50 text-blue-700'
                      : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <UserIcon className="w-4 h-4" />
                  <span>Car Owner (Customer)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('driver')}
                  className={`p-3 rounded-2xl border text-left font-bold text-xs flex items-center gap-2 cursor-pointer ${
                    role === 'driver'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                      : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Car className="w-4 h-4" />
                  <span>Acting Driver Partner</span>
                </button>
              </div>
            </div>
          )}

          <form onSubmit={handleAuthSubmit} className="space-y-4">
            {mode === 'register' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="auth-name-input" className="block text-xs font-bold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    id="auth-name-input"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. M. Rajaram"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="auth-mobile-input" className="block text-xs font-bold text-slate-700 mb-1">
                    Mobile Number *
                  </label>
                  <input
                    id="auth-mobile-input"
                    type="tel"
                    required
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    placeholder="98400 12345"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}

            <div>
              <label htmlFor="auth-email-input" className="block text-xs font-bold text-slate-700 mb-1">
                Email Address *
              </label>
              <input
                id="auth-email-input"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="rajaram@example.com"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="auth-password-input" className="block text-xs font-bold text-slate-700 mb-1">
                Password *
              </label>
              <input
                id="auth-password-input"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Extra driver fields if registering as driver */}
            {mode === 'register' && role === 'driver' && (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Acting Driver Verification Details
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="auth-aadhaar-input" className="block text-xs font-bold text-slate-700 mb-1">
                      Aadhaar Number *
                    </label>
                    <input
                      id="auth-aadhaar-input"
                      type="text"
                      required
                      value={aadhaarNumber}
                      onChange={(e) => setAadhaarNumber(e.target.value)}
                      placeholder="1234 5678 9012"
                      className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium"
                    />
                  </div>

                  <div>
                    <label htmlFor="auth-dl-input" className="block text-xs font-bold text-slate-700 mb-1">
                      Driving License No. *
                    </label>
                    <input
                      id="auth-dl-input"
                      type="text"
                      required
                      value={licenseNumber}
                      onChange={(e) => setLicenseNumber(e.target.value)}
                      placeholder="TN09 20180012345"
                      className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="auth-vehicle-type-select" className="block text-xs font-bold text-slate-700 mb-1">
                      Car Specialization *
                    </label>
                    <select
                      id="auth-vehicle-type-select"
                      value={vehicleType}
                      onChange={(e) => setVehicleType(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium bg-white"
                    >
                      <option value="Sedan">Sedan Specialist</option>
                      <option value="SUV">SUV Specialist</option>
                      <option value="Luxury">Luxury / EV Specialist</option>
                      <option value="Hatchback">All Cars</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="auth-experience-input" className="block text-xs font-bold text-slate-700 mb-1">
                      Experience (Years) *
                    </label>
                    <input
                      id="auth-experience-input"
                      type="number"
                      required
                      min={1}
                      max={40}
                      value={experience}
                      onChange={(e) => setExperience(Number(e.target.value))}
                      className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium"
                    />
                  </div>
                </div>

                {/* Document upload simulation */}
                <div className="pt-2">
                  <span className="text-[11px] font-bold text-slate-600 block mb-1">
                    Required KYC Document Uploads (Simulated)
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {['Aadhaar Card Photo', 'Driving License', 'Police Check Cert', 'Driver Portrait'].map(
                      (docName, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => handleDocUpload(docName)}
                          className={`p-2 rounded-xl border text-left flex items-center justify-between transition-colors cursor-pointer ${
                            uploadedDocs[docName]
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                              : 'bg-white border-slate-200 hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <span className="truncate">{docName}</span>
                          {uploadedDocs[docName] ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          ) : (
                            <Upload className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          )}
                        </button>
                      )
                    )}
                  </div>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm shadow-md shadow-blue-500/20 disabled:opacity-50 transition-all flex items-center justify-center gap-2 cursor-pointer mt-4"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <span>{mode === 'login' ? 'Sign In to DriveMate' : 'Complete Registration'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Preset Login hints */}
          <div className="mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500">
            <span className="font-bold text-slate-700 block mb-1">Test Login Credentials:</span>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>• Customer: <strong>rajaram@example.com</strong> / password123</div>
              <div>• Driver: <strong>rajesh@example.com</strong> / password123</div>
              <div>• Admin: <strong>admin@drivemate.com</strong> / admin123</div>
              <div>• Pending: <strong>suresh@example.com</strong> / password123</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
