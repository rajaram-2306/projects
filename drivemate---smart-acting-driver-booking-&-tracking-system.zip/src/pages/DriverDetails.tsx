import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Shield, Star, Car, Clock, MapPin, CheckCircle, Award, ArrowLeft, Phone, Mail, Calendar, Sparkles, CheckCircle2 } from 'lucide-react';
import { User } from '../types';
import { BookingModal } from '../components/BookingModal';
import { useAuth } from '../context/AuthContext';

export const DriverDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [driver, setDriver] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingSuccessMessage, setBookingSuccessMessage] = useState('');

  useEffect(() => {
    const fetchDriver = async () => {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/drivers/${id}`);
        if (res.ok) {
          const data = await res.json();
          setDriver(data.driver);
        }
      } catch (err) {
        console.error('Error fetching driver details:', err);
      } finally {
        setIsLoading(false);
      }
    };
    if (id) fetchDriver();
  }, [id]);

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-sm font-semibold text-slate-500 mt-4">Loading driver profile...</p>
      </div>
    );
  }

  if (!driver) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-2xl font-extrabold text-slate-800">Driver Not Found</h2>
        <p className="text-sm text-slate-500">This driver may no longer be available on the platform.</p>
        <Link
          to="/drivers"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 text-white font-bold text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Acting Drivers</span>
        </Link>
      </div>
    );
  }

  const handleBookingSuccess = (booking: any) => {
    setBookingSuccessMessage(
      `Booking confirmed! Your request #${booking.id.slice(0, 8)} is now sent to ${driver.name}.`
    );
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Back navigation */}
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Driver List</span>
      </button>

      {/* Success Banner */}
      {bookingSuccessMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-sm font-bold">{bookingSuccessMessage}</p>
        </div>
      )}

      {/* Profile Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                src={driver.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                alt={driver.name}
                className="w-24 h-24 rounded-2xl object-cover border-4 border-slate-50 shadow-md"
              />
              <span
                className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-2 border-white flex items-center justify-center text-[10px] text-white font-bold ${
                  driver.isOnline ? 'bg-emerald-500' : 'bg-slate-400'
                }`}
                title={driver.isOnline ? 'Online Now' : 'Offline'}
              />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">{driver.name}</h1>
                <span className="inline-flex items-center text-emerald-600" title="RTO Verified">
                  <CheckCircle className="w-5 h-5 fill-emerald-100" />
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{driver.address || 'Chennai, Tamil Nadu'} • Active Member</span>
              </p>

              {/* Status tags */}
              <div className="flex flex-wrap items-center gap-2 mt-3">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                  Car Specialization: {driver.vehicleType || 'Sedan & SUV'}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  100% Background Checked
                </span>
              </div>
            </div>
          </div>

          {/* Pricing Box & CTA */}
          <div className="flex flex-col sm:items-end gap-3 w-full sm:w-auto pt-4 sm:pt-0 border-t sm:border-0 border-slate-100">
            <div className="text-left sm:text-right">
              <span className="text-xs font-bold text-slate-400 uppercase">Hourly Rate</span>
              <p className="text-3xl font-extrabold text-blue-600">₹{driver.hourlyRate || 180}<span className="text-sm font-semibold text-slate-500"> / hour</span></p>
            </div>
            <button
              onClick={() => setIsBookingModalOpen(true)}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm shadow-md shadow-blue-500/20 transition-all cursor-pointer"
            >
              Book {driver.name.split(' ')[0]} Now
            </button>
          </div>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8 pt-6 border-t border-slate-100 text-center">
          <div className="p-4 rounded-2xl bg-slate-50">
            <div className="flex items-center justify-center gap-1.5 text-amber-500 font-extrabold text-xl">
              <Star className="w-5 h-5 fill-amber-400" />
              <span>{Number(driver.rating || 5.0).toFixed(1)} / 5</span>
            </div>
            <span className="text-xs font-semibold text-slate-500 block mt-1">Average Customer Rating</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50">
            <p className="text-xl font-extrabold text-slate-900">{driver.totalTrips || 154}+</p>
            <span className="text-xs font-semibold text-slate-500 block mt-1">Trips Completed</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50">
            <p className="text-xl font-extrabold text-slate-900">{driver.experience || 5} Years</p>
            <span className="text-xs font-semibold text-slate-500 block mt-1">Driving Experience</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50">
            <p className="text-xl font-extrabold text-emerald-600">Verified</p>
            <span className="text-xs font-semibold text-slate-500 block mt-1">Police & RTO Status</span>
          </div>
        </div>
      </div>

      {/* Grid: 5-Step Verification & Skills */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Verification Checkmarks */}
        <div className="bg-white rounded-3xl border border-slate-200/80 p-6 space-y-4">
          <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-600" />
            <span>DriveMate 5-Step Verification Checklist</span>
          </h3>

          <ul className="space-y-3">
            {[
              { label: 'Aadhaar Card Identity Authentication', status: 'Verified' },
              { label: 'RTO Commercial / Private Driving License', status: 'Verified & Active' },
              { label: 'Local Police Background Check Certificate', status: 'Cleared' },
              { label: 'Practical City Driving Skill Test', status: 'Passed (Score: 96/100)' },
              { label: 'Customer Etiquette & Safety Orientation', status: 'Completed' }
            ].map((chk, i) => (
              <li key={i} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-xs font-bold text-slate-700">{chk.label}</span>
                <span className="inline-flex items-center gap-1 text-xs font-extrabold text-emerald-600">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{chk.status}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Vehicle Skills */}
        <div className="bg-white rounded-3xl border border-slate-200/80 p-6 space-y-4">
          <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
            <Car className="w-5 h-5 text-blue-600" />
            <span>Car Specializations & Competency</span>
          </h3>

          <div className="space-y-3 text-xs font-semibold text-slate-700">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block">Automatic & Manual Transmissions</span>
              <p className="text-slate-500 mt-0.5">Experienced with DCT, CVT, Torque Converter, and Manual clutches.</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block">Luxury & EV Sedans / SUVs</span>
              <p className="text-slate-500 mt-0.5">Familiar with BMW, Mercedes, Audi, Kia EV6, Tata Nexon EV, Innova Hycross.</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block">Outstation & Night Highway Driving</span>
              <p className="text-slate-500 mt-0.5">Trained in highway defensive driving, zero fatigue breaks, and night visibility rules.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Customer Reviews Section */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 space-y-6">
        <h3 className="font-extrabold text-lg text-slate-900">Recent Customer Reviews</h3>

        <div className="divide-y divide-slate-100">
          {[
            {
              customerName: 'Karthik Sunder',
              date: '12 July 2026',
              rating: 5,
              comment: 'Rajesh drove my Honda City Automatic from Anna Nagar to Airport smoothly. Very courteous and arrived 10 minutes early.',
              overallScore: '5.0 / 5'
            },
            {
              customerName: 'Dr. Priya Narayanan',
              date: '04 July 2026',
              rating: 5,
              comment: 'Excellent driving skill in heavy rain. Very patient in Chennai evening traffic. Highly recommended!',
              overallScore: '5.0 / 5'
            },
            {
              customerName: 'Ranganathan V.',
              date: '28 June 2026',
              rating: 5,
              comment: 'Booked for an outstation trip to Pondicherry. Kept the car clean and followed speed limits properly.',
              overallScore: '4.9 / 5'
            }
          ].map((rev, idx) => (
            <div key={idx} className="py-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-sm text-slate-800">{rev.customerName}</span>
                  <span className="text-xs text-slate-400">• {rev.date}</span>
                </div>
                <div className="flex items-center gap-1 text-amber-500 font-bold text-xs bg-amber-50 px-2.5 py-1 rounded-full">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span>{rev.overallScore}</span>
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">&ldquo;{rev.comment}&rdquo;</p>
            </div>
          ))}
        </div>
      </div>

      <BookingModal
        driver={driver}
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        onBookingSuccess={handleBookingSuccess}
      />
    </div>
  );
};
