import React from 'react';
import { Shield, Car, CheckCircle2, Clock, MapPin, Award, Heart, Users, Navigation } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Hero Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-extrabold uppercase tracking-widest text-blue-600 bg-blue-50 px-3.5 py-1.5 rounded-full">
          About DriveMate
        </span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 leading-tight">
          India&apos;s Smartest & Safest <span className="text-blue-600">Acting Driver</span> Booking Platform
        </h1>
        <p className="text-base text-slate-600 leading-relaxed">
          We connect car owners with background-verified, RTO-checked professional acting drivers. Whether it is a daily commute, late night event, or outstation trip, your own car is in safe hands.
        </p>
      </div>

      {/* How It Works - Customer Flow */}
      <div className="space-y-8">
        <div className="text-center">
          <h2 className="text-2xl font-extrabold text-slate-900">How DriveMate Works For Car Owners</h2>
          <p className="text-sm text-slate-500 mt-1">3 simple steps to hire a trusted acting driver for your own car</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              step: '01',
              title: 'Select City & Car Specialization',
              desc: 'Enter your pickup and destination addresses, choose your car type (Sedan, SUV, Luxury EV), and view instant distance and fare estimates.'
            },
            {
              step: '02',
              title: 'Pick a Verified Driver',
              desc: 'Browse acting drivers based on ratings, hourly rates, and experience. Every driver is Aadhaar-verified and police background-checked.'
            },
            {
              step: '03',
              title: 'Track Live via GPS & Enjoy',
              desc: 'Monitor your trip in real time on our Leaflet GPS map. Share the live tracking link with family for peace of mind.'
            }
          ].map((item, i) => (
            <div key={i} className="bg-white p-8 rounded-3xl border border-slate-200/80 shadow-xs relative overflow-hidden">
              <span className="text-5xl font-extrabold text-blue-100 absolute top-4 right-4 select-none">
                {item.step}
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-4">{item.title}</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 5-Dimension Safety Policy */}
      <div className="bg-slate-900 rounded-3xl p-8 sm:p-12 text-white grid grid-cols-1 lg:grid-cols-12 gap-8 items-center shadow-xl">
        <div className="lg:col-span-6 space-y-4">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950 px-3 py-1.5 rounded-full border border-emerald-800">
            100% Background-Checked
          </span>
          <h3 className="text-3xl font-extrabold text-white">Our 5-Point Driver Verification Protocol</h3>
          <p className="text-sm text-slate-300 leading-relaxed">
            We reject 40% of driver applicants during our background screening. Only disciplined, experienced drivers make it onto our platform.
          </p>

          <ul className="space-y-3 pt-2">
            {[
              'Government Aadhaar Biometric Identity Verification',
              'RTO Driving License Authenticity & Commercial Check',
              'Local Police Criminal Record Background Certificate',
              'Practical Road Driving Test & Vehicle Handling Audit',
              '5-Dimension Post-Trip Customer Review Monitoring'
            ].map((pt, idx) => (
              <li key={idx} className="flex items-center gap-3 text-xs font-bold text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{pt}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-6 bg-slate-800/80 rounded-2xl p-6 border border-slate-700/80 space-y-4">
          <h4 className="font-extrabold text-base text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <span>Transparent Pricing Policy</span>
          </h4>
          <p className="text-xs text-slate-300 leading-relaxed">
            Unlike taxi aggregators, you only pay for the acting driver&apos;s professional time.
          </p>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400 block">City Hourly Rate</span>
              <p className="text-xl font-extrabold text-white mt-0.5">₹180–₹220 / hr</p>
              <span className="text-[10px] text-slate-500">Min. 3 hours billing</span>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-700">
              <span className="text-xs text-slate-400 block">Outstation Day Allowance</span>
              <p className="text-xl font-extrabold text-white mt-0.5">₹1,200 / day</p>
              <span className="text-[10px] text-slate-500">+ food & stay allowance</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
