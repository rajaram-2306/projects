import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Car, Clock, MapPin, Shield, Star, AlertCircle, RefreshCw, CheckCircle2, XCircle, Phone, Navigation, ArrowRight, Download, Eye } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Booking } from '../../types';
import { LiveTrackingMap } from '../../components/LiveTrackingMap';
import { TripFeedbackModal } from '../../components/TripFeedbackModal';

export const CustomerDashboard: React.FC = () => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTrackBooking, setSelectedTrackBooking] = useState<Booking | null>(null);
  const [selectedRateBooking, setSelectedRateBooking] = useState<Booking | null>(null);
  const [activeTab, setActiveTab] = useState<'active' | 'history'>('active');
  const [toastMessage, setToastMessage] = useState('');

  const fetchMyBookings = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const res = await fetch(`/api/bookings/my-bookings?userId=${user.id}`);
      if (res.ok) {
        const data = await res.json();
        setBookings(data.bookings);
        // Default track first active trip if any
        const activeTrip = data.bookings.find(
          (b: Booking) => b.status === 'in-progress' || b.status === 'accepted'
        );
        if (activeTrip) setSelectedTrackBooking(activeTrip);
      }
    } catch (err) {
      console.error('Error fetching bookings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMyBookings();
  }, [user]);

  const handleCancelTrip = async (bookingId: string) => {
    if (!window.confirm('Are you sure you want to cancel this driver booking request?')) return;
    try {
      const res = await fetch(`/api/bookings/${bookingId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'cancelled', cancellationReason: 'Customer requested cancellation' })
      });
      if (res.ok) {
        setToastMessage('Booking cancelled successfully.');
        fetchMyBookings();
        setTimeout(() => setToastMessage(''), 4000);
      }
    } catch (err) {
      console.error('Error cancelling:', err);
    }
  };

  const activeBookings = bookings.filter(
    (b) => b.status === 'requested' || b.status === 'accepted' || b.status === 'in-progress'
  );

  const historyBookings = bookings.filter(
    (b) => b.status === 'completed' || b.status === 'cancelled' || b.status === 'rejected'
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-3xl p-8 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-lg">
        <div className="space-y-1.5">
          <span className="text-xs font-extrabold uppercase tracking-widest text-blue-100 bg-white/20 px-3 py-1 rounded-full">
            Car Owner Dashboard
          </span>
          <h1 className="text-3xl font-extrabold text-white">
            Welcome, {user?.name || 'M. Rajaram'}
          </h1>
          <p className="text-xs text-blue-100">
            Manage your acting driver bookings, track active trips via GPS, and view GST invoices.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchMyBookings}
            className="px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs flex items-center gap-2 border border-white/20 transition-all cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Refresh</span>
          </button>
          <Link
            to="/drivers"
            className="px-5 py-2.5 rounded-xl bg-white text-blue-700 font-extrabold text-xs shadow-md hover:bg-blue-50 transition-all flex items-center gap-1.5"
          >
            <span>Book Driver Now</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>

      {toastMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-xs font-bold">{toastMessage}</p>
        </div>
      )}

      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Active Trips</span>
          <p className="text-2xl font-extrabold text-blue-600 mt-1">{activeBookings.length}</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Completed Trips</span>
          <p className="text-2xl font-extrabold text-emerald-600 mt-1">
            {bookings.filter((b) => b.status === 'completed').length}
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Your Rating</span>
          <p className="text-2xl font-extrabold text-amber-500 mt-1">★ 4.9</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">SOS Protection</span>
          <p className="text-sm font-extrabold text-emerald-600 mt-2 flex items-center gap-1">
            <Shield className="w-4 h-4" />
            <span>Active & Insured</span>
          </p>
        </div>
      </div>

      {/* Live GPS Tracking Map Section if there is an active booking */}
      {selectedTrackBooking && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-md overflow-hidden">
          <div className="p-6 bg-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 uppercase">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Live Trip GPS Tracking</span>
              </span>
              <h3 className="text-lg font-extrabold text-white mt-2">
                Driver: {selectedTrackBooking.driverName} ({selectedTrackBooking.driverMobile})
              </h3>
              <p className="text-xs text-slate-300">
                Vehicle: {selectedTrackBooking.vehicleModel} ({selectedTrackBooking.vehicleNumber}) • Status: {selectedTrackBooking.status.toUpperCase()}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <a
                href={`tel:${selectedTrackBooking.driverMobile}`}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Driver</span>
              </a>
              <button
                onClick={() => setSelectedTrackBooking(null)}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
              >
                Close Map
              </button>
            </div>
          </div>

          <div className="p-4">
            <LiveTrackingMap
              bookingId={selectedTrackBooking.id}
              driverId={selectedTrackBooking.driverId}
              pickupLat={selectedTrackBooking.pickupLat || 13.085}
              pickupLng={selectedTrackBooking.pickupLng || 80.21}
              pickupAddress={selectedTrackBooking.pickupAddress}
              destinationLat={selectedTrackBooking.destinationLat || 12.994}
              destinationLng={selectedTrackBooking.destinationLng || 80.17}
              destinationAddress={selectedTrackBooking.destinationAddress}
              status={selectedTrackBooking.status}
              height="h-80"
            />
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-3 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('active')}
          className={`py-3 px-6 font-extrabold text-sm border-b-2 transition-all cursor-pointer ${
            activeTab === 'active'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Active & Upcoming Trips ({activeBookings.length})
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`py-3 px-6 font-extrabold text-sm border-b-2 transition-all cursor-pointer ${
            activeTab === 'history'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Completed & Cancelled ({historyBookings.length})
        </button>
      </div>

      {/* Bookings List */}
      <div className="space-y-4">
        {(activeTab === 'active' ? activeBookings : historyBookings).length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
            <Car className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="font-extrabold text-base text-slate-800">
              No {activeTab === 'active' ? 'Active' : 'Past'} Bookings Found
            </h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              {activeTab === 'active'
                ? 'You currently do not have any active or upcoming acting driver reservations.'
                : 'Your completed and past trip records will appear here.'}
            </p>
            {activeTab === 'active' && (
              <Link
                to="/drivers"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 text-white font-bold text-xs"
              >
                <span>Browse Acting Drivers</span>
              </Link>
            )}
          </div>
        ) : (
          (activeTab === 'active' ? activeBookings : historyBookings).map((booking) => (
            <div
              key={booking.id}
              className="bg-white rounded-3xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all p-6 space-y-4"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-slate-900">
                      Booking #{booking.id.slice(0, 8)}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        booking.status === 'completed'
                          ? 'bg-emerald-100 text-emerald-700'
                          : booking.status === 'in-progress'
                          ? 'bg-blue-100 text-blue-700'
                          : booking.status === 'accepted'
                          ? 'bg-amber-100 text-amber-700'
                          : booking.status === 'cancelled'
                          ? 'bg-red-100 text-red-700'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {booking.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Trip Date: {booking.tripDate} at {booking.tripTime} • Vehicle: {booking.vehicleModel}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-400">Est. Fare:</span>
                  <span className="text-lg font-extrabold text-blue-600">₹{booking.estimatedFare}</span>
                </div>
              </div>

              {/* Route line */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-400 uppercase text-[10px]">Pickup Location</span>
                    <p className="font-bold text-slate-800 mt-0.5">{booking.pickupAddress}</p>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-400 uppercase text-[10px]">Destination</span>
                    <p className="font-bold text-slate-800 mt-0.5">{booking.destinationAddress}</p>
                  </div>
                </div>
              </div>

              {/* Driver info & actions */}
              <div className="flex flex-wrap items-center justify-between pt-3 border-t border-slate-100 gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs">
                    {booking.driverName.charAt(0)}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">{booking.driverName}</span>
                    <span className="text-[11px] text-slate-500">Driver Mobile: {booking.driverMobile}</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {(booking.status === 'in-progress' || booking.status === 'accepted') && (
                    <>
                      <button
                        onClick={() => setSelectedTrackBooking(booking)}
                        className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Navigation className="w-3.5 h-3.5" />
                        <span>Track Live GPS</span>
                      </button>
                      <a
                        href={`tel:${booking.driverMobile}`}
                        className="px-3.5 py-1.5 rounded-xl bg-blue-50 text-blue-700 font-bold text-xs hover:bg-blue-100 transition-colors"
                      >
                        Call
                      </a>
                    </>
                  )}

                  {booking.status === 'requested' && (
                    <button
                      onClick={() => handleCancelTrip(booking.id)}
                      className="px-3.5 py-1.5 rounded-xl bg-red-50 text-red-700 font-bold text-xs hover:bg-red-100 transition-colors cursor-pointer"
                    >
                      Cancel Request
                    </button>
                  )}

                  {booking.status === 'completed' && (
                    <>
                      <button
                        onClick={() => setSelectedRateBooking(booking)}
                        className="px-3.5 py-1.5 rounded-xl bg-amber-50 text-amber-700 font-bold text-xs hover:bg-amber-100 transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Star className="w-3.5 h-3.5 fill-amber-400" />
                        <span>Rate Trip</span>
                      </button>
                      <button
                        onClick={() => alert(`Downloading GST Invoice #${booking.id.slice(0, 8)}...`)}
                        className="px-3.5 py-1.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs hover:bg-slate-200 transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>GST Invoice</span>
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <TripFeedbackModal
        booking={selectedRateBooking}
        isOpen={!!selectedRateBooking}
        onClose={() => setSelectedRateBooking(null)}
        onRatingSuccess={() => {
          setToastMessage('Thank you! Your 5-dimension trip rating has been submitted.');
          setTimeout(() => setToastMessage(''), 4000);
          fetchMyBookings();
        }}
      />
    </div>
  );
};
