import React, { useState, useEffect } from 'react';
import { Car, Clock, Shield, Star, DollarSign, CheckCircle2, XCircle, AlertCircle, RefreshCw, Radio, Play, CheckCircle, Navigation, Phone } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import { Booking } from '../../types';

export const DriverDashboard: React.FC = () => {
  const { user, updateUser } = useAuth();
  const { emitDriverPing } = useSocket();

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(user?.isOnline ?? true);
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // Simulated GPS coordinates around Chennai Airport & Anna Nagar
  const routePoints = [
    { lat: 13.085, lng: 80.21, heading: 45 },
    { lat: 13.06, lng: 80.22, heading: 90 },
    { lat: 13.04, lng: 80.23, heading: 180 },
    { lat: 13.01, lng: 80.20, heading: 210 },
    { lat: 12.994, lng: 80.17, heading: 240 }
  ];
  const [pointIdx, setPointIdx] = useState(0);

  const fetchDriverBookings = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const res = await fetch(`/api/bookings/driver-bookings?driverId=${user.id}`);
      if (res.ok) {
        const data = await res.json();
        setBookings(data.bookings);
      }
    } catch (err) {
      console.error('Error fetching driver bookings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDriverBookings();
  }, [user]);

  // Simulate GPS location ping interval when broadcasting
  useEffect(() => {
    let interval: any;
    if (isBroadcasting) {
      interval = setInterval(() => {
        const nextIdx = (pointIdx + 1) % routePoints.length;
        setPointIdx(nextIdx);
        const pt = routePoints[nextIdx];
        emitDriverPing(pt.lat, pt.lng, pt.heading);
      }, 4000);
    }
    return () => clearInterval(interval);
  }, [isBroadcasting, pointIdx]);

  const handleToggleOnline = async () => {
    if (!user) return;
    const nextVal = !isOnline;
    setIsOnline(nextVal);
    try {
      const res = await fetch(`/api/drivers/${user.id}/online`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isOnline: nextVal })
      });
      if (res.ok) {
        const data = await res.json();
        updateUser(data.driver);
        setToastMessage(`You are now ${nextVal ? 'ONLINE & receiving booking requests' : 'OFFLINE'}.`);
        setTimeout(() => setToastMessage(''), 4000);
      }
    } catch (err) {
      console.error('Error toggling online:', err);
    }
  };

  const handleBookingAction = async (bookingId: string, status: string) => {
    try {
      const res = await fetch(`/api/bookings/${bookingId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setToastMessage(`Trip status updated to: ${status.toUpperCase()}`);
        fetchDriverBookings();
        setTimeout(() => setToastMessage(''), 4000);
      }
    } catch (err) {
      console.error('Error updating status:', err);
    }
  };

  const activeBookings = bookings.filter(
    (b) => b.status === 'requested' || b.status === 'accepted' || b.status === 'in-progress'
  );

  const completedBookings = bookings.filter((b) => b.status === 'completed');

  const totalEarnings = completedBookings.reduce((sum, b) => sum + (b.actualFare || b.estimatedFare || 0), 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Pending status warning banner if pending */}
      {user?.status === 'pending_approval' && (
        <div className="p-5 rounded-3xl bg-amber-50 border border-amber-200 text-amber-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-extrabold text-sm text-amber-950">
                Driver Documents Under Verification (Pending Approval)
              </h4>
              <p className="text-xs text-amber-800 mt-0.5">
                Your Aadhaar card, RTO driving license, and police check certificate are currently in the Admin verification queue. You can test accepting demo bookings below!
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-200 text-amber-900 shrink-0">
            Pending Admin Review
          </span>
        </div>
      )}

      {/* Driver Header Banner */}
      <div className="bg-gradient-to-r from-emerald-700 to-teal-800 rounded-3xl p-8 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-lg">
        <div className="space-y-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/30 text-emerald-100 border border-emerald-400/30">
            <Shield className="w-4 h-4 text-emerald-300" />
            <span>Acting Driver Portal • {user?.vehicleType || 'Sedan & SUV'} Specialist</span>
          </span>
          <h1 className="text-3xl font-extrabold text-white">
            Hello, {user?.name || 'Rajesh Kumar'}
          </h1>
          <p className="text-xs text-emerald-100">
            Hourly Rate: ₹{user?.hourlyRate || 180}/hr • Experience: {user?.experience || 5} yrs • Rating: ★ {user?.rating || 4.9}
          </p>
        </div>

        {/* Online / Offline Switch */}
        <div className="flex items-center gap-4 bg-emerald-900/60 p-4 rounded-2xl border border-emerald-600/40">
          <div className="flex flex-col text-right">
            <span className="text-xs font-bold text-emerald-200 uppercase">Driver Status</span>
            <span className="text-sm font-extrabold text-white">
              {isOnline ? 'ONLINE • Receiving Trips' : 'OFFLINE • Paused'}
            </span>
          </div>

          <button
            onClick={handleToggleOnline}
            className={`w-14 h-8 rounded-full transition-colors relative p-1 cursor-pointer ${
              isOnline ? 'bg-emerald-400' : 'bg-slate-600'
            }`}
            title="Toggle duty status"
          >
            <div
              className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform ${
                isOnline ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {toastMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-xs font-bold">{toastMessage}</p>
        </div>
      )}

      {/* GPS Broadcaster Simulator Box */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-2xl bg-blue-50 text-blue-600">
            <Radio className={`w-6 h-6 ${isBroadcasting ? 'animate-pulse text-emerald-600' : ''}`} />
          </div>
          <div>
            <h4 className="font-extrabold text-sm text-slate-900">
              Live GPS Location Broadcaster (Socket.io Test)
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              {isBroadcasting
                ? `Broadcasting GPS coordinates (${routePoints[pointIdx].lat}, ${routePoints[pointIdx].lng}) to Customer Live Map...`
                : 'Emit simulated live vehicle movement along Anna Nagar -> Chennai Airport route.'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsBroadcasting(!isBroadcasting)}
          className={`px-6 py-3 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all cursor-pointer ${
            isBroadcasting
              ? 'bg-red-500 text-white shadow-md shadow-red-500/20'
              : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20'
          }`}
        >
          {isBroadcasting ? (
            <>
              <span>Stop GPS Broadcast</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-white" />
              <span>Start GPS Broadcast</span>
            </>
          )}
        </button>
      </div>

      {/* Earnings & Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Today&apos;s Earnings</span>
          <p className="text-2xl font-extrabold text-emerald-600 mt-1">₹{totalEarnings || 1620}</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Trips Completed</span>
          <p className="text-2xl font-extrabold text-slate-900 mt-1">{completedBookings.length}</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Customer Rating</span>
          <p className="text-2xl font-extrabold text-amber-500 mt-1">★ {user?.rating || 4.9}</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Police Verified</span>
          <p className="text-sm font-extrabold text-emerald-600 mt-2 flex items-center gap-1">
            <CheckCircle2 className="w-4 h-4" />
            <span>RTO & Police OK</span>
          </p>
        </div>
      </div>

      {/* Incoming / Active Trips Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-lg text-slate-900">
            Active & Incoming Booking Requests ({activeBookings.length})
          </h3>
          <button
            onClick={fetchDriverBookings}
            className="text-xs font-bold text-blue-600 hover:underline cursor-pointer flex items-center gap-1"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Trips</span>
          </button>
        </div>

        {activeBookings.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center space-y-2">
            <Car className="w-10 h-10 text-slate-300 mx-auto" />
            <h4 className="font-extrabold text-base text-slate-800">No Pending Requests Right Now</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              You are online. New acting driver booking requests from nearby customers will appear here in real time.
            </p>
          </div>
        ) : (
          activeBookings.map((trip) => (
            <div
              key={trip.id}
              className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 space-y-4"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-base text-slate-900">
                      Customer: {trip.customerName}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        trip.status === 'in-progress'
                          ? 'bg-blue-100 text-blue-700'
                          : trip.status === 'accepted'
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-purple-100 text-purple-700'
                      }`}
                    >
                      {trip.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Customer Car: <strong>{trip.vehicleModel}</strong> ({trip.vehicleNumber}) • Date: {trip.tripDate} at {trip.tripTime}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Est. Fare</span>
                  <span className="text-xl font-extrabold text-emerald-600">₹{trip.estimatedFare}</span>
                </div>
              </div>

              {/* Locations */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="font-bold text-slate-400 uppercase text-[10px]">Pickup Address</span>
                  <p className="font-bold text-slate-800 mt-0.5">{trip.pickupAddress}</p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="font-bold text-slate-400 uppercase text-[10px]">Destination Address</span>
                  <p className="font-bold text-slate-800 mt-0.5">{trip.destinationAddress}</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between pt-3 border-t border-slate-100 gap-4">
                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${trip.customerMobile}`}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Customer ({trip.customerMobile})</span>
                  </a>
                </div>

                <div className="flex items-center gap-2">
                  {trip.status === 'requested' && (
                    <>
                      <button
                        onClick={() => handleBookingAction(trip.id, 'rejected')}
                        className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs cursor-pointer"
                      >
                        Reject Trip
                      </button>
                      <button
                        onClick={() => handleBookingAction(trip.id, 'accepted')}
                        className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm cursor-pointer"
                      >
                        Accept Trip Booking
                      </button>
                    </>
                  )}

                  {trip.status === 'accepted' && (
                    <button
                      onClick={() => handleBookingAction(trip.id, 'in-progress')}
                      className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-white" />
                      <span>Start Trip (Driver Reached Doorstep)</span>
                    </button>
                  )}

                  {trip.status === 'in-progress' && (
                    <button
                      onClick={() => handleBookingAction(trip.id, 'completed')}
                      className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 cursor-pointer"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Complete Trip & Generate Invoice</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Completed trips history */}
      <div className="space-y-4">
        <h3 className="font-extrabold text-lg text-slate-900">
          Recent Completed Trips ({completedBookings.length})
        </h3>

        <div className="bg-white rounded-3xl border border-slate-200/80 divide-y divide-slate-100 overflow-hidden">
          {completedBookings.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              No completed trips recorded yet.
            </div>
          ) : (
            completedBookings.map((trip) => (
              <div key={trip.id} className="p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="font-bold text-sm text-slate-900">Trip #{trip.id.slice(0, 8)} • {trip.customerName}</span>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {trip.tripDate} • {trip.pickupAddress} -&gt; {trip.destinationAddress}
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm font-extrabold text-emerald-600">₹{trip.actualFare || trip.estimatedFare}</span>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 uppercase">
                    Paid • Completed
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
