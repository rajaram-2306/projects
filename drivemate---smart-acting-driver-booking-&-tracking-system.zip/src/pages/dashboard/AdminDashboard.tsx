import React, { useState, useEffect } from 'react';
import { Shield, Car, Users, CheckCircle2, XCircle, AlertCircle, RefreshCw, BarChart3, Clock, DollarSign, Eye, Award, FileText, Check, X } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, Legend } from 'recharts';
import { User, Booking } from '../../types';

export const AdminDashboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'verification' | 'analytics' | 'bookings' | 'users'>('verification');
  const [toastMessage, setToastMessage] = useState('');

  const [selectedDriverForDoc, setSelectedDriverForDoc] = useState<User | null>(null);

  // Sample analytics data for charts
  const tripTrendData = [
    { month: 'Jan', trips: 1420, revenue: 320000 },
    { month: 'Feb', trips: 1850, revenue: 410000 },
    { month: 'Mar', trips: 2240, revenue: 530000 },
    { month: 'Apr', trips: 2900, revenue: 680000 },
    { month: 'May', trips: 3450, revenue: 810000 },
    { month: 'Jun', trips: 4120, revenue: 980000 },
    { month: 'Jul', trips: 4890, revenue: 1150000 }
  ];

  const vehicleDistribution = [
    { type: 'Sedan Specialists', drivers: 1850 },
    { type: 'SUV Specialists', drivers: 1420 },
    { type: 'Luxury EV Specialists', drivers: 620 },
    { type: 'All Specializations', drivers: 310 }
  ];

  const fetchAdminData = async () => {
    setIsLoading(true);
    try {
      const [uRes, bRes] = await Promise.all([
        fetch('/api/admin/users'),
        fetch('/api/admin/bookings')
      ]);

      if (uRes.ok) {
        const uData = await uRes.json();
        setUsers(uData.users);
      }
      if (bRes.ok) {
        const bData = await bRes.json();
        setBookings(bData.bookings);
      }
    } catch (err) {
      console.error('Error fetching admin data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleVerifyDriver = async (driverId: string, status: 'active' | 'rejected') => {
    try {
      const res = await fetch(`/api/admin/drivers/${driverId}/verify`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setToastMessage(`Driver #${driverId.slice(0, 8)} status changed to: ${status.toUpperCase()}`);
        setTimeout(() => setToastMessage(''), 4000);
        fetchAdminData();
      }
    } catch (err) {
      console.error('Error verifying driver:', err);
    }
  };

  const pendingDrivers = users.filter((u) => u.role === 'driver' && u.status === 'pending_approval');
  const activeDrivers = users.filter((u) => u.role === 'driver' && u.status === 'active');
  const customers = users.filter((u) => u.role === 'customer');

  const totalPlatformRevenue = bookings
    .filter((b) => b.status === 'completed')
    .reduce((sum, b) => sum + (b.actualFare || b.estimatedFare || 0), 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Admin Welcome Header */}
      <div className="bg-gradient-to-r from-purple-800 to-indigo-900 rounded-3xl p-8 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-lg">
        <div className="space-y-1.5">
          <span className="text-xs font-extrabold uppercase tracking-widest text-purple-200 bg-white/15 px-3 py-1 rounded-full">
            Operations & RTO Verification Console
          </span>
          <h1 className="text-3xl font-extrabold text-white">DriveMate Admin Portal</h1>
          <p className="text-xs text-purple-200">
            Monitor live acting driver trips, approve RTO/Aadhaar documents, and analyze platform growth.
          </p>
        </div>

        <button
          onClick={fetchAdminData}
          className="px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs flex items-center gap-2 border border-white/20 transition-all cursor-pointer shrink-0"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Refresh Console</span>
        </button>
      </div>

      {toastMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-xs font-bold">{toastMessage}</p>
        </div>
      )}

      {/* Top Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Pending Verification</span>
          <div className="flex items-center justify-between mt-1">
            <p className="text-2xl font-extrabold text-amber-600">{pendingDrivers.length}</p>
            <AlertCircle className="w-5 h-5 text-amber-500" />
          </div>
          <span className="text-[11px] text-slate-400">Drivers waiting review</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Active Drivers</span>
          <div className="flex items-center justify-between mt-1">
            <p className="text-2xl font-extrabold text-emerald-600">{activeDrivers.length}</p>
            <Car className="w-5 h-5 text-emerald-500" />
          </div>
          <span className="text-[11px] text-slate-400">Background checked</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Total Bookings</span>
          <div className="flex items-center justify-between mt-1">
            <p className="text-2xl font-extrabold text-blue-600">{bookings.length}</p>
            <BarChart3 className="w-5 h-5 text-blue-500" />
          </div>
          <span className="text-[11px] text-slate-400">All cities</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold uppercase">Platform Revenue</span>
          <div className="flex items-center justify-between mt-1">
            <p className="text-2xl font-extrabold text-purple-600">₹{totalPlatformRevenue.toLocaleString()}</p>
            <DollarSign className="w-5 h-5 text-purple-500" />
          </div>
          <span className="text-[11px] text-slate-400">Total processed fare</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-3 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('verification')}
          className={`py-3 px-5 font-extrabold text-sm border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'verification'
              ? 'border-purple-600 text-purple-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Driver KYC Verification Queue ({pendingDrivers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`py-3 px-5 font-extrabold text-sm border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'analytics'
              ? 'border-purple-600 text-purple-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Analytics & Charts</span>
        </button>

        <button
          onClick={() => setActiveTab('bookings')}
          className={`py-3 px-5 font-extrabold text-sm border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'bookings'
              ? 'border-purple-600 text-purple-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Car className="w-4 h-4" />
          <span>All Trips ({bookings.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`py-3 px-5 font-extrabold text-sm border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'users'
              ? 'border-purple-600 text-purple-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>All Platform Users ({users.length})</span>
        </button>
      </div>

      {/* TAB 1: Driver Verification Queue */}
      {activeTab === 'verification' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-lg text-slate-900">Driver Document Verification Queue</h3>
              <p className="text-xs text-slate-500">
                Inspect Aadhaar identity, RTO driving license number, and police check certificates before activating drivers.
              </p>
            </div>
          </div>

          {pendingDrivers.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
              <h4 className="font-extrabold text-base text-slate-800">All Driver Applications Processed!</h4>
              <p className="text-xs text-slate-500">
                There are currently zero drivers pending approval in the KYC queue.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {pendingDrivers.map((drv) => (
                <div
                  key={drv.id}
                  className="bg-white rounded-3xl border border-amber-200/80 shadow-md p-6 space-y-4"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={drv.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                        alt={drv.name}
                        className="w-14 h-14 rounded-2xl object-cover border"
                      />
                      <div>
                        <h4 className="font-extrabold text-base text-slate-900">{drv.name}</h4>
                        <p className="text-xs text-slate-500">{drv.email} • {drv.mobile}</p>
                        <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 uppercase">
                          Pending Approval
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* KYC Data */}
                  <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3.5 rounded-2xl border border-slate-200/60">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Aadhaar Number</span>
                      <p className="font-bold text-slate-800 mt-0.5">{drv.aadhaarNumber || '1234-5678-9012'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Driving License</span>
                      <p className="font-bold text-slate-800 mt-0.5">{drv.licenseNumber || 'TN09 20180012345'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Specialization</span>
                      <p className="font-bold text-slate-800 mt-0.5">{drv.vehicleType || 'Sedan & SUV'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Experience</span>
                      <p className="font-bold text-slate-800 mt-0.5">{drv.experience || 6} yrs</p>
                    </div>
                  </div>

                  {/* Document check list */}
                  <div className="space-y-1.5 text-xs font-semibold text-slate-700">
                    <div className="flex items-center justify-between py-1 border-b border-slate-100">
                      <span>• Government Aadhaar Biometric Scan</span>
                      <span className="text-emerald-600 font-bold">Uploaded & Checked</span>
                    </div>
                    <div className="flex items-center justify-between py-1 border-b border-slate-100">
                      <span>• RTO DL Commercial Endorsement</span>
                      <span className="text-emerald-600 font-bold">Valid DL</span>
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <span>• Police Character & Background Check</span>
                      <span className="text-emerald-600 font-bold">Clear</span>
                    </div>
                  </div>

                  {/* Approve / Reject Actions */}
                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                    <button
                      onClick={() => handleVerifyDriver(drv.id, 'rejected')}
                      className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                      <span>Reject Application</span>
                    </button>
                    <button
                      onClick={() => handleVerifyDriver(drv.id, 'active')}
                      className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      <span>Approve & Activate Driver</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Analytics & Growth Charts */}
      {activeTab === 'analytics' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Chart 1: Monthly Trip Volume & Revenue */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="font-extrabold text-base text-slate-900">Monthly Completed Trip Growth</h3>
              <p className="text-xs text-slate-500">Number of acting driver trips completed each month across Tamil Nadu & Karnataka</p>

              <div className="h-72 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={tripTrendData}>
                    <defs>
                      <linearGradient id="colorTrips" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#2563EB" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Area type="monotone" dataKey="trips" stroke="#2563EB" strokeWidth={3} fillOpacity={1} fill="url(#colorTrips)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Driver Specialization Distribution */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="font-extrabold text-base text-slate-900">Driver Car Specialization Breakdown</h3>
              <p className="text-xs text-slate-500">Distribution of verified acting driver partners across car segments</p>

              <div className="h-72 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={vehicleDistribution}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="type" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="drivers" fill="#10B981" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: All Bookings */}
      {activeTab === 'bookings' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-lg text-slate-900">Platform Bookings Directory ({bookings.length})</h3>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200/80 overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase">
                  <th className="p-4">Booking ID</th>
                  <th className="p-4">Customer</th>
                  <th className="p-4">Acting Driver</th>
                  <th className="p-4">Route (Pickup -&gt; Dest)</th>
                  <th className="p-4">Vehicle</th>
                  <th className="p-4">Status</th>
                  <th className="p-4">Fare</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-4 font-bold text-slate-900">#{b.id.slice(0, 8)}</td>
                    <td className="p-4">
                      <span className="font-bold text-slate-900 block">{b.customerName}</span>
                      <span className="text-[11px] text-slate-400">{b.customerMobile}</span>
                    </td>
                    <td className="p-4">
                      <span className="font-bold text-slate-900 block">{b.driverName}</span>
                      <span className="text-[11px] text-slate-400">{b.driverMobile}</span>
                    </td>
                    <td className="p-4">
                      <div className="max-w-xs truncate" title={`${b.pickupAddress} -> ${b.destinationAddress}`}>
                        <span>{b.pickupAddress} -&gt; {b.destinationAddress}</span>
                      </div>
                    </td>
                    <td className="p-4">{b.vehicleModel}</td>
                    <td className="p-4">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                          b.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-700'
                            : b.status === 'in-progress'
                            ? 'bg-blue-100 text-blue-700'
                            : b.status === 'accepted'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {b.status}
                      </span>
                    </td>
                    <td className="p-4 font-bold text-emerald-600">₹{b.actualFare || b.estimatedFare}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: Users Directory */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-lg text-slate-900">Platform Members ({users.length})</h3>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200/80 overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase">
                  <th className="p-4">User</th>
                  <th className="p-4">Role</th>
                  <th className="p-4">Status / KYC</th>
                  <th className="p-4">Hourly Rate</th>
                  <th className="p-4">Rating</th>
                  <th className="p-4">Experience</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={u.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                          alt={u.name}
                          className="w-9 h-9 rounded-xl object-cover"
                        />
                        <div>
                          <span className="font-extrabold text-slate-900 block">{u.name}</span>
                          <span className="text-[11px] text-slate-400">{u.email}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                          u.role === 'admin'
                            ? 'bg-purple-100 text-purple-700'
                            : u.role === 'driver'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="p-4">
                      {u.role === 'driver' ? (
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                            u.status === 'active'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-amber-50 text-amber-700'
                          }`}
                        >
                          {u.status}
                        </span>
                      ) : (
                        <span className="text-slate-400">N/A</span>
                      )}
                    </td>
                    <td className="p-4 font-bold text-slate-900">
                      {u.role === 'driver' ? `₹${u.hourlyRate}/hr` : '-'}
                    </td>
                    <td className="p-4 font-bold text-amber-500">
                      {u.role === 'driver' ? `★ ${Number(u.rating || 5.0).toFixed(1)}` : '-'}
                    </td>
                    <td className="p-4">
                      {u.role === 'driver' ? `${u.experience || 5} yrs` : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
