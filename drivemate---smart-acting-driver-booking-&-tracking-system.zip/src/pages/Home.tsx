import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, Car, Star, Clock, MapPin, CheckCircle2, ArrowRight, Award, Phone, Users, Sparkles, Navigation } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [pickupCity, setPickupCity] = useState('Chennai');
  const [vehicleType, setVehicleType] = useState('All');
  const [tripType, setTripType] = useState('Hourly Acting Driver');

  const handleQuickSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/drivers?city=${encodeURIComponent(pickupCity)}&vehicle=${encodeURIComponent(vehicleType)}`);
  };

  return (
    <div className="space-y-20 pb-24">
      {/* Hero Section */}
      <section className="relative pt-10 pb-20 bg-gradient-to-b from-blue-900 via-slate-900 to-slate-900 text-white overflow-hidden">
        {/* Background glow effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-blue-500/20 blur-3xl rounded-full pointer-events-none" />
        <div className="absolute top-10 right-10 w-96 h-96 bg-indigo-500/10 blur-3xl rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Copy */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-400/30 text-blue-300 text-xs font-bold uppercase tracking-wider">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>100% Background-Checked Acting Drivers</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
                Hire India&apos;s Most Trusted <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">Acting Drivers</span> For Your Own Car
              </h1>

              <p className="text-lg text-slate-300 max-w-2xl leading-relaxed">
                Whether it&apos;s a city commute, airport drop, late-night party return, or outstation weekend trip, book professional, RTO-verified acting drivers with 24/7 live GPS emergency tracking.
              </p>

              {/* Trust badges row */}
              <div className="flex flex-wrap items-center gap-6 pt-2 text-sm text-slate-300 font-semibold">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>Aadhaar & Police Verified</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>Live GPS Movement</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>From ₹180/hour</span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-4">
                <Link
                  to="/drivers"
                  className="px-8 py-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-base shadow-lg shadow-blue-600/30 transition-all flex items-center gap-2.5"
                >
                  <span>Find Available Drivers</span>
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/about"
                  className="px-8 py-4 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-extrabold text-base border border-white/15 transition-all"
                >
                  How It Works
                </Link>
              </div>
            </div>

            {/* Right Booking Quick Widget */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 text-slate-900">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
                  <div>
                    <h3 className="font-extrabold text-xl text-slate-900">Book an Acting Driver</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Instant booking or schedule in advance</p>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-blue-50 text-blue-600">
                    <Car className="w-6 h-6" />
                  </div>
                </div>

                <form onSubmit={handleQuickSearch} className="space-y-4">
                  <div>
                    <label htmlFor="service-city-select" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Service City
                    </label>
                    <div className="relative">
                      <MapPin className="w-4 h-4 text-blue-600 absolute left-3 top-3.5" />
                      <select
                        id="service-city-select"
                        value={pickupCity}
                        onChange={(e) => setPickupCity(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 text-sm font-semibold text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Chennai">Chennai, Tamil Nadu</option>
                        <option value="Bangalore">Bangalore, Karnataka</option>
                        <option value="Hyderabad">Hyderabad, Telangana</option>
                        <option value="Coimbatore">Coimbatore, Tamil Nadu</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="trip-type-select" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Trip Type
                    </label>
                    <select
                      id="trip-type-select"
                      value={tripType}
                      onChange={(e) => setTripType(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm font-semibold text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Hourly Acting Driver">City Hourly Acting Driver (Min 3 hrs)</option>
                      <option value="Airport Transfer">Airport Drop / Pickup (Fixed Fare)</option>
                      <option value="Outstation Trip">Outstation / Weekend Trip</option>
                      <option value="Designated Driver">Late Night Party Designated Driver</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="car-type-select" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Your Car Type
                    </label>
                    <select
                      id="car-type-select"
                      value={vehicleType}
                      onChange={(e) => setVehicleType(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm font-semibold text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="All">All Car Types (Sedan, SUV, Hatchback)</option>
                      <option value="Sedan">Sedan (City, Verna, Ciaz)</option>
                      <option value="SUV">SUV (Innova, Creta, Fortuner)</option>
                      <option value="Luxury">Luxury & Automatic (BMW, Merc, EV)</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    <span>Search Verified Drivers</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>

                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span>Average ETA: <strong>15–25 mins</strong></span>
                  <span><strong>4,200+</strong> drivers online</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Counter Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          <div>
            <p className="text-3xl sm:text-4xl font-extrabold text-blue-600">50,000+</p>
            <p className="text-sm font-bold text-slate-700 mt-1">Safe Trips Completed</p>
            <p className="text-xs text-slate-500 mt-0.5">Zero accident guarantee standard</p>
          </div>
          <div>
            <p className="text-3xl sm:text-4xl font-extrabold text-emerald-600">4,200+</p>
            <p className="text-sm font-bold text-slate-700 mt-1">Verified Acting Drivers</p>
            <p className="text-xs text-slate-500 mt-0.5">Rigorous 5-step background checks</p>
          </div>
          <div>
            <p className="text-3xl sm:text-4xl font-extrabold text-amber-500">4.9 / 5.0</p>
            <p className="text-sm font-bold text-slate-700 mt-1">Average Driver Rating</p>
            <p className="text-xs text-slate-500 mt-0.5">Based on 32,000+ customer reviews</p>
          </div>
          <div>
            <p className="text-3xl sm:text-4xl font-extrabold text-purple-600">&lt; 20 Mins</p>
            <p className="text-sm font-bold text-slate-700 mt-1">Average Doorstep ETA</p>
            <p className="text-xs text-slate-500 mt-0.5">Fast GPS dispatch in metro cities</p>
          </div>
        </div>
      </section>

      {/* Why Choose DriveMate */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-extrabold uppercase tracking-widest text-blue-600 bg-blue-50 px-3 py-1.5 rounded-full">
            Why DriveMate?
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-4">
            Safety, Reliability & Complete Peace of Mind
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-3">
            Your car is your prized possession. Here is why thousands of car owners trust DriveMate acting drivers every day.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-3xl border border-slate-200/80 shadow-xs hover:shadow-lg transition-all">
            <div className="w-14 h-14 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mb-6">
              <Shield className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Strict Background Verification</h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Every driver undergoes Aadhaar authentication, RTO driving license verification, police background checks, and practical driving skill assessments before joining.
            </p>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200/80 shadow-xs hover:shadow-lg transition-all">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-6">
              <Navigation className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">24/7 Live GPS Tracking</h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Track your driver&apos;s real-time movement on Leaflet interactive maps. Share live trip tracking links with family members for maximum safety.
            </p>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200/80 shadow-xs hover:shadow-lg transition-all">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mb-6">
              <Award className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Transparent Hourly Pricing</h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              No surge pricing or hidden fees. Transparent hourly rates starting at ₹180/hour with simple digital payments and instant GST-compliant invoicing.
            </p>
          </div>
        </div>
      </section>

      {/* Driver Specializations Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-slate-900 to-indigo-950 rounded-3xl p-8 sm:p-12 text-white flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl">
          <div className="space-y-4 max-w-2xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Drive Your Own Car Safely</span>
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
              Are you an experienced professional driver? Join India&apos;s fastest growing acting driver network today.
            </h3>
            <p className="text-sm text-slate-300 leading-relaxed">
              Earn up to ₹35,000/month with flexible hours, instant weekly payouts, and zero commission on tips.
            </p>
          </div>
          <div>
            <Link
              to="/register?role=driver"
              className="px-8 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-sm transition-all shadow-lg shadow-emerald-500/20 whitespace-nowrap block text-center"
            >
              Apply as Driver Partner
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-extrabold uppercase tracking-widest text-blue-600 bg-blue-50 px-3 py-1.5 rounded-full">
            Customer Stories
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 mt-3">
            Trusted by Car Owners Across Tamil Nadu & Karnataka
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              author: 'Karthik Sunder',
              role: 'BMW 5-Series Owner, Chennai',
              content: 'Finding a reliable acting driver who knows how to handle automatic luxury sedans gently was difficult until I used DriveMate. Rajesh was punctual, extremely polite, and drove perfectly through ECR traffic.',
              rating: 5,
              avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'
            },
            {
              author: 'Dr. Priya Narayanan',
              role: 'Doctor, Apollo Hospitals',
              content: 'After long 12-hour surgical shifts, I book a DriveMate acting driver to drive my car home. The live GPS tracking gives my family complete peace of mind. Truly a lifesaver!',
              rating: 5,
              avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80'
            },
            {
              author: 'Arun Venkatesh',
              role: 'Business Owner, Bangalore',
              content: 'We use DriveMate for our outstation weekend trips to Ooty and Coorg. The drivers are background verified and know mountain highway driving rules very well. Highly recommended!',
              rating: 5,
              avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80'
            }
          ].map((test, idx) => (
            <div key={idx} className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex text-amber-400 mb-4">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star key={s} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <p className="text-sm text-slate-700 italic leading-relaxed">&ldquo;{test.content}&rdquo;</p>
              </div>
              <div className="flex items-center gap-3 mt-6 pt-4 border-t border-slate-100">
                <img
                  src={test.avatar}
                  alt={test.author}
                  className="w-11 h-11 rounded-full object-cover border"
                />
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{test.author}</h4>
                  <p className="text-xs text-slate-500">{test.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
