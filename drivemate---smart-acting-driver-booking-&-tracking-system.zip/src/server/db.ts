import initSqlJs, { Database as SqlJsDatabase } from 'sql.js';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  User,
  Booking,
  DriverLocation,
  Rating,
  Feedback,
  NotificationItem,
  FAQItem,
  Testimonial,
  BookingStatus,
  DriverStatus
} from './types.js';

let db: SqlJsDatabase;
const DB_PATH = path.join(process.cwd(), 'drivemate.sqlite');

export async function initDB(): Promise<void> {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    try {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(new Uint8Array(fileBuffer));
      console.log('Loaded existing SQLite database from disk');
    } catch (err) {
      console.warn('Could not read existing database, creating fresh:', err);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
    console.log('Initialized new SQLite database');
  }

  createTables();
  seedInitialData();
  saveDB();
}

export function saveDB(): void {
  try {
    if (!db) return;
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  } catch (err) {
    console.error('Error saving SQLite DB to disk:', err);
  }
}

function createTables(): void {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      role TEXT NOT NULL,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      mobile TEXT NOT NULL,
      password TEXT NOT NULL,
      status TEXT,
      address TEXT,
      aadhaarNumber TEXT,
      licenseNumber TEXT,
      vehicleType TEXT,
      vehicleNumber TEXT,
      experience INTEGER,
      avatarUrl TEXT,
      rating REAL DEFAULT 5.0,
      totalTrips INTEGER DEFAULT 0,
      hourlyRate INTEGER DEFAULT 180,
      isOnline INTEGER DEFAULT 0,
      documentUrls TEXT,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY,
      customerId TEXT NOT NULL,
      customerName TEXT NOT NULL,
      customerMobile TEXT NOT NULL,
      driverId TEXT NOT NULL,
      driverName TEXT NOT NULL,
      driverMobile TEXT NOT NULL,
      pickupAddress TEXT NOT NULL,
      pickupLat REAL NOT NULL,
      pickupLng REAL NOT NULL,
      destinationAddress TEXT NOT NULL,
      destinationLat REAL NOT NULL,
      destinationLng REAL NOT NULL,
      vehicleType TEXT NOT NULL,
      vehicleModel TEXT NOT NULL,
      vehicleNumber TEXT NOT NULL,
      tripDate TEXT NOT NULL,
      tripTime TEXT NOT NULL,
      status TEXT NOT NULL,
      estimatedFare REAL NOT NULL,
      actualFare REAL,
      distanceKm REAL NOT NULL,
      etaMinutes INTEGER NOT NULL,
      createdAt TEXT NOT NULL,
      startedAt TEXT,
      completedAt TEXT,
      cancellationReason TEXT
    );

    CREATE TABLE IF NOT EXISTS driver_locations (
      id TEXT PRIMARY KEY,
      driverId TEXT UNIQUE NOT NULL,
      lat REAL NOT NULL,
      lng REAL NOT NULL,
      isOnline INTEGER NOT NULL DEFAULT 1,
      heading INTEGER DEFAULT 0,
      lastUpdated TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ratings (
      id TEXT PRIMARY KEY,
      bookingId TEXT NOT NULL,
      customerId TEXT NOT NULL,
      customerName TEXT NOT NULL,
      driverId TEXT NOT NULL,
      behaviour INTEGER NOT NULL,
      drivingSkill INTEGER NOT NULL,
      safety INTEGER NOT NULL,
      communication INTEGER NOT NULL,
      vehicleCleanliness INTEGER NOT NULL,
      overall REAL NOT NULL,
      comment TEXT,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS feedbacks (
      id TEXT PRIMARY KEY,
      userId TEXT NOT NULL,
      userName TEXT NOT NULL,
      userEmail TEXT NOT NULL,
      category TEXT NOT NULL,
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      createdAt TEXT NOT NULL,
      adminReply TEXT
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      userId TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL,
      isRead INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL,
      link TEXT
    );

    CREATE TABLE IF NOT EXISTS faqs (
      id TEXT PRIMARY KEY,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      category TEXT NOT NULL,
      isPublished INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS testimonials (
      id TEXT PRIMARY KEY,
      author TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      rating INTEGER NOT NULL,
      avatarUrl TEXT NOT NULL
    );
  `);
}

function seedInitialData(): void {
  const result = db.exec('SELECT COUNT(*) as cnt FROM users');
  const count = result[0]?.values[0]?.[0] as number;
  if (count && count > 0) return; // already seeded

  console.log('Seeding initial DriveMate database...');
  const salt = bcrypt.genSaltSync(10);
  const hash = (pass: string) => bcrypt.hashSync(pass, salt);

  // Seed Admin
  insertUser({
    id: 'admin-1',
    role: 'admin',
    name: 'Rajaram (Admin)',
    email: 'admin@drivemate.com',
    mobile: '9876543210',
    password: hash('admin123'),
    createdAt: new Date().toISOString()
  });

  // Seed Active Drivers
  const activeDrivers: User[] = [
    {
      id: 'driver-1',
      role: 'driver',
      name: 'Rajesh Kumar',
      email: 'rajesh@drivemate.com',
      mobile: '9840123456',
      password: hash('driver123'),
      status: 'active',
      address: 'T. Nagar, Chennai',
      aadhaarNumber: '8912 3456 7890',
      licenseNumber: 'TN01-2015-0012345',
      vehicleType: 'Sedan',
      vehicleNumber: 'TN09 AB 1234',
      experience: 8,
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      rating: 4.9,
      totalTrips: 340,
      hourlyRate: 180,
      isOnline: true,
      documentUrls: {
        photo: 'verified_photo.jpg',
        license: 'verified_license.pdf',
        aadhaar: 'verified_aadhaar.pdf',
        rcBook: 'verified_rc.pdf',
        insurance: 'verified_ins.pdf'
      },
      createdAt: new Date(Date.now() - 60 * 86400000).toISOString()
    },
    {
      id: 'driver-2',
      role: 'driver',
      name: 'Vikram Singh',
      email: 'vikram@drivemate.com',
      mobile: '9840987654',
      password: hash('driver123'),
      status: 'active',
      address: 'Indiranagar, Bangalore',
      aadhaarNumber: '4512 8976 1122',
      licenseNumber: 'KA03-2017-0098765',
      vehicleType: 'SUV',
      vehicleNumber: 'KA01 MN 4567',
      experience: 11,
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      rating: 4.85,
      totalTrips: 412,
      hourlyRate: 220,
      isOnline: true,
      documentUrls: {
        photo: 'verified_photo.jpg',
        license: 'verified_license.pdf',
        aadhaar: 'verified_aadhaar.pdf',
        rcBook: 'verified_rc.pdf',
        insurance: 'verified_ins.pdf'
      },
      createdAt: new Date(Date.now() - 45 * 86400000).toISOString()
    },
    {
      id: 'driver-3',
      role: 'driver',
      name: 'Priya Sharma',
      email: 'priya@drivemate.com',
      mobile: '9840556677',
      password: hash('driver123'),
      status: 'active',
      address: 'Bandra West, Mumbai',
      aadhaarNumber: '6712 9087 4321',
      licenseNumber: 'MH02-2019-0044332',
      vehicleType: 'Luxury',
      vehicleNumber: 'MH02 EF 8899',
      experience: 6,
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      rating: 4.95,
      totalTrips: 210,
      hourlyRate: 300,
      isOnline: true,
      documentUrls: {
        photo: 'verified_photo.jpg',
        license: 'verified_license.pdf',
        aadhaar: 'verified_aadhaar.pdf',
        rcBook: 'verified_rc.pdf',
        insurance: 'verified_ins.pdf'
      },
      createdAt: new Date(Date.now() - 30 * 86400000).toISOString()
    },
    {
      id: 'driver-4',
      role: 'driver',
      name: 'Anbu Selvan',
      email: 'anbu@drivemate.com',
      mobile: '9840332211',
      password: hash('driver123'),
      status: 'active',
      address: 'Adyar, Chennai',
      aadhaarNumber: '3321 4455 6677',
      licenseNumber: 'TN07-2014-0011998',
      vehicleType: 'Hatchback',
      vehicleNumber: 'TN07 CD 2345',
      experience: 14,
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
      rating: 4.88,
      totalTrips: 530,
      hourlyRate: 160,
      isOnline: true,
      documentUrls: {
        photo: 'verified_photo.jpg',
        license: 'verified_license.pdf',
        aadhaar: 'verified_aadhaar.pdf',
        rcBook: 'verified_rc.pdf',
        insurance: 'verified_ins.pdf'
      },
      createdAt: new Date(Date.now() - 90 * 86400000).toISOString()
    }
  ];

  activeDrivers.forEach(insertUser);

  // Seed Pending Drivers (Waiting in Admin Approval Queue)
  const pendingDrivers: User[] = [
    {
      id: 'driver-5',
      role: 'driver',
      name: 'Suresh Mohan',
      email: 'suresh@drivemate.com',
      mobile: '9840112233',
      password: hash('driver123'),
      status: 'pending_approval',
      address: 'Velachery, Chennai',
      aadhaarNumber: '9901 8877 6655',
      licenseNumber: 'TN14-2021-0099887',
      vehicleType: 'Sedan',
      vehicleNumber: 'TN14 GH 7890',
      experience: 5,
      avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
      rating: 5.0,
      totalTrips: 0,
      hourlyRate: 180,
      isOnline: false,
      documentUrls: {
        photo: 'uploaded_photo.jpg',
        license: 'uploaded_license.pdf',
        aadhaar: 'uploaded_aadhaar.pdf',
        rcBook: 'uploaded_rc.pdf',
        insurance: 'uploaded_ins.pdf'
      },
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString()
    },
    {
      id: 'driver-6',
      role: 'driver',
      name: 'Karthik Raj',
      email: 'karthik@drivemate.com',
      mobile: '9840445566',
      password: hash('driver123'),
      status: 'pending_approval',
      address: 'Whitefield, Bangalore',
      aadhaarNumber: '7788 9900 1122',
      licenseNumber: 'KA53-2022-0033445',
      vehicleType: 'SUV',
      vehicleNumber: 'KA53 XY 9012',
      experience: 4,
      avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80',
      rating: 5.0,
      totalTrips: 0,
      hourlyRate: 200,
      isOnline: false,
      documentUrls: {
        photo: 'uploaded_photo.jpg',
        license: 'uploaded_license.pdf',
        aadhaar: 'uploaded_aadhaar.pdf',
        rcBook: 'uploaded_rc.pdf',
        insurance: 'uploaded_ins.pdf'
      },
      createdAt: new Date(Date.now() - 1 * 86400000).toISOString()
    }
  ];

  pendingDrivers.forEach(insertUser);

  // Seed Customers
  const customers: User[] = [
    {
      id: 'customer-1',
      role: 'customer',
      name: 'M. Rajaram',
      email: 'customer@drivemate.com',
      mobile: '9884001122',
      password: hash('customer123'),
      createdAt: new Date(Date.now() - 30 * 86400000).toISOString()
    },
    {
      id: 'customer-2',
      role: 'customer',
      name: 'Anita Nair',
      email: 'anita@example.com',
      mobile: '9884112233',
      password: hash('customer123'),
      createdAt: new Date(Date.now() - 20 * 86400000).toISOString()
    }
  ];

  customers.forEach(insertUser);

  // Seed Driver Locations (Chennai & Bangalore coordinates for realistic live tracking)
  const initialLocations: DriverLocation[] = [
    {
      id: 'loc-1',
      driverId: 'driver-1',
      lat: 13.0405, // T Nagar Chennai
      lng: 80.2337,
      isOnline: true,
      heading: 90,
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'loc-2',
      driverId: 'driver-2',
      lat: 12.9784, // Indiranagar Bangalore
      lng: 77.6408,
      isOnline: true,
      heading: 180,
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'loc-3',
      driverId: 'driver-3',
      lat: 19.0596, // Bandra West Mumbai
      lng: 72.8295,
      isOnline: true,
      heading: 270,
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'loc-4',
      driverId: 'driver-4',
      lat: 13.0012, // Adyar Chennai
      lng: 80.2565,
      isOnline: true,
      heading: 45,
      lastUpdated: new Date().toISOString()
    }
  ];

  initialLocations.forEach(upsertDriverLocation);

  // Seed Bookings
  const seedBookings: Booking[] = [
    {
      id: 'book-1',
      customerId: 'customer-1',
      customerName: 'M. Rajaram',
      customerMobile: '9884001122',
      driverId: 'driver-1',
      driverName: 'Rajesh Kumar',
      driverMobile: '9840123456',
      pickupAddress: 'Anna Nagar West, Chennai',
      pickupLat: 13.0850,
      pickupLng: 80.2101,
      destinationAddress: 'Chennai International Airport, Meenambakkam',
      destinationLat: 12.9941,
      destinationLng: 80.1709,
      vehicleType: 'Sedan',
      vehicleModel: 'Honda City 2023 (Automatic)',
      vehicleNumber: 'TN09 AB 1234',
      tripDate: new Date().toISOString().split('T')[0],
      tripTime: '18:30',
      status: 'in-progress',
      estimatedFare: 540,
      distanceKm: 18.5,
      etaMinutes: 35,
      createdAt: new Date(Date.now() - 30 * 60000).toISOString(),
      startedAt: new Date(Date.now() - 20 * 60000).toISOString()
    },
    {
      id: 'book-2',
      customerId: 'customer-1',
      customerName: 'M. Rajaram',
      customerMobile: '9884001122',
      driverId: 'driver-4',
      driverName: 'Anbu Selvan',
      driverMobile: '9840332211',
      pickupAddress: 'Adyar Signal, Chennai',
      pickupLat: 13.0012,
      pickupLng: 80.2565,
      destinationAddress: 'ECR Beach Resort, Muthukadu',
      destinationLat: 12.8256,
      destinationLng: 80.2443,
      vehicleType: 'Hatchback',
      vehicleModel: 'Maruti Baleno 2022',
      vehicleNumber: 'TN07 CD 2345',
      tripDate: new Date(Date.now() - 86400000).toISOString().split('T')[0],
      tripTime: '10:00',
      status: 'completed',
      estimatedFare: 720,
      actualFare: 720,
      distanceKm: 24.2,
      etaMinutes: 45,
      createdAt: new Date(Date.now() - 86400000 - 3600000).toISOString(),
      startedAt: new Date(Date.now() - 86400000 - 3000000).toISOString(),
      completedAt: new Date(Date.now() - 86400000).toISOString()
    },
    {
      id: 'book-3',
      customerId: 'customer-2',
      customerName: 'Anita Nair',
      customerMobile: '9884112233',
      driverId: 'driver-2',
      driverName: 'Vikram Singh',
      driverMobile: '9840987654',
      pickupAddress: 'Indiranagar Metro Station, Bangalore',
      pickupLat: 12.9784,
      pickupLng: 77.6408,
      destinationAddress: 'Electronic City Phase 1, Bangalore',
      destinationLat: 12.8452,
      destinationLng: 77.6602,
      vehicleType: 'SUV',
      vehicleModel: 'Hyundai Creta 2024',
      vehicleNumber: 'KA01 MN 4567',
      tripDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
      tripTime: '09:15',
      status: 'requested',
      estimatedFare: 660,
      distanceKm: 19.8,
      etaMinutes: 40,
      createdAt: new Date().toISOString()
    }
  ];

  seedBookings.forEach(insertBooking);

  // Seed Rating
  insertRating({
    id: 'rate-1',
    bookingId: 'book-2',
    customerId: 'customer-1',
    customerName: 'M. Rajaram',
    driverId: 'driver-4',
    behaviour: 5,
    drivingSkill: 5,
    safety: 5,
    communication: 5,
    vehicleCleanliness: 4,
    overall: 4.8,
    comment: 'Anbu was extremely polite, punctual, and drove my car with great care along ECR. High recommendation!',
    createdAt: new Date(Date.now() - 86400000).toISOString()
  });

  // Seed FAQs
  const seedFaqs: FAQItem[] = [
    {
      id: 'faq-1',
      question: 'What is an Acting / Designated Driver?',
      answer: 'An acting driver is a professional, background-verified driver hired to drive your own vehicle for a few hours, a full day, or outstation trips.',
      category: 'General',
      isPublished: true
    },
    {
      id: 'faq-2',
      question: 'How are drivers verified on DriveMate?',
      answer: 'Every driver undergoes 5-step verification: Aadhaar identity verification, valid RTO driving license check, criminal record screening, and prior driving test evaluation.',
      category: 'Safety',
      isPublished: true
    },
    {
      id: 'faq-3',
      question: 'How is the trip fare calculated?',
      answer: 'Trip fares are calculated based on hourly acting rates (ranging from Rs 160 to Rs 300 per hour depending on vehicle category) plus a nominal base charge.',
      category: 'Billing',
      isPublished: true
    },
    {
      id: 'faq-4',
      question: 'Can I track my vehicle in real-time during a trip?',
      answer: 'Yes! Our live GPS tracking feature allows you or your family members to monitor the vehicle location and ETA on an interactive map.',
      category: 'Safety',
      isPublished: true
    }
  ];

  seedFaqs.forEach(insertFAQ);

  // Seed Testimonials
  const seedTestimonials: Testimonial[] = [
    {
      id: 'test-1',
      author: 'Karthik Subramanian',
      role: 'Business Owner, Chennai',
      content: 'I frequently book acting drivers for airport drops and late-night dinners. Rajesh Kumar was professional, on time, and handled my automatic sedan perfectly.',
      rating: 5,
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'
    },
    {
      id: 'test-2',
      author: 'Dr. Meenakshi Sundaram',
      role: 'Physician, Bangalore',
      content: 'Safety is my top priority when hiring someone to drive my car. DriveMate’s background-checked drivers give me complete peace of mind.',
      rating: 5,
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
    },
    {
      id: 'test-3',
      author: 'Rahul Verma',
      role: 'Corporate Executive, Mumbai',
      content: 'The real-time tracking and instant ETA updates are fantastic. Best acting driver service I’ve used so far.',
      rating: 5,
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80'
    }
  ];

  seedTestimonials.forEach(insertTestimonial);

  console.log('Successfully seeded DriveMate SQLite database!');
}

// ================= CRUD Helpers =================

export function insertUser(user: User): void {
  db.run(`
    INSERT OR REPLACE INTO users (
      id, role, name, email, mobile, password, status, address, aadhaarNumber,
      licenseNumber, vehicleType, vehicleNumber, experience, avatarUrl,
      rating, totalTrips, hourlyRate, isOnline, documentUrls, createdAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    user.id, user.role, user.name, user.email.toLowerCase(), user.mobile,
    user.password || '', user.status || '', user.address || '', user.aadhaarNumber || '',
    user.licenseNumber || '', user.vehicleType || '', user.vehicleNumber || '',
    user.experience || 0, user.avatarUrl || '', user.rating || 5.0,
    user.totalTrips || 0, user.hourlyRate || 180, user.isOnline ? 1 : 0,
    user.documentUrls ? JSON.stringify(user.documentUrls) : '{}', user.createdAt
  ]);
  saveDB();
}

export function getAllUsers(role?: string): User[] {
  let query = 'SELECT * FROM users';
  const params: any[] = [];
  if (role) {
    query += ' WHERE role = ?';
    params.push(role);
  }
  query += ' ORDER BY createdAt DESC';
  const results = db.exec(query, params);
  return parseUserRows(results[0]);
}

export function getUserById(id: string): User | null {
  const results = db.exec('SELECT * FROM users WHERE id = ?', [id]);
  const users = parseUserRows(results[0]);
  return users[0] || null;
}

export function getUserByEmail(email: string): User | null {
  const results = db.exec('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
  const users = parseUserRows(results[0]);
  return users[0] || null;
}

export function updateUserStatus(id: string, status: DriverStatus): void {
  db.run('UPDATE users SET status = ? WHERE id = ?', [status, id]);
  saveDB();
}

export function updateDriverOnlineStatus(id: string, isOnline: boolean): void {
  db.run('UPDATE users SET isOnline = ? WHERE id = ?', [isOnline ? 1 : 0, id]);
  saveDB();
}

function parseUserRows(res: any): User[] {
  if (!res || !res.values) return [];
  return res.values.map((row: any[]) => ({
    id: String(row[0]),
    role: row[1] as any,
    name: String(row[2]),
    email: String(row[3]),
    mobile: String(row[4]),
    password: String(row[5]),
    status: (row[6] as any) || undefined,
    address: row[7] || undefined,
    aadhaarNumber: row[8] || undefined,
    licenseNumber: row[9] || undefined,
    vehicleType: row[10] || undefined,
    vehicleNumber: row[11] || undefined,
    experience: Number(row[12] || 0),
    avatarUrl: row[13] || undefined,
    rating: Number(row[14] || 5.0),
    totalTrips: Number(row[15] || 0),
    hourlyRate: Number(row[16] || 180),
    isOnline: Boolean(row[17]),
    documentUrls: row[18] ? JSON.parse(row[18]) : {},
    createdAt: String(row[19])
  }));
}

// Bookings
export function insertBooking(booking: Booking): void {
  db.run(`
    INSERT OR REPLACE INTO bookings (
      id, customerId, customerName, customerMobile, driverId, driverName, driverMobile,
      pickupAddress, pickupLat, pickupLng, destinationAddress, destinationLat, destinationLng,
      vehicleType, vehicleModel, vehicleNumber, tripDate, tripTime, status, estimatedFare,
      actualFare, distanceKm, etaMinutes, createdAt, startedAt, completedAt, cancellationReason
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    booking.id, booking.customerId, booking.customerName, booking.customerMobile,
    booking.driverId, booking.driverName, booking.driverMobile, booking.pickupAddress,
    booking.pickupLat, booking.pickupLng, booking.destinationAddress, booking.destinationLat,
    booking.destinationLng, booking.vehicleType, booking.vehicleModel, booking.vehicleNumber,
    booking.tripDate, booking.tripTime, booking.status, booking.estimatedFare,
    booking.actualFare || null, booking.distanceKm, booking.etaMinutes, booking.createdAt,
    booking.startedAt || null, booking.completedAt || null, booking.cancellationReason || null
  ]);
  saveDB();
}

export function getBookings(filters?: { customerId?: string; driverId?: string; status?: BookingStatus }): Booking[] {
  let query = 'SELECT * FROM bookings WHERE 1=1';
  const params: any[] = [];
  if (filters?.customerId) {
    query += ' AND customerId = ?';
    params.push(filters.customerId);
  }
  if (filters?.driverId) {
    query += ' AND driverId = ?';
    params.push(filters.driverId);
  }
  if (filters?.status) {
    query += ' AND status = ?';
    params.push(filters.status);
  }
  query += ' ORDER BY createdAt DESC';
  const results = db.exec(query, params);
  return parseBookingRows(results[0]);
}

export function getBookingById(id: string): Booking | null {
  const results = db.exec('SELECT * FROM bookings WHERE id = ?', [id]);
  const bookings = parseBookingRows(results[0]);
  return bookings[0] || null;
}

export function updateBookingStatus(
  id: string,
  status: BookingStatus,
  extra?: { startedAt?: string; completedAt?: string; actualFare?: number; cancellationReason?: string }
): Booking | null {
  let sql = 'UPDATE bookings SET status = ?';
  const params: any[] = [status];
  if (extra?.startedAt) {
    sql += ', startedAt = ?';
    params.push(extra.startedAt);
  }
  if (extra?.completedAt) {
    sql += ', completedAt = ?';
    params.push(extra.completedAt);
  }
  if (extra?.actualFare !== undefined) {
    sql += ', actualFare = ?';
    params.push(extra.actualFare);
  }
  if (extra?.cancellationReason) {
    sql += ', cancellationReason = ?';
    params.push(extra.cancellationReason);
  }
  sql += ' WHERE id = ?';
  params.push(id);

  db.run(sql, params);
  saveDB();
  return getBookingById(id);
}

function parseBookingRows(res: any): Booking[] {
  if (!res || !res.values) return [];
  return res.values.map((row: any[]) => ({
    id: String(row[0]),
    customerId: String(row[1]),
    customerName: String(row[2]),
    customerMobile: String(row[3]),
    driverId: String(row[4]),
    driverName: String(row[5]),
    driverMobile: String(row[6]),
    pickupAddress: String(row[7]),
    pickupLat: Number(row[8]),
    pickupLng: Number(row[9]),
    destinationAddress: String(row[10]),
    destinationLat: Number(row[11]),
    destinationLng: Number(row[12]),
    vehicleType: String(row[13]),
    vehicleModel: String(row[14]),
    vehicleNumber: String(row[15]),
    tripDate: String(row[16]),
    tripTime: String(row[17]),
    status: row[18] as BookingStatus,
    estimatedFare: Number(row[19]),
    actualFare: row[20] ? Number(row[20]) : undefined,
    distanceKm: Number(row[21]),
    etaMinutes: Number(row[22]),
    createdAt: String(row[23]),
    startedAt: row[24] || undefined,
    completedAt: row[25] || undefined,
    cancellationReason: row[26] || undefined
  }));
}

// Driver Locations
export function upsertDriverLocation(loc: DriverLocation): void {
  db.run(`
    INSERT OR REPLACE INTO driver_locations (id, driverId, lat, lng, isOnline, heading, lastUpdated)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `, [
    loc.id, loc.driverId, loc.lat, loc.lng, loc.isOnline ? 1 : 0, loc.heading, loc.lastUpdated
  ]);
  saveDB();
}

export function getDriverLocation(driverId: string): DriverLocation | null {
  const results = db.exec('SELECT * FROM driver_locations WHERE driverId = ?', [driverId]);
  const locs = parseLocationRows(results[0]);
  return locs[0] || null;
}

export function getAllDriverLocations(): DriverLocation[] {
  const results = db.exec('SELECT * FROM driver_locations WHERE isOnline = 1');
  return parseLocationRows(results[0]);
}

function parseLocationRows(res: any): DriverLocation[] {
  if (!res || !res.values) return [];
  return res.values.map((row: any[]) => ({
    id: String(row[0]),
    driverId: String(row[1]),
    lat: Number(row[2]),
    lng: Number(row[3]),
    isOnline: Boolean(row[4]),
    heading: Number(row[5]),
    lastUpdated: String(row[6])
  }));
}

// Ratings
export function insertRating(r: Rating): void {
  db.run(`
    INSERT INTO ratings (
      id, bookingId, customerId, customerName, driverId,
      behaviour, drivingSkill, safety, communication, vehicleCleanliness,
      overall, comment, createdAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    r.id, r.bookingId, r.customerId, r.customerName, r.driverId,
    r.behaviour, r.drivingSkill, r.safety, r.communication, r.vehicleCleanliness,
    r.overall, r.comment, r.createdAt
  ]);

  // Recalculate average rating for driver
  const stats = db.exec('SELECT AVG(overall) as avgRate, COUNT(*) as cnt FROM ratings WHERE driverId = ?', [r.driverId]);
  const avg = stats[0]?.values[0]?.[0] || 5.0;
  db.run('UPDATE users SET rating = ? WHERE id = ?', [Number(avg).toFixed(2), r.driverId]);
  saveDB();
}

export function getRatingsByDriver(driverId: string): Rating[] {
  const results = db.exec('SELECT * FROM ratings WHERE driverId = ? ORDER BY createdAt DESC', [driverId]);
  if (!results[0] || !results[0].values) return [];
  return results[0].values.map((row: any[]) => ({
    id: String(row[0]),
    bookingId: String(row[1]),
    customerId: String(row[2]),
    customerName: String(row[3]),
    driverId: String(row[4]),
    behaviour: Number(row[5]),
    drivingSkill: Number(row[6]),
    safety: Number(row[7]),
    communication: Number(row[8]),
    vehicleCleanliness: Number(row[9]),
    overall: Number(row[10]),
    comment: String(row[11] || ''),
    createdAt: String(row[12])
  }));
}

// FAQs
export function insertFAQ(faq: FAQItem): void {
  db.run('INSERT OR REPLACE INTO faqs (id, question, answer, category, isPublished) VALUES (?, ?, ?, ?, ?)', [
    faq.id, faq.question, faq.answer, faq.category, faq.isPublished ? 1 : 0
  ]);
  saveDB();
}

export function getAllFAQs(): FAQItem[] {
  const results = db.exec('SELECT * FROM faqs WHERE isPublished = 1');
  if (!results[0] || !results[0].values) return [];
  return results[0].values.map((row: any[]) => ({
    id: String(row[0]),
    question: String(row[1]),
    answer: String(row[2]),
    category: String(row[3]),
    isPublished: Boolean(row[4])
  }));
}

// Testimonials
export function insertTestimonial(t: Testimonial): void {
  db.run('INSERT OR REPLACE INTO testimonials (id, author, role, content, rating, avatarUrl) VALUES (?, ?, ?, ?, ?, ?)', [
    t.id, t.author, t.role, t.content, t.rating, t.avatarUrl
  ]);
  saveDB();
}

export function getAllTestimonials(): Testimonial[] {
  const results = db.exec('SELECT * FROM testimonials');
  if (!results[0] || !results[0].values) return [];
  return results[0].values.map((row: any[]) => ({
    id: String(row[0]),
    author: String(row[1]),
    role: String(row[2]),
    content: String(row[3]),
    rating: Number(row[4]),
    avatarUrl: String(row[5])
  }));
}

// Feedbacks
export function insertFeedback(f: Feedback): void {
  db.run('INSERT INTO feedbacks (id, userId, userName, userEmail, category, subject, message, status, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [
    f.id, f.userId, f.userName, f.userEmail, f.category, f.subject, f.message, f.status, f.createdAt
  ]);
  saveDB();
}

export function getAllFeedbacks(): Feedback[] {
  const results = db.exec('SELECT * FROM feedbacks ORDER BY createdAt DESC');
  if (!results[0] || !results[0].values) return [];
  return results[0].values.map((row: any[]) => ({
    id: String(row[0]),
    userId: String(row[1]),
    userName: String(row[2]),
    userEmail: String(row[3]),
    category: row[4] as any,
    subject: String(row[5]),
    message: String(row[6]),
    status: row[7] as any,
    createdAt: String(row[8]),
    adminReply: row[9] || undefined
  }));
}

// Notifications
export function insertNotification(n: NotificationItem): void {
  db.run('INSERT INTO notifications (id, userId, title, message, type, isRead, createdAt, link) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', [
    n.id, n.userId, n.title, n.message, n.type, n.isRead ? 1 : 0, n.createdAt, n.link || null
  ]);
  saveDB();
}

export function getUserNotifications(userId: string): NotificationItem[] {
  const results = db.exec('SELECT * FROM notifications WHERE userId = ? ORDER BY createdAt DESC LIMIT 20', [userId]);
  if (!results[0] || !results[0].values) return [];
  return results[0].values.map((row: any[]) => ({
    id: String(row[0]),
    userId: String(row[1]),
    title: String(row[2]),
    message: String(row[3]),
    type: row[4] as any,
    isRead: Boolean(row[5]),
    createdAt: String(row[6]),
    link: row[7] || undefined
  }));
}

// Admin Statistics overview
export function getAdminStats() {
  const totalCustomers = db.exec('SELECT COUNT(*) FROM users WHERE role = "customer"')[0]?.values[0]?.[0] || 0;
  const totalDrivers = db.exec('SELECT COUNT(*) FROM users WHERE role = "driver"')[0]?.values[0]?.[0] || 0;
  const activeDrivers = db.exec('SELECT COUNT(*) FROM users WHERE role = "driver" AND status = "active"')[0]?.values[0]?.[0] || 0;
  const pendingDrivers = db.exec('SELECT COUNT(*) FROM users WHERE role = "driver" AND status = "pending_approval"')[0]?.values[0]?.[0] || 0;
  const totalBookings = db.exec('SELECT COUNT(*) FROM bookings')[0]?.values[0]?.[0] || 0;
  const activeTrips = db.exec('SELECT COUNT(*) FROM bookings WHERE status = "in-progress"')[0]?.values[0]?.[0] || 0;
  const completedTrips = db.exec('SELECT COUNT(*) FROM bookings WHERE status = "completed"')[0]?.values[0]?.[0] || 0;

  return {
    totalCustomers: Number(totalCustomers),
    totalDrivers: Number(totalDrivers),
    activeDrivers: Number(activeDrivers),
    pendingDrivers: Number(pendingDrivers),
    totalBookings: Number(totalBookings),
    activeTrips: Number(activeTrips),
    completedTrips: Number(completedTrips)
  };
}
