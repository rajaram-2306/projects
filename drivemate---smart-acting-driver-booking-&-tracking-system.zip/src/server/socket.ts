import { Server as SocketIOServer, Socket } from 'socket.io';
import { Server as HttpServer } from 'http';
import * as db from './db.js';

let io: SocketIOServer;

export function initSocketServer(server: HttpServer): SocketIOServer {
  io = new SocketIOServer(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST']
    }
  });

  io.on('connection', (socket: Socket) => {
    console.log(`Socket connected: ${socket.id}`);

    // Allow clients to join a room by userId or bookingId
    socket.on('join_room', (roomId: string) => {
      socket.join(roomId);
      console.log(`Socket ${socket.id} joined room ${roomId}`);
    });

    socket.on('leave_room', (roomId: string) => {
      socket.leave(roomId);
    });

    // Driver broadcasts a live location ping
    socket.on('driver:ping', (data: { driverId: string; lat: number; lng: number; heading?: number }) => {
      if (!data.driverId) return;
      db.upsertDriverLocation({
        id: `loc-${data.driverId}`,
        driverId: data.driverId,
        lat: data.lat,
        lng: data.lng,
        isOnline: true,
        heading: data.heading || 0,
        lastUpdated: new Date().toISOString()
      });

      // Broadcast to all clients watching active locations or specific driver
      io.emit('driver:location:broadcast', {
        driverId: data.driverId,
        lat: data.lat,
        lng: data.lng,
        heading: data.heading || 0
      });

      io.to(`driver_${data.driverId}`).emit('trip:location:update', {
        driverId: data.driverId,
        lat: data.lat,
        lng: data.lng
      });
    });

    socket.on('disconnect', () => {
      console.log(`Socket disconnected: ${socket.id}`);
    });
  });

  // Start background simulation for active trips so ETA and polyline movement are live
  startLiveTripSimulator();

  return io;
}

export function getIO(): SocketIOServer | undefined {
  return io;
}

// Emits notification and booking status changes
export function emitBookingUpdate(bookingId: string, status: string, bookingData?: any) {
  if (!io) return;
  io.emit(`booking:${bookingId}:update`, { id: bookingId, status, ...bookingData });
  io.emit('bookings:changed', { bookingId, status });
}

export function emitNotification(userId: string, title: string, message: string, type: 'booking' | 'system' | 'approval' | 'rating' = 'booking') {
  if (!io) return;
  const notif = {
    id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    userId,
    title,
    message,
    type,
    isRead: false,
    createdAt: new Date().toISOString()
  };
  db.insertNotification(notif);
  io.to(`user_${userId}`).emit('notification:new', notif);
  io.emit(`user_notif_${userId}`, notif);
}

// Background loop to simulate smooth GPS movement for trips currently 'in-progress'
function startLiveTripSimulator() {
  setInterval(() => {
    try {
      const activeTrips = db.getBookings({ status: 'in-progress' });
      if (!activeTrips.length || !io) return;

      activeTrips.forEach((trip) => {
        const loc = db.getDriverLocation(trip.driverId);
        if (!loc) return;

        // Move slightly closer to destination
        const dLat = trip.destinationLat - loc.lat;
        const dLng = trip.destinationLng - loc.lng;
        const distance = Math.sqrt(dLat * dLat + dLng * dLng);

        if (distance > 0.002) {
          const step = 0.0006; // ~50m per step
          const angle = Math.atan2(dLat, dLng);
          const newLat = loc.lat + Math.sin(angle) * step;
          const newLng = loc.lng + Math.cos(angle) * step;
          const heading = Math.round((Math.atan2(dLng, dLat) * 180) / Math.PI);

          db.upsertDriverLocation({
            ...loc,
            lat: Number(newLat.toFixed(6)),
            lng: Number(newLng.toFixed(6)),
            heading,
            lastUpdated: new Date().toISOString()
          });

          io.emit('driver:location:broadcast', {
            driverId: trip.driverId,
            lat: newLat,
            lng: newLng,
            heading
          });

          io.emit(`trip_track_${trip.id}`, {
            bookingId: trip.id,
            driverId: trip.driverId,
            lat: newLat,
            lng: newLng,
            heading,
            distanceRemainingKm: Number((distance * 111).toFixed(1)),
            etaMinutes: Math.max(1, Math.round((distance * 111) / 0.5))
          });
        }
      });
    } catch (err) {
      console.error('Error in live trip simulator:', err);
    }
  }, 4000);
}
