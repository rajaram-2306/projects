import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import * as db from '../db.js';
import { User, UserRole } from '../types.js';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'drivemate-super-secret-key-2026';

function generateToken(user: User): string {
  return jwt.sign(
    { id: user.id, role: user.role, name: user.name, email: user.email },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// POST /api/auth/register
router.post('/register', async (req: Request, res: Response) => {
  try {
    const { role, name, email, mobile, password, address, aadhaarNumber, licenseNumber, vehicleType, vehicleNumber, experience } = req.body;

    if (!email || !name || !role) {
      return res.status(400).json({ error: 'Name, Email and Role are required' });
    }

    const existing = db.getUserByEmail(email);
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password || 'password123', salt);

    const userId = `${role}-${Date.now()}`;
    const newUser: User = {
      id: userId,
      role: role as UserRole,
      name,
      email: email.toLowerCase(),
      mobile: mobile || '9800000000',
      password: hashedPassword,
      status: role === 'driver' ? 'pending_approval' : undefined,
      address,
      aadhaarNumber,
      licenseNumber,
      vehicleType: vehicleType || (role === 'driver' ? 'Sedan' : undefined),
      vehicleNumber,
      experience: experience ? Number(experience) : 0,
      avatarUrl: `https://images.unsplash.com/photo-${role === 'driver' ? '1534528741775-53994a69daeb' : '1500648767791-00dcc994a43e'}?auto=format&fit=crop&w=300&q=80`,
      rating: 5.0,
      totalTrips: 0,
      hourlyRate: role === 'driver' ? 180 : undefined,
      isOnline: false,
      documentUrls: role === 'driver' ? {
        photo: 'uploaded_photo.jpg',
        license: 'uploaded_license.pdf',
        aadhaar: 'uploaded_aadhaar.pdf',
        rcBook: 'uploaded_rc.pdf',
        insurance: 'uploaded_ins.pdf'
      } : undefined,
      createdAt: new Date().toISOString()
    };

    db.insertUser(newUser);

    // Notify admin if new driver registered
    if (role === 'driver') {
      const admins = db.getAllUsers('admin');
      admins.forEach((admin) => {
        db.insertNotification({
          id: `notif-${Date.now()}`,
          userId: admin.id,
          title: 'New Driver Registration',
          message: `${name} has applied as an acting driver and is waiting for document verification.`,
          type: 'approval',
          isRead: false,
          createdAt: new Date().toISOString()
        });
      });
    }

    const token = generateToken(newUser);
    const { password: _, ...userWithoutPass } = newUser;
    return res.status(201).json({ token, user: userWithoutPass });
  } catch (err: any) {
    console.error('Registration error:', err);
    return res.status(500).json({ error: 'Internal server error during registration' });
  }
});

// POST /api/auth/login
router.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = db.getUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Verify password (support both bcrypt hash and demo plaintext fallback)
    let valid = false;
    if (user.password?.startsWith('$2a$') || user.password?.startsWith('$2b$')) {
      valid = await bcrypt.compare(password, user.password);
    } else {
      valid = (user.password === password);
    }

    if (!valid && password !== 'demo123') {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = generateToken(user);
    const { password: _, ...userWithoutPass } = user;
    return res.json({ token, user: userWithoutPass });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Internal server error during login' });
  }
});

// POST /api/auth/demo-switch (1-click role testing)
router.post('/demo-switch', async (req: Request, res: Response) => {
  try {
    const { role, status } = req.body; // e.g. { role: 'driver', status: 'active' } or { role: 'admin' }
    const allUsers = db.getAllUsers();
    let target: User | undefined;

    if (role === 'driver' && status === 'pending_approval') {
      target = allUsers.find(u => u.role === 'driver' && u.status === 'pending_approval');
    } else if (role === 'driver') {
      target = allUsers.find(u => u.role === 'driver' && u.status === 'active');
    } else {
      target = allUsers.find(u => u.role === role);
    }

    if (!target) {
      return res.status(404).json({ error: `No demo account found for role: ${role}` });
    }

    const token = generateToken(target);
    const { password: _, ...userWithoutPass } = target;
    return res.json({ token, user: userWithoutPass });
  } catch (err: any) {
    console.error('Demo switch error:', err);
    return res.status(500).json({ error: 'Failed to switch demo account' });
  }
});

// POST /api/auth/verify-otp (Simulated OTP verification for mobile/email)
router.post('/verify-otp', (req: Request, res: Response) => {
  const { mobile, otp } = req.body;
  if (otp === '1234' || otp === '123456') {
    return res.json({ success: true, message: 'OTP verified successfully!' });
  }
  return res.status(400).json({ error: 'Invalid OTP code. Please use 1234.' });
});

// POST /api/auth/reset-password
router.post('/reset-password', (req: Request, res: Response) => {
  const { email } = req.body;
  const user = db.getUserByEmail(email);
  if (!user) {
    return res.status(404).json({ error: 'No account associated with this email address.' });
  }
  return res.json({ success: true, message: `Password reset link sent to ${email}. For testing, you can use temporary password: demo123` });
});

// GET /api/auth/me
router.get('/me', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string };
    const user = db.getUserById(decoded.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    const { password: _, ...userWithoutPass } = user;
    return res.json({ user: userWithoutPass });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
});

export default router;
