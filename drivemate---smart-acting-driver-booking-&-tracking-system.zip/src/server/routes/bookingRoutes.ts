import { Router, Request, Response } from 'express';
import * as db from '../db.js';
import * as socketServer from '../socket.js';
import { Booking, BookingStatus } from '../types.js';

const router = Router();

// GET /api/bookings - Get list of bookings (filtered by customerId, driverId, or status)
router.get('/', (req: Request, res: Response) => {
  try {
    const { customerId, driverId, status } = req.query;
    const bookings = db.getBookings({
      customerId: typeof customerId === 'string' ? customerId : undefined,
      driverId: typeof driverId === 'string' ? driverId : undefined,
      status: typeof status === 'string' ? status as BookingStatus : undefined,
    });
    return res.json({ bookings });
  } catch (err: any) {
    console.error('Error fetching bookings:', err);
    return res.status(500).json({ error: 'Failed to retrieve bookings' });
  }
});

// GET /api/bookings/:id
router.get('/:id', (req: Request, res: Response) => {
  try {
    const booking = db.getBookingById(req.params.id);
    if (!booking) {
      return res.status(404).json({ error: 'Booking not found' });
    }
    return res.json({ booking });
  } catch (err: any) {
    console.error('Error fetching booking details:', err);
    return res.status(500).json({ error: 'Failed to retrieve booking' });
  }
});

// POST /api/bookings/estimate - Calculate estimated fare & ETA
router.post('/estimate', (req: Request, res: Response) => {
  try {
    const { pickupLat, pickupLng, destinationLat, destinationLng, vehicleType, driverId } = req.body;

    // Approximate distance using Haversine or simple Euclidean proxy for demo
    const dLat = (Number(destinationLat) - Number(pickupLat)) * 111;
    const dLng = (Number(destinationLng) - Number(pickupLng)) * 111 * Math.cos((Number(pickupLat) * Math.PI) / 180);
    const distanceKm = Math.max(3, Math.round(Math.sqrt(dLat * dLat + dLng * dLng) * 1.3)); // add 30% road factor
    const etaMinutes = Math.max(10, Math.round((distanceKm / 25) * 60)); // ~25 km/h city speed

    let hourlyRate = 180;
    if (driverId) {
      const driver = db.getUserById(driverId);
      if (driver?.hourlyRate) hourlyRate = driver.hourlyRate;
    } else if (vehicleType === 'SUV') {
      hourlyRate = 220;
    } else if (vehicleType === 'Luxury') {
      hourlyRate = 300;
    } else if (vehicleType === 'Hatchback') {
      hourlyRate = 160;
    }

    // Minimum 3 hours acting charge or distance-based hours
    const estimatedHours = Math.max(3, Math.ceil(etaMinutes / 60) + 1);
    const estimatedFare = estimatedHours * hourlyRate;

    return res.json({
      distanceKm,
      etaMinutes,
      estimatedHours,
      hourlyRate,
      estimatedFare
    });
  } catch (err: any) {
    console.error('Error estimating fare:', err);
    return res.status(500).json({ error: 'Failed to calculate estimate' });
  }
});

// POST /api/bookings - Create new booking
router.post('/', (req: Request, res: Response) => {
  try {
    const {
      customerId,
      driverId,
      pickupAddress,
      pickupLat,
      pickupLng,
      destinationAddress,
      destinationLat,
      destinationLng,
      vehicleType,
      vehicleModel,
      vehicleNumber,
      tripDate,
      tripTime,
      estimatedFare,
      distanceKm,
      etaMinutes
    } = req.body;

    if (!customerId || !driverId || !pickupAddress || !destinationAddress) {
      return res.status(400).json({ error: 'Pickup, destination, customer, and driver are required' });
    }

    const customer = db.getUserById(customerId);
    const driver = db.getUserById(driverId);

    if (!customer || !driver) {
      return res.status(404).json({ error: 'Customer or Driver account not found' });
    }

    const bookingId = `book-${Date.now()}`;
    const newBooking: Booking = {
      id: bookingId,
      customerId,
      customerName: customer.name,
      customerMobile: customer.mobile,
      driverId,
      driverName: driver.name,
      driverMobile: driver.mobile,
      pickupAddress,
      pickupLat: Number(pickupLat || 13.0850),
      pickupLng: Number(pickupLng || 80.2101),
      destinationAddress,
      destinationLat: Number(destinationLat || 12.9941),
      destinationLng: Number(destinationLng || 80.1709),
      vehicleType: vehicleType || 'Sedan',
      vehicleModel: vehicleModel || 'My Private Vehicle',
      vehicleNumber: vehicleNumber || 'TN09 AB 1234',
      tripDate: tripDate || new Date().toISOString().split('T')[0],
      tripTime: tripTime || '10:00',
      status: 'requested',
      estimatedFare: Number(estimatedFare || 540),
      distanceKm: Number(distanceKm || 15),
      etaMinutes: Number(etaMinutes || 35),
      createdAt: new Date().toISOString()
    };

    db.insertBooking(newBooking);

    // Emit live notification & Socket.IO update
    socketServer.emitNotification(
      driverId,
      'New Acting Driver Request!',
      `${customer.name} has requested you to drive their ${vehicleModel} (${vehicleNumber}) on ${tripDate} at ${tripTime}.`,
      'booking'
    );
    socketServer.emitBookingUpdate(bookingId, 'requested', newBooking);

    return res.status(201).json({ booking: newBooking });
  } catch (err: any) {
    console.error('Error creating booking:', err);
    return res.status(500).json({ error: 'Failed to create booking request' });
  }
});

// PATCH /api/bookings/:id/status - Accept, Reject, Start, Complete, or Cancel trip
router.patch('/:id/status', (req: Request, res: Response) => {
  try {
    const { status, cancellationReason, actualFare } = req.body;
    const booking = db.getBookingById(req.params.id);

    if (!booking) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const validStatuses: BookingStatus[] = ['requested', 'accepted', 'rejected', 'in-progress', 'completed', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid booking status' });
    }

    const now = new Date().toISOString();
    const updates: any = {};

    if (status === 'in-progress') {
      updates.startedAt = now;
    } else if (status === 'completed') {
      updates.completedAt = now;
      updates.actualFare = actualFare || booking.estimatedFare;
      // Increment driver trip count
      const driver = db.getUserById(booking.driverId);
      if (driver) {
        db.insertUser({
          ...driver,
          totalTrips: (driver.totalTrips || 0) + 1
        });
      }
    } else if (status === 'cancelled') {
      updates.cancellationReason = cancellationReason || 'Cancelled by user';
    }

    const updated = db.updateBookingStatus(req.params.id, status as BookingStatus, updates);

    // Determine notification copy
    let title = `Trip ${status.toUpperCase()}`;
    let message = `Your booking with driver ${booking.driverName} is now ${status}.`;
    if (status === 'accepted') {
      title = 'Driver Accepted Your Booking!';
      message = `${booking.driverName} accepted your request for ${booking.tripDate} at ${booking.tripTime}.`;
    } else if (status === 'in-progress') {
      title = 'Trip Started - Live Tracking Active';
      message = `${booking.driverName} has arrived and started the trip. You can track live GPS movement.`;
    } else if (status === 'completed') {
      title = 'Trip Completed Successfully';
      message = `Your trip with ${booking.driverName} is complete. Total Fare: ₹${updates.actualFare || booking.estimatedFare}. Please rate your driver!`;
    } else if (status === 'rejected') {
      title = 'Booking Request Declined';
      message = `${booking.driverName} is currently unavailable. Please choose another verified driver.`;
    }

    socketServer.emitNotification(booking.customerId, title, message, 'booking');
    socketServer.emitBookingUpdate(req.params.id, status, updated);

    return res.json({ booking: updated });
  } catch (err: any) {
    console.error('Error updating booking status:', err);
    return res.status(500).json({ error: 'Failed to update booking status' });
  }
});

export default router;
