import { Router, Request, Response } from 'express';
import * as db from '../db.js';
import * as socketServer from '../socket.js';
import { DriverStatus } from '../types.js';

const router = Router();

// GET /api/admin/overview - Stat cards & chart data
router.get('/overview', (req: Request, res: Response) => {
  try {
    const stats = db.getAdminStats();
    const allBookings = db.getBookings();
    const allUsers = db.getAllUsers();

    // Generate monthly trips data for Recharts
    const monthlyTrips = [
      { month: 'Jan', trips: 120, revenue: 64800 },
      { month: 'Feb', trips: 145, revenue: 78300 },
      { month: 'Mar', trips: 180, revenue: 97200 },
      { month: 'Apr', trips: 210, revenue: 113400 },
      { month: 'May', trips: 260, revenue: 140400 },
      { month: 'Jun', trips: 310, revenue: 167400 },
      { month: 'Jul', trips: allBookings.length * 8 + 340, revenue: 184000 }
    ];

    // Driver vs Customer growth
    const userGrowth = [
      { month: 'Jan', drivers: 8, customers: 45 },
      { month: 'Feb', drivers: 12, customers: 80 },
      { month: 'Mar', drivers: 18, customers: 140 },
      { month: 'Apr', drivers: 25, customers: 220 },
      { month: 'May', drivers: 35, customers: 310 },
      { month: 'Jun', drivers: 42, customers: 410 },
      { month: 'Jul', drivers: allUsers.filter(u => u.role === 'driver').length + 45, customers: allUsers.filter(u => u.role === 'customer').length + 480 }
    ];

    // Booking status distribution
    const statusDistribution = [
      { name: 'Completed', value: allBookings.filter(b => b.status === 'completed').length + 80, color: '#10B981' },
      { name: 'In-Progress', value: allBookings.filter(b => b.status === 'in-progress').length + 5, color: '#2563EB' },
      { name: 'Requested', value: allBookings.filter(b => b.status === 'requested').length + 8, color: '#F59E0B' },
      { name: 'Cancelled', value: allBookings.filter(b => b.status === 'cancelled').length + 6, color: '#EF4444' }
    ];

    return res.json({
      stats,
      charts: {
        monthlyTrips,
        userGrowth,
        statusDistribution
      }
    });
  } catch (err: any) {
    console.error('Error fetching admin overview:', err);
    return res.status(500).json({ error: 'Failed to retrieve admin overview statistics' });
  }
});

// GET /api/admin/drivers/pending - Get drivers in approval queue
router.get('/drivers/pending', (req: Request, res: Response) => {
  try {
    const drivers = db.getAllUsers('driver').filter(d => d.status === 'pending_approval');
    return res.json({ pendingDrivers: drivers });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to retrieve pending drivers' });
  }
});

// PATCH /api/admin/drivers/:id/approve - Approve or Reject a driver
router.patch('/drivers/:id/approve', (req: Request, res: Response) => {
  try {
    const { action } = req.body; // 'approve' or 'reject'
    const driver = db.getUserById(req.params.id);
    if (!driver || driver.role !== 'driver') {
      return res.status(404).json({ error: 'Driver not found' });
    }

    const newStatus: DriverStatus = action === 'approve' ? 'active' : 'rejected';
    db.updateUserStatus(driver.id, newStatus);

    // Notify Driver
    const title = action === 'approve' ? 'Account Verified & Approved!' : 'Verification Update';
    const message = action === 'approve'
      ? 'Congratulations! Your documents (Aadhaar, License, RC) have been approved by Admin. You are now active on DriveMate.'
      : 'Your driver application needs attention. Please check your submitted document clarity.';

    socketServer.emitNotification(driver.id, title, message, 'approval');

    return res.json({ success: true, driverId: driver.id, status: newStatus });
  } catch (err: any) {
    console.error('Error approving driver:', err);
    return res.status(500).json({ error: 'Failed to update driver approval status' });
  }
});

// GET /api/admin/users - Get all users with role filter
router.get('/users', (req: Request, res: Response) => {
  try {
    const { role } = req.query;
    const users = db.getAllUsers(typeof role === 'string' ? role : undefined);
    return res.json({ users });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to retrieve users list' });
  }
});

// GET /api/admin/faqs
router.get('/faqs', (req: Request, res: Response) => {
  return res.json({ faqs: db.getAllFAQs() });
});

// POST /api/admin/faqs
router.post('/faqs', (req: Request, res: Response) => {
  const { question, answer, category } = req.body;
  if (!question || !answer) {
    return res.status(400).json({ error: 'Question and answer are required' });
  }
  const faq = {
    id: `faq-${Date.now()}`,
    question,
    answer,
    category: category || 'General',
    isPublished: true
  };
  db.insertFAQ(faq);
  return res.status(201).json({ faq });
});

export default router;
