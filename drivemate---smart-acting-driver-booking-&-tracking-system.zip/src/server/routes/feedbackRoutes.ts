import { Router, Request, Response } from 'express';
import * as db from '../db.js';
import * as socketServer from '../socket.js';
import { Rating, Feedback } from '../types.js';

const router = Router();

// POST /api/feedback/rate-trip - 5-dimension post-trip rating
router.post('/rate-trip', (req: Request, res: Response) => {
  try {
    const {
      bookingId,
      customerId,
      customerName,
      driverId,
      behaviour,
      drivingSkill,
      safety,
      communication,
      vehicleCleanliness,
      overall,
      comment
    } = req.body;

    if (!bookingId || !driverId || !customerId) {
      return res.status(400).json({ error: 'Booking, Customer and Driver IDs are required' });
    }

    const rating: Rating = {
      id: `rate-${Date.now()}`,
      bookingId,
      customerId,
      customerName: customerName || 'Verified Customer',
      driverId,
      behaviour: Number(behaviour || 5),
      drivingSkill: Number(drivingSkill || 5),
      safety: Number(safety || 5),
      communication: Number(communication || 5),
      vehicleCleanliness: Number(vehicleCleanliness || 5),
      overall: Number(overall || 5),
      comment: comment || '',
      createdAt: new Date().toISOString()
    };

    db.insertRating(rating);

    // Notify driver of their new review
    socketServer.emitNotification(
      driverId,
      'New Customer Review Received!',
      `You received a ${overall}-star review from ${customerName}: "${comment || 'Great trip!'}"`,
      'rating'
    );

    return res.status(201).json({ success: true, rating });
  } catch (err: any) {
    console.error('Error submitting trip rating:', err);
    return res.status(500).json({ error: 'Failed to save rating' });
  }
});

// GET /api/feedback/driver/:driverId - Get reviews for a driver
router.get('/driver/:driverId', (req: Request, res: Response) => {
  try {
    const reviews = db.getRatingsByDriver(req.params.driverId);
    return res.json({ reviews });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to retrieve driver reviews' });
  }
});

// POST /api/feedback - General feedback / complaint form
router.post('/', (req: Request, res: Response) => {
  try {
    const { userId, userName, userEmail, category, subject, message } = req.body;

    if (!subject || !message) {
      return res.status(400).json({ error: 'Subject and message are required' });
    }

    const feedback: Feedback = {
      id: `feed-${Date.now()}`,
      userId: userId || 'guest',
      userName: userName || 'Customer',
      userEmail: userEmail || 'customer@example.com',
      category: category || 'General',
      subject,
      message,
      status: 'open',
      createdAt: new Date().toISOString()
    };

    db.insertFeedback(feedback);
    return res.status(201).json({ success: true, feedback });
  } catch (err: any) {
    console.error('Error submitting feedback:', err);
    return res.status(500).json({ error: 'Failed to save feedback' });
  }
});

// GET /api/feedback - List all feedback for admin moderation
router.get('/', (req: Request, res: Response) => {
  try {
    const feedbacks = db.getAllFeedbacks();
    return res.json({ feedbacks });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to retrieve feedback list' });
  }
});

export default router;
