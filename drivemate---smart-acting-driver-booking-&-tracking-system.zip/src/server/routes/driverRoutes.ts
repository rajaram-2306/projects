import { Router, Request, Response } from 'express';
import * as db from '../db.js';
import { User } from '../types.js';

const router = Router();

// GET /api/drivers - Filterable, searchable, sortable driver listing
router.get('/', (req: Request, res: Response) => {
  try {
    const {
      vehicleType,
      minRating,
      minExperience,
      search,
      onlyOnline,
      sortBy
    } = req.query;

    const allDrivers = db.getAllUsers('driver');

    // Filter only active drivers for public listing
    let filtered = allDrivers.filter(d => d.status === 'active');

    if (vehicleType && vehicleType !== 'All' && vehicleType !== 'all') {
      filtered = filtered.filter(d => d.vehicleType === vehicleType);
    }

    if (minRating) {
      filtered = filtered.filter(d => (d.rating || 0) >= Number(minRating));
    }

    if (minExperience) {
      filtered = filtered.filter(d => (d.experience || 0) >= Number(minExperience));
    }

    if (onlyOnline === 'true') {
      filtered = filtered.filter(d => d.isOnline);
    }

    if (search && typeof search === 'string') {
      const q = search.toLowerCase();
      filtered = filtered.filter(d =>
        d.name.toLowerCase().includes(q) ||
        (d.address && d.address.toLowerCase().includes(q)) ||
        (d.vehicleType && d.vehicleType.toLowerCase().includes(q))
      );
    }

    // Sorting
    if (sortBy === 'rating') {
      filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    } else if (sortBy === 'experience') {
      filtered.sort((a, b) => (b.experience || 0) - (a.experience || 0));
    } else if (sortBy === 'rate_low') {
      filtered.sort((a, b) => (a.hourlyRate || 0) - (b.hourlyRate || 0));
    } else if (sortBy === 'trips') {
      filtered.sort((a, b) => (b.totalTrips || 0) - (a.totalTrips || 0));
    }

    // Attach latest location to each driver
    const withLocations = filtered.map(d => {
      const { password, ...safeDriver } = d;
      const loc = db.getDriverLocation(d.id);
      return {
        ...safeDriver,
        location: loc || { lat: 13.0405, lng: 80.2337, isOnline: d.isOnline }
      };
    });

    return res.json({ drivers: withLocations, total: withLocations.length });
  } catch (err: any) {
    console.error('Error fetching drivers:', err);
    return res.status(500).json({ error: 'Failed to retrieve drivers' });
  }
});

// GET /api/drivers/:id
router.get('/:id', (req: Request, res: Response) => {
  try {
    const driver = db.getUserById(req.params.id);
    if (!driver || driver.role !== 'driver') {
      return res.status(404).json({ error: 'Driver not found' });
    }
    const { password, ...safeDriver } = driver;
    const location = db.getDriverLocation(driver.id);
    const reviews = db.getRatingsByDriver(driver.id);

    return res.json({
      driver: {
        ...safeDriver,
        location: location || { lat: 13.0405, lng: 80.2337, isOnline: driver.isOnline }
      },
      reviews
    });
  } catch (err: any) {
    console.error('Error fetching driver details:', err);
    return res.status(500).json({ error: 'Failed to retrieve driver details' });
  }
});

// POST /api/drivers/:id/status (Toggle online/offline)
router.post('/:id/status', (req: Request, res: Response) => {
  try {
    const { isOnline } = req.body;
    db.updateDriverOnlineStatus(req.params.id, Boolean(isOnline));
    const location = db.getDriverLocation(req.params.id);
    if (location) {
      db.upsertDriverLocation({
        ...location,
        isOnline: Boolean(isOnline),
        lastUpdated: new Date().toISOString()
      });
    }
    return res.json({ success: true, isOnline: Boolean(isOnline) });
  } catch (err: any) {
    console.error('Error toggling online status:', err);
    return res.status(500).json({ error: 'Failed to update driver status' });
  }
});

export default router;
