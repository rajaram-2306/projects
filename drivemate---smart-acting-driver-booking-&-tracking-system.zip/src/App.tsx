/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { DemoSwitcherModal } from './components/DemoSwitcherModal';

// Pages
import { Home } from './pages/Home';
import { DriverListing } from './pages/DriverListing';
import { DriverDetails } from './pages/DriverDetails';
import { About } from './pages/About';
import { FAQPage } from './pages/FAQPage';
import { Contact } from './pages/Contact';
import { AuthPage } from './pages/AuthPage';

// Dashboards
import { CustomerDashboard } from './pages/dashboard/CustomerDashboard';
import { DriverDashboard } from './pages/dashboard/DriverDashboard';
import { AdminDashboard } from './pages/dashboard/AdminDashboard';

export default function App() {
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);

  return (
    <AuthProvider>
      <SocketProvider>
        <Router>
          <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 antialiased selection:bg-blue-600 selection:text-white">
            <Navbar onOpenDemoModal={() => setIsDemoModalOpen(true)} />

            <main className="flex-1">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/drivers" element={<DriverListing />} />
                <Route path="/drivers/:id" element={<DriverDetails />} />
                <Route path="/about" element={<About />} />
                <Route path="/faqs" element={<FAQPage />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/login" element={<AuthPage initialMode="login" />} />
                <Route path="/register" element={<AuthPage initialMode="register" />} />

                {/* Dashboard routes */}
                <Route path="/dashboard/customer" element={<CustomerDashboard />} />
                <Route path="/dashboard/driver" element={<DriverDashboard />} />
                <Route path="/dashboard/admin" element={<AdminDashboard />} />

                {/* Fallback */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>

            <Footer />

            <DemoSwitcherModal
              isOpen={isDemoModalOpen}
              onClose={() => setIsDemoModalOpen(false)}
            />
          </div>
        </Router>
      </SocketProvider>
    </AuthProvider>
  );
}
