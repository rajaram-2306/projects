import React, { useEffect, useState } from 'react';
import L from 'leaflet';
import { Navigation, MapPin, Clock, ShieldAlert, Radio } from 'lucide-react';
import { useSocket } from '../context/SocketContext';

// Fix standard Leaflet icon paths
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png'
});

interface LiveTrackingMapProps {
  bookingId?: string;
  driverId?: string;
  pickupLat: number;
  pickupLng: number;
  pickupAddress?: string;
  destinationLat: number;
  destinationLng: number;
  destinationAddress?: string;
  driverLat?: number;
  driverLng?: number;
  driverHeading?: number;
  status?: string;
  height?: string;
}

export const LiveTrackingMap: React.FC<LiveTrackingMapProps> = ({
  bookingId,
  driverId,
  pickupLat,
  pickupLng,
  pickupAddress,
  destinationLat,
  destinationLng,
  destinationAddress,
  driverLat = pickupLat,
  driverLng = pickupLng,
  driverHeading = 0,
  status = 'in-progress',
  height = 'h-96'
}) => {
  const { socket } = useSocket();
  const [currentLat, setCurrentLat] = useState<number>(driverLat);
  const [currentLng, setCurrentLng] = useState<number>(driverLng);
  const [heading, setHeading] = useState<number>(driverHeading);
  const [etaMinutes, setEtaMinutes] = useState<number>(20);
  const [distanceRemaining, setDistanceRemaining] = useState<number>(12.4);

  // Listen to Socket.IO live driver movement
  useEffect(() => {
    if (!socket || !bookingId) return;

    const handleTrackUpdate = (data: any) => {
      if (data.bookingId === bookingId || data.driverId === driverId) {
        setCurrentLat(data.lat);
        setCurrentLng(data.lng);
        if (data.heading !== undefined) setHeading(data.heading);
        if (data.etaMinutes) setEtaMinutes(data.etaMinutes);
        if (data.distanceRemainingKm) setDistanceRemaining(data.distanceRemainingKm);
      }
    };

    socket.on(`trip_track_${bookingId}`, handleTrackUpdate);
    socket.on('driver:location:broadcast', (data: any) => {
      if (data.driverId === driverId) {
        setCurrentLat(data.lat);
        setCurrentLng(data.lng);
        if (data.heading !== undefined) setHeading(data.heading);
      }
    });

    return () => {
      socket.off(`trip_track_${bookingId}`, handleTrackUpdate);
      socket.off('driver:location:broadcast');
    };
  }, [socket, bookingId, driverId]);

  useEffect(() => {
    const containerId = `map-${bookingId || driverId || 'default'}`;
    const mapContainer = document.getElementById(containerId);
    if (!mapContainer) return;

    // Check if container already has Leaflet instance
    if ((mapContainer as any)._leaflet_id) {
      mapContainer.innerHTML = '';
      delete (mapContainer as any)._leaflet_id;
    }

    const map = L.map(containerId, {
      center: [currentLat, currentLng],
      zoom: 13,
      zoomControl: true,
      attributionControl: false
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19
    }).addTo(map);

    // Custom Icon styles
    const driverIcon = L.divIcon({
      className: 'custom-driver-marker',
      html: `
        <div style="transform: rotate(${heading}deg); width: 36px; height: 36px; background: #2563EB; border: 3px solid white; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(37,99,235,0.4);">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>
        </div>
      `,
      iconSize: [36, 36],
      iconAnchor: [18, 18]
    });

    const pickupIcon = L.divIcon({
      className: 'custom-pickup-marker',
      html: `
        <div style="width: 28px; height: 28px; background: #10B981; border: 3px solid white; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 8px rgba(16,185,129,0.3);">
          <span style="color: white; font-size: 11px; font-weight: bold;">P</span>
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });

    const destIcon = L.divIcon({
      className: 'custom-dest-marker',
      html: `
        <div style="width: 28px; height: 28px; background: #EF4444; border: 3px solid white; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 8px rgba(239,68,68,0.3);">
          <span style="color: white; font-size: 11px; font-weight: bold;">D</span>
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });

    // Add Markers
    L.marker([pickupLat, pickupLng], { icon: pickupIcon })
      .addTo(map)
      .bindPopup(`<b>Pickup Location</b><br/>${pickupAddress || 'Start point'}`);

    L.marker([destinationLat, destinationLng], { icon: destIcon })
      .addTo(map)
      .bindPopup(`<b>Destination</b><br/>${destinationAddress || 'End point'}`);

    const driverMarker = L.marker([currentLat, currentLng], { icon: driverIcon })
      .addTo(map)
      .bindPopup(`<b>Driver Live GPS</b><br/>Status: ${status.toUpperCase()}`);

    // Draw Route Polyline
    const routePolyline = L.polyline(
      [
        [currentLat, currentLng],
        [destinationLat, destinationLng]
      ],
      { color: '#2563EB', weight: 4, opacity: 0.8, dashArray: '6, 8' }
    ).addTo(map);

    // Fit map bounds
    const bounds = L.latLngBounds([
      [pickupLat, pickupLng],
      [destinationLat, destinationLng],
      [currentLat, currentLng]
    ]);
    map.fitBounds(bounds, { padding: [40, 40] });

    return () => {
      map.remove();
    };
  }, [currentLat, currentLng, pickupLat, pickupLng, destinationLat, destinationLng, heading, status, bookingId, driverId, pickupAddress, destinationAddress]);

  return (
    <div className="relative rounded-3xl overflow-hidden border border-slate-200 shadow-md bg-slate-100">
      <div id={`map-${bookingId || driverId || 'default'}`} className={`w-full ${height} z-0`} />

      {/* Floating Status Overlay */}
      <div className="absolute top-4 left-4 z-10 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-lg border border-slate-200/80 flex items-center gap-3">
        <div className="flex items-center gap-1.5 text-xs font-bold text-blue-600">
          <Radio className="w-4 h-4 text-emerald-500 animate-pulse" />
          <span>LIVE TRACKING</span>
        </div>
        <div className="h-4 w-px bg-slate-200" />
        <div className="flex items-center gap-1 text-xs font-semibold text-slate-700">
          <Clock className="w-3.5 h-3.5 text-slate-500" />
          <span>ETA: ~{etaMinutes} min ({distanceRemaining} km)</span>
        </div>
      </div>
    </div>
  );
};
