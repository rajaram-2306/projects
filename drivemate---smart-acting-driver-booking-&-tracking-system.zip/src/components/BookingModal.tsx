import React, { useState, useEffect } from 'react';
import { X, Car, Clock, MapPin, Calendar, IndianRupee, CheckCircle2, ShieldCheck, Sparkles, Loader2 } from 'lucide-react';
import { User } from '../types';
import { useAuth } from '../context/AuthContext';

interface BookingModalProps {
  driver: User | null;
  isOpen: boolean;
  onClose: () => void;
  onBookingSuccess: (booking: any) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  driver,
  isOpen,
  onClose,
  onBookingSuccess
}) => {
  const { user } = useAuth();
  const [pickupAddress, setPickupAddress] = useState('Anna Nagar West, Chennai');
  const [pickupLat, setPickupLat] = useState(13.0850);
  const [pickupLng, setPickupLng] = useState(80.2101);

  const [destinationAddress, setDestinationAddress] = useState('Chennai International Airport, Meenambakkam');
  const [destinationLat, setDestinationLat] = useState(12.9941);
  const [destinationLng, setDestinationLng] = useState(80.1709);

  const [vehicleType, setVehicleType] = useState('Sedan');
  const [vehicleModel, setVehicleModel] = useState('Honda City Automatic');
  const [vehicleNumber, setVehicleNumber] = useState('TN09 AB 1234');
  const [tripDate, setTripDate] = useState(new Date().toISOString().split('T')[0]);
  const [tripTime, setTripTime] = useState('14:30');

  const [estimate, setEstimate] = useState<{
    distanceKm: number;
    etaMinutes: number;
    estimatedHours: number;
    hourlyRate: number;
    estimatedFare: number;
  } | null>({
    distanceKm: 18.5,
    etaMinutes: 35,
    estimatedHours: 3,
    hourlyRate: driver?.hourlyRate || 180,
    estimatedFare: (driver?.hourlyRate || 180) * 3
  });

  const [isEstimating, setIsEstimating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  // Popular Chennai & Bangalore preset locations for 1-click testing
  const presets = [
    { name: 'Chennai Airport Drop', pickup: 'T. Nagar, Chennai', pLat: 13.0405, pLng: 80.2337, dest: 'Chennai Airport (MAA)', dLat: 12.9941, dLng: 80.1709 },
    { name: 'ECR Weekend Resort', pickup: 'Adyar Signal, Chennai', pLat: 13.0012, pLng: 80.2565, dest: 'MGM Beach Resorts, Muthukadu', dLat: 12.8256, dLng: 80.2443 },
    { name: 'IT Corridor Office', pickup: 'Indiranagar, Bangalore', pLat: 12.9784, pLng: 77.6408, dest: 'Electronic City Phase 1, Bangalore', dLat: 12.8452, dLng: 77.6602 }
  ];

  useEffect(() => {
    if (!isOpen || !driver) return;
    const fetchEstimate = async () => {
      setIsEstimating(true);
      try {
        const res = await fetch('/api/bookings/estimate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            pickupLat,
            pickupLng,
            destinationLat,
            destinationLng,
            vehicleType,
            driverId: driver.id
          })
        });
        const data = await res.json();
        if (res.ok) {
          setEstimate(data);
        }
      } catch (err) {
        console.error('Error estimating fare:', err);
      } finally {
        setIsEstimating(false);
      }
    };
    fetchEstimate();
  }, [pickupLat, pickupLng, destinationLat, destinationLng, vehicleType, driver, isOpen]);

  const applyPreset = (p: typeof presets[0]) => {
    setPickupAddress(p.pickup);
    setPickupLat(p.pLat);
    setPickupLng(p.pLng);
    setDestinationAddress(p.dest);
    setDestinationLat(p.dLat);
    setDestinationLng(p.dLng);
  };

  const handleBookNow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setError('Please sign in as a customer to book an acting driver.');
      return;
    }
    if (!driver) return;

    setIsSubmitting(true);
    setError('');

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerId: user.id,
          driverId: driver.id,
          pickupAddress,
          pickupLat,
          pickupLng,
          destinationAddress,
          destinationLat,
          destinationLng,
          vehicleType,
          vehicleModel,
          vehicleNumber,
          tripDate,
          tripTime,
          estimatedFare: estimate?.estimatedFare || 540,
          distanceKm: estimate?.distanceKm || 15,
          etaMinutes: estimate?.etaMinutes || 35
        })
      });

      const data = await res.json();
      if (res.ok) {
        onBookingSuccess(data.booking);
        onClose();
      } else {
        setError(data.error || 'Failed to submit booking request');
      }
    } catch (err: any) {
      setError(err.message || 'Network error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !driver) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200 my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header banner */}
        <div className="p-6 bg-gradient-to-r from-blue-600 to-indigo-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={driver.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
              alt={driver.name}
              className="w-12 h-12 rounded-xl object-cover border-2 border-white shadow-md"
            />
            <div>
              <h3 className="font-extrabold text-lg">Book Acting Driver: {driver.name}</h3>
              <p className="text-xs text-blue-100 mt-0.5 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verified • ★ {driver.rating} • ₹{driver.hourlyRate}/hour</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleBookNow} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3.5 rounded-xl bg-red-50 text-red-700 text-xs font-semibold border border-red-200">
              {error}
            </div>
          )}

          {/* Quick presets */}
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
              Popular Trip Presets (1-Click Test)
            </label>
            <div className="flex flex-wrap gap-2">
              {presets.map((p, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => applyPreset(p)}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          {/* Pickup and destination */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="pickup-address-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                Pickup Address *
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-emerald-600 absolute left-3 top-3" />
                <input
                  id="pickup-address-input"
                  type="text"
                  required
                  value={pickupAddress}
                  onChange={(e) => setPickupAddress(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g. T. Nagar, Chennai"
                />
              </div>
            </div>

            <div>
              <label htmlFor="dest-address-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                Destination Address *
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-red-500 absolute left-3 top-3" />
                <input
                  id="dest-address-input"
                  type="text"
                  required
                  value={destinationAddress}
                  onChange={(e) => setDestinationAddress(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g. Airport / Office"
                />
              </div>
            </div>
          </div>

          {/* Customer's Vehicle Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="vehicle-type-select" className="block text-xs font-bold text-slate-700 mb-1.5">
                Your Car Type
              </label>
              <select
                id="vehicle-type-select"
                value={vehicleType}
                onChange={(e) => setVehicleType(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                <option value="Hatchback">Hatchback</option>
                <option value="Sedan">Sedan</option>
                <option value="SUV">SUV</option>
                <option value="Luxury">Luxury / EV</option>
              </select>
            </div>

            <div>
              <label htmlFor="vehicle-model-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                Car Make & Model
              </label>
              <input
                id="vehicle-model-input"
                type="text"
                required
                value={vehicleModel}
                onChange={(e) => setVehicleModel(e.target.value)}
                placeholder="e.g. Honda City Automatic"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="vehicle-num-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                Registration No.
              </label>
              <input
                id="vehicle-num-input"
                type="text"
                required
                value={vehicleNumber}
                onChange={(e) => setVehicleNumber(e.target.value)}
                placeholder="TN09 AB 1234"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="trip-date-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                Trip Date *
              </label>
              <input
                id="trip-date-input"
                type="date"
                required
                value={tripDate}
                onChange={(e) => setTripDate(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="trip-time-input" className="block text-xs font-bold text-slate-700 mb-1.5">
                Pickup Time *
              </label>
              <input
                id="trip-time-input"
                type="time"
                required
                value={tripTime}
                onChange={(e) => setTripTime(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Estimated Fare & Trip Summary Box */}
          <div className="p-5 rounded-2xl bg-blue-50/70 border border-blue-200">
            <h4 className="font-extrabold text-sm text-slate-900 mb-3 flex items-center justify-between">
              <span>Acting Driver Fare Estimate</span>
              {isEstimating && <Loader2 className="w-4 h-4 animate-spin text-blue-600" />}
            </h4>

            {estimate && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="bg-white p-2.5 rounded-xl border border-blue-100">
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">Est. Distance</span>
                  <p className="font-extrabold text-sm text-slate-800 mt-0.5">{estimate.distanceKm} km</p>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-blue-100">
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">Travel Time</span>
                  <p className="font-extrabold text-sm text-slate-800 mt-0.5">~{estimate.etaMinutes} min</p>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-blue-100">
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">Min. Hours</span>
                  <p className="font-extrabold text-sm text-slate-800 mt-0.5">{estimate.estimatedHours} hrs</p>
                </div>
                <div className="bg-blue-600 text-white p-2.5 rounded-xl shadow-sm">
                  <span className="text-[10px] uppercase font-semibold opacity-90">Total Fare</span>
                  <p className="font-extrabold text-base mt-0.5">₹{estimate.estimatedFare}</p>
                </div>
              </div>
            )}
            <p className="text-[11px] text-slate-500 mt-3 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Includes background-checked driver, insurance coverage, and 24/7 GPS emergency tracking.</span>
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-300 font-bold text-sm text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md shadow-blue-500/20 disabled:opacity-50 transition-all flex items-center gap-2 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Submitting Request...</span>
                </>
              ) : (
                <>
                  <span>Confirm Driver Booking</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
