import React, { useState } from 'react';
import { X, Star, CheckCircle, Shield, Award, MessageSquare, Loader2 } from 'lucide-react';
import { Booking } from '../types';
import { useAuth } from '../context/AuthContext';

interface TripFeedbackModalProps {
  booking: Booking | null;
  isOpen: boolean;
  onClose: () => void;
  onRatingSuccess: () => void;
}

export const TripFeedbackModal: React.FC<TripFeedbackModalProps> = ({
  booking,
  isOpen,
  onClose,
  onRatingSuccess
}) => {
  const { user } = useAuth();
  const [behaviour, setBehaviour] = useState(5);
  const [drivingSkill, setDrivingSkill] = useState(5);
  const [safety, setSafety] = useState(5);
  const [communication, setCommunication] = useState(5);
  const [vehicleCleanliness, setVehicleCleanliness] = useState(5);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !booking) return null;

  const calculateOverall = () => {
    return Number(((behaviour + drivingSkill + safety + communication + vehicleCleanliness) / 5).toFixed(1));
  };

  const handleRatingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsSubmitting(true);
    setError('');

    try {
      const res = await fetch('/api/feedback/rate-trip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookingId: booking.id,
          customerId: booking.customerId,
          customerName: booking.customerName,
          driverId: booking.driverId,
          behaviour,
          drivingSkill,
          safety,
          communication,
          vehicleCleanliness,
          overall: calculateOverall(),
          comment
        })
      });

      const data = await res.json();
      if (res.ok) {
        onRatingSuccess();
        onClose();
      } else {
        setError(data.error || 'Failed to submit rating');
      }
    } catch (err: any) {
      setError(err.message || 'Network error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStarInput = (label: string, value: number, onChange: (val: number) => void) => (
    <div className="flex items-center justify-between py-2 border-b border-slate-100">
      <span className="text-sm font-semibold text-slate-800">{label}</span>
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="p-1 hover:scale-110 transition-transform cursor-pointer"
          >
            <Star
              className={`w-5 h-5 ${
                star <= value ? 'fill-amber-400 text-amber-500' : 'text-slate-300'
              }`}
            />
          </button>
        ))}
        <span className="ml-2 font-bold text-xs w-6 text-slate-600">{value}/5</span>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-lg">Rate Your Trip Experience</h3>
            <p className="text-xs text-emerald-100 mt-0.5">
              Driver: {booking.driverName} • Trip Date: {booking.tripDate}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleRatingSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs font-semibold">
              {error}
            </div>
          )}

          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
                Calculated Overall Score
              </span>
              <p className="text-2xl font-extrabold text-amber-900 mt-0.5">
                {calculateOverall()} / 5.0
              </p>
            </div>
            <div className="flex">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star
                  key={s}
                  className={`w-5 h-5 ${
                    s <= Math.round(calculateOverall())
                      ? 'fill-amber-400 text-amber-500'
                      : 'text-amber-200'
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="space-y-1">
            {renderStarInput('Driver Behaviour & Politeness', behaviour, setBehaviour)}
            {renderStarInput('Driving Skill & Traffic Control', drivingSkill, setDrivingSkill)}
            {renderStarInput('Road Safety & Defensive Driving', safety, setSafety)}
            {renderStarInput('Communication & Punctuality', communication, setCommunication)}
            {renderStarInput('Vehicle Handling & Cleanliness', vehicleCleanliness, setVehicleCleanliness)}
          </div>

          <div>
            <label htmlFor="feedback-comment-input" className="block text-xs font-bold text-slate-700 mb-1">
              Your Review or Comments
            </label>
            <textarea
              id="feedback-comment-input"
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="How was your trip with this acting driver?"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-xs text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-500/20 disabled:opacity-50 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>Submit 5-Dimension Rating</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
