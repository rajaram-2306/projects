import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Shield, Car, Clock, MapPin, CheckCircle, Award, ArrowRight } from 'lucide-react';
import { User } from '../types';

interface DriverCardProps {
  driver: User;
  onBookNow: (driver: User) => void;
}

export const DriverCard: React.FC<DriverCardProps> = ({ driver, onBookNow }) => {
  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs hover:shadow-xl hover:border-blue-300 transition-all duration-300 flex flex-col justify-between overflow-hidden group">
      {/* Top Banner & Avatar */}
      <div className="p-6 pb-4">
        <div className="flex items-start justify-between gap-4">
          <div className="relative">
            <img
              src={driver.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
              alt={driver.name}
              className="w-20 h-20 rounded-2xl object-cover border-2 border-white shadow-md"
            />
            {driver.isOnline ? (
              <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 border-2 border-white rounded-full" title="Online now" />
            ) : (
              <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-slate-400 border-2 border-white rounded-full" title="Offline" />
            )}
          </div>

          <div className="flex flex-col items-end">
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100">
              ₹{driver.hourlyRate || 180}/hr
            </span>
            <span className="text-[11px] font-semibold text-slate-400 mt-1">
              Minimum 3 hours
            </span>
          </div>
        </div>

        {/* Name & verification badge */}
        <div className="mt-4">
          <div className="flex items-center gap-1.5">
            <h3 className="font-extrabold text-lg text-slate-900 group-hover:text-blue-600 transition-colors">
              {driver.name}
            </h3>
            <span className="inline-flex items-center text-emerald-600" title="Background & RTO Verified">
              <CheckCircle className="w-4 h-4 fill-emerald-100" />
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>{driver.address || 'Chennai, Tamil Nadu'}</span>
          </p>
        </div>

        {/* Key attributes grid */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-100 text-center">
          <div className="p-2 rounded-xl bg-slate-50">
            <div className="flex items-center justify-center gap-1 text-amber-500 font-bold text-sm">
              <Star className="w-4 h-4 fill-amber-400" />
              <span>{Number(driver.rating || 5.0).toFixed(1)}</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">Rating</span>
          </div>

          <div className="p-2 rounded-xl bg-slate-50">
            <div className="flex items-center justify-center gap-1 text-slate-800 font-bold text-sm">
              <Award className="w-4 h-4 text-blue-600" />
              <span>{driver.experience || 5} yrs</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">Experience</span>
          </div>

          <div className="p-2 rounded-xl bg-slate-50">
            <div className="flex items-center justify-center gap-1 text-slate-800 font-bold text-sm">
              <Car className="w-4 h-4 text-emerald-600" />
              <span>{driver.totalTrips || 0}</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">Trips</span>
          </div>
        </div>

        {/* Vehicle category tag */}
        <div className="mt-4 flex items-center gap-2">
          <span className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 text-slate-700">
            Specialist: {driver.vehicleType || 'Sedan & SUV'}
          </span>
          <span className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100">
            {driver.isOnline ? 'Available Now' : 'Advance Book'}
          </span>
        </div>
      </div>

      {/* Action footer */}
      <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2">
        <Link
          to={`/drivers/${driver.id}`}
          className="flex-1 text-center py-2.5 px-3 rounded-xl border border-slate-300 font-bold text-xs text-slate-700 hover:bg-white transition-colors"
        >
          View Profile
        </Link>
        <button
          onClick={() => onBookNow(driver)}
          className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm shadow-blue-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <span>Book Driver</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
