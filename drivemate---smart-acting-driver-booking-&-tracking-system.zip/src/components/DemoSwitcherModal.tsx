import React from 'react';
import { User, Shield, Car, CheckCircle2, Clock, X, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

interface DemoSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DemoSwitcherModal: React.FC<DemoSwitcherModalProps> = ({ isOpen, onClose }) => {
  const { user, demoSwitch } = useAuth();

  if (!isOpen) return null;

  const roles = [
    {
      title: 'Customer (M. Rajaram)',
      role: 'customer' as UserRole,
      status: undefined,
      description: 'Book drivers, view live GPS tracking, rate trips & submit support tickets',
      icon: User,
      color: 'bg-blue-50 text-blue-700 border-blue-200'
    },
    {
      title: 'Active Driver (Rajesh Kumar)',
      role: 'driver' as UserRole,
      status: 'active',
      description: 'Accept booking requests, broadcast live GPS location, view earnings & trip history',
      icon: Car,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200'
    },
    {
      title: 'Pending Driver (Suresh Mohan)',
      role: 'driver' as UserRole,
      status: 'pending_approval',
      description: 'Waiting in Admin review queue after document submission (test approval flow)',
      icon: Clock,
      color: 'bg-amber-50 text-amber-700 border-amber-200'
    },
    {
      title: 'Admin / Ops Manager',
      role: 'admin' as UserRole,
      status: undefined,
      description: 'Approve driver documents, monitor live trips, view analytics & manage platform',
      icon: Shield,
      color: 'bg-purple-50 text-purple-700 border-purple-200'
    }
  ];

  const handleSelectRole = async (role: UserRole, status?: string) => {
    await demoSwitch(role, status);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 bg-gradient-to-r from-blue-600 to-indigo-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-6 h-6 text-amber-300" />
            <div>
              <h3 className="font-extrabold text-lg">Instant Role Switcher</h3>
              <p className="text-xs text-blue-100 mt-0.5">Test any DriveMate role with realistic seed data</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-3">
          {roles.map((item) => {
            const Icon = item.icon;
            const isCurrent =
              user?.role === item.role &&
              (item.role !== 'driver' || user?.status === item.status);

            return (
              <button
                key={`${item.role}-${item.status || ''}`}
                onClick={() => handleSelectRole(item.role, item.status)}
                className={`w-full flex items-start gap-4 p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                  isCurrent
                    ? 'border-blue-600 bg-blue-50/60 ring-2 ring-blue-500/20'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className={`p-3 rounded-xl border shrink-0 ${item.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-900">{item.title}</span>
                    {isCurrent && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-600 bg-blue-100 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Active Role
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">{item.description}</p>
                </div>
              </button>
            );
          })}
        </div>

        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Current: <strong className="text-slate-800">{user ? `${user.name} (${user.role})` : 'Guest'}</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
