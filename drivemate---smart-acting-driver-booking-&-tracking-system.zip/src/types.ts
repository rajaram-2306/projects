export type UserRole = 'admin' | 'driver' | 'customer';
export type DriverStatus = 'active' | 'pending_approval' | 'rejected' | 'suspended';
export type BookingStatus = 'requested' | 'accepted' | 'rejected' | 'in-progress' | 'completed' | 'cancelled';

export interface User {
  id: string;
  role: UserRole;
  name: string;
  email: string;
  mobile: string;
  status?: DriverStatus;
  address?: string;
  aadhaarNumber?: string;
  licenseNumber?: string;
  vehicleType?: 'Hatchback' | 'Sedan' | 'SUV' | 'Luxury' | 'All';
  vehicleNumber?: string;
  experience?: number;
  avatarUrl?: string;
  rating?: number;
  totalTrips?: number;
  hourlyRate?: number;
  isOnline?: boolean;
  createdAt: string;
  documentUrls?: {
    photo?: string;
    license?: string;
    aadhaar?: string;
    rcBook?: string;
    insurance?: string;
  };
  location?: {
    lat: number;
    lng: number;
    isOnline: boolean;
  };
}

export interface Booking {
  id: string;
  customerId: string;
  customerName: string;
  customerMobile: string;
  driverId: string;
  driverName: string;
  driverMobile: string;
  pickupAddress: string;
  pickupLat: number;
  pickupLng: number;
  destinationAddress: string;
  destinationLat: number;
  destinationLng: number;
  vehicleType: string;
  vehicleModel: string;
  vehicleNumber: string;
  tripDate: string;
  tripTime: string;
  status: BookingStatus;
  estimatedFare: number;
  actualFare?: number;
  distanceKm: number;
  etaMinutes: number;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  cancellationReason?: string;
}

export interface Rating {
  id: string;
  bookingId: string;
  customerId: string;
  customerName: string;
  driverId: string;
  behaviour: number;
  drivingSkill: number;
  safety: number;
  communication: number;
  vehicleCleanliness: number;
  overall: number;
  comment: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'booking' | 'system' | 'approval' | 'rating';
  isRead: boolean;
  createdAt: string;
  link?: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
  isPublished: boolean;
}

export interface Testimonial {
  id: string;
  author: string;
  role: string;
  content: string;
  rating: number;
  avatarUrl: string;
}
