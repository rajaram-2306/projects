export type PageType = 'home' | 'about' | 'products' | 'gallery' | 'contact' | 'blog';

export interface Product {
  id: string;
  name: string;
  tamilName?: string;
  category: 'fruit' | 'vegetable' | 'grocery' | 'service';
  price: number;
  unit: string;
  image: string;
  description: string;
  badge?: string;
  isFeatured?: boolean;
  isOrganic?: boolean;
  rating: number;
  reviewsCount: number;
  inStock: boolean;
  nutrition?: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  comment: string;
  rating: number;
  avatar: string;
  date: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'fruits' | 'vegetables' | 'store' | 'grocery' | 'fresh';
  image: string;
  description: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  category: string;
  image: string;
  tags: string[];
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}
