import { Product, Testimonial, GalleryItem, BlogPost, FAQItem } from '../types';

export const STORE_INFO = {
  name: 'Anbu Fruit & Vegetable Shop',
  tagline: 'Fresh. Organic. Delivered.',
  owner: 'Mr. Anbu & Family',
  address: 'Main Road, Balakrishnapuram, Dindigul, Tamil Nadu - 624005, India',
  landmark: 'Near Balakrishnapuram Bus Stand & Temple Street',
  phone: '+91 94876 02371',
  whatsapp: '919487602371',
  email: 'contact@anbufruits.com',
  hours: 'Monday – Sunday: 7:00 AM – 9:00 PM',
  establishedYear: '2008',
  deliveryRadius: '15 km around Dindigul town',
  freeDeliveryThreshold: 300,
};

export const PRODUCTS: Product[] = [
  // Fruits
  {
    id: 'f-apple',
    name: 'Crisp Shimla Apple',
    tamilName: 'ஆப்பிள் (Apple)',
    category: 'fruit',
    price: 180,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=800&q=80',
    description: 'Sweet, juicy, and crunch-packed Grade-A apples directly sourced from Kinnaur & Shimla orchards.',
    badge: 'Best Seller',
    isFeatured: true,
    isOrganic: true,
    rating: 4.9,
    reviewsCount: 142,
    inStock: true,
    nutrition: ['Rich in Fiber', 'Vitamin C', 'Antioxidants', 'Low Calorie']
  },
  {
    id: 'f-banana',
    name: 'Robusta & Sevvazhai Banana',
    tamilName: 'செவ்வாழை & பழம் (Banana)',
    category: 'fruit',
    price: 60,
    unit: 'dozen',
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=800&q=80',
    description: 'Naturally ripened local Dindigul Sevvazhai and Karpooravalli bananas, packed with potassium and natural sweetness.',
    badge: 'Daily Fresh',
    isFeatured: true,
    isOrganic: true,
    rating: 4.8,
    reviewsCount: 98,
    inStock: true,
    nutrition: ['High Potassium', 'Energy Booster', 'Vitamin B6']
  },
  {
    id: 'f-mango',
    name: 'Alphonso & Banganapalli Mango',
    tamilName: 'மாம்பழம் (Mango)',
    category: 'fruit',
    price: 140,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=800&q=80',
    description: 'Aromatic, tree-ripened farm mangoes free from carbide chemicals. Pure sweetness in every slice.',
    badge: 'Seasonal Prime',
    isFeatured: true,
    isOrganic: true,
    rating: 5.0,
    reviewsCount: 210,
    inStock: true,
    nutrition: ['Vitamin A', 'Vitamin C', 'Digestive Enzymes']
  },
  {
    id: 'f-orange',
    name: 'Nagpur & Sweet Lime Orange',
    tamilName: 'ஆரஞ்சு (Orange)',
    category: 'fruit',
    price: 90,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1547514701-42782101795e?auto=format&fit=crop&w=800&q=80',
    description: 'Juicy, pulp-rich oranges bursting with natural citrus hydration and immunity-boosting Vitamin C.',
    badge: 'Juicy',
    isFeatured: true,
    isOrganic: true,
    rating: 4.7,
    reviewsCount: 85,
    inStock: true,
    nutrition: ['Vitamin C', 'Hydrating', 'Folate']
  },
  {
    id: 'f-watermelon',
    name: 'Crisp Red Watermelon',
    tamilName: 'தர்பூசணி (Watermelon)',
    category: 'fruit',
    price: 35,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?auto=format&fit=crop&w=800&q=80',
    description: 'Deep red, seedless & seeded farm-fresh watermelons. Ultimate summer cooler for your family.',
    badge: 'Hydration Pack',
    isFeatured: true,
    isOrganic: true,
    rating: 4.9,
    reviewsCount: 120,
    inStock: true,
    nutrition: ['92% Water', 'Lycopene', 'Electrolytes']
  },
  {
    id: 'f-pineapple',
    name: 'Queen Pineapple',
    tamilName: 'அன்னாசி பழம் (Pineapple)',
    category: 'fruit',
    price: 70,
    unit: 'piece',
    image: 'https://images.unsplash.com/photo-1550258987-190a2d41a8ba?auto=format&fit=crop&w=800&q=80',
    description: 'Tangy-sweet, fragrant pineapples packed with bromelain enzymes for healthy digestion.',
    badge: 'Fresh Cut',
    isFeatured: false,
    isOrganic: true,
    rating: 4.6,
    reviewsCount: 64,
    inStock: true,
    nutrition: ['Bromelain', 'Manganese', 'Vitamin C']
  },
  {
    id: 'f-grapes',
    name: 'Black Seedless & Green Grapes',
    tamilName: 'திராட்சை (Grapes)',
    category: 'fruit',
    price: 110,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1537640538966-79f369143f8f?auto=format&fit=crop&w=800&q=80',
    description: 'Plump, sweet, crisp table grapes harvested from local Tamil Nadu vineyards.',
    badge: 'Farm Fresh',
    isFeatured: false,
    isOrganic: true,
    rating: 4.8,
    reviewsCount: 78,
    inStock: true,
    nutrition: ['Resveratrol', 'Heart Health', 'Vitamin K']
  },
  {
    id: 'f-guava',
    name: 'Pink & White Country Guava',
    tamilName: 'கொய்யா பழம் (Guava)',
    category: 'fruit',
    price: 60,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1536511135882-7e0e5a95efd5?auto=format&fit=crop&w=800&q=80',
    description: 'Crisp country guavas with sweet pink pulp. Contains 4x more Vitamin C than oranges!',
    badge: 'Superfood',
    isFeatured: true,
    isOrganic: true,
    rating: 4.9,
    reviewsCount: 115,
    inStock: true,
    nutrition: ['High Fiber', '4x Vitamin C', 'Low Glycemic']
  },

  // Vegetables
  {
    id: 'v-tomato',
    name: 'Country Tomato (Naattu Thakkali)',
    tamilName: 'நாட்டு தக்காளி (Tomato)',
    category: 'vegetable',
    price: 30,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=800&q=80',
    description: 'Juicy, tangy country tomatoes picked early morning from Oddanchatram & Dindigul farms.',
    badge: 'Essential',
    isFeatured: true,
    isOrganic: true,
    rating: 4.9,
    reviewsCount: 310,
    inStock: true,
    nutrition: ['Lycopene', 'Vitamin C', 'Potassium']
  },
  {
    id: 'v-potato',
    name: 'Ooty Fresh Potato',
    tamilName: 'உருளைக்கிழங்கு (Potato)',
    category: 'vegetable',
    price: 40,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=800&q=80',
    description: 'Clean, firm Ooty potatoes ideal for crispy roasts, kurma, and daily cooking.',
    badge: 'Kitchen Staple',
    isFeatured: true,
    isOrganic: true,
    rating: 4.8,
    reviewsCount: 220,
    inStock: true,
    nutrition: ['Complex Carbs', 'Vitamin B6', 'Fiber']
  },
  {
    id: 'v-onion',
    name: 'Small Shallots & Big Red Onion',
    tamilName: 'சின்ன வெங்காயம் & பெரிய வெங்காயம்',
    category: 'vegetable',
    price: 55,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cf?auto=format&fit=crop&w=800&q=80',
    description: 'Aromatic Dindigul small onions (Chinna Vengayam) and high-quality red onions for authentic sambar.',
    badge: 'Dindigul Special',
    isFeatured: true,
    isOrganic: true,
    rating: 5.0,
    reviewsCount: 410,
    inStock: true,
    nutrition: ['Quercetin', 'Immunity Boost', 'Flavonoids']
  },
  {
    id: 'v-carrot',
    name: 'Crisp Ooty Orange Carrot',
    tamilName: 'கேரட் (Carrot)',
    category: 'vegetable',
    price: 50,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?auto=format&fit=crop&w=800&q=80',
    description: 'Sweet, vibrant red-orange carrots rich in Beta-Carotene for healthy eyesight and salads.',
    badge: 'Eye Health',
    isFeatured: true,
    isOrganic: true,
    rating: 4.9,
    reviewsCount: 160,
    inStock: true,
    nutrition: ['Beta Carotene', 'Vitamin A', 'Dietary Fiber']
  },
  {
    id: 'v-brinjal',
    name: 'Purple & Green Line Brinjal',
    tamilName: 'கத்தரிக்காய் (Brinjal)',
    category: 'vegetable',
    price: 40,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1628773822503-930a85832a81?auto=format&fit=crop&w=800&q=80',
    description: 'Tender, seedless local brinjals perfect for Ennai Kathirkai and Kara குழம்பு.',
    badge: 'Fresh Harvest',
    isFeatured: false,
    isOrganic: true,
    rating: 4.7,
    reviewsCount: 88,
    inStock: true,
    nutrition: ['Nasunin', 'Antioxidants', 'Low Calorie']
  },
  {
    id: 'v-cabbage',
    name: 'Green Leaf Cabbage',
    tamilName: 'முட்டைக்கோஸ் (Cabbage)',
    category: 'vegetable',
    price: 30,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1594282486552-05b4d80fbb9f?auto=format&fit=crop&w=800&q=80',
    description: 'Tight-headed, crisp cabbages from hill country farms. Excellent for poriyal and salads.',
    badge: 'Crunchy',
    isFeatured: false,
    isOrganic: true,
    rating: 4.6,
    reviewsCount: 75,
    inStock: true,
    nutrition: ['Vitamin K', 'Sulforaphane', 'Gut Health']
  },
  {
    id: 'v-ladiesfinger',
    name: 'Tender Ladies Finger (Vendakkai)',
    tamilName: 'வெண்டைக்காய் (Okra)',
    category: 'vegetable',
    price: 45,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1628773822503-930a85832a81?auto=format&fit=crop&w=800&q=80',
    description: 'Slender, snap-fresh okra free from fibrous strings. Perfect for crisp fry and vatha kuzhambu.',
    badge: 'Tender',
    isFeatured: true,
    isOrganic: true,
    rating: 4.8,
    reviewsCount: 130,
    inStock: true,
    nutrition: ['Folate', 'Soluble Fiber', 'Magnesium']
  },
  {
    id: 'v-drumstick',
    name: 'Fresh Moringa Drumstick (Murungakkai)',
    tamilName: 'முருங்கைக்காய் (Drumstick)',
    category: 'vegetable',
    price: 60,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    description: 'Fleshy, long drumsticks harvested from local trees. Gives unmatched aroma to South Indian Sambar.',
    badge: 'Moringa Power',
    isFeatured: true,
    isOrganic: true,
    rating: 5.0,
    reviewsCount: 195,
    inStock: true,
    nutrition: ['Calcium', 'Iron', 'Anti-inflammatory']
  },
  {
    id: 'v-beetroot',
    name: 'Deep Red Beetroot',
    tamilName: 'பீட்ரூட் (Beetroot)',
    category: 'vegetable',
    price: 40,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1528825871115-3581a5387919?auto=format&fit=crop&w=800&q=80',
    description: 'Soil-fresh ruby red beetroots rich in natural nitrates and iron for blood health.',
    badge: 'Blood Purifier',
    isFeatured: false,
    isOrganic: true,
    rating: 4.8,
    reviewsCount: 92,
    inStock: true,
    nutrition: ['Nitrates', 'Iron', 'Blood Pressure Support']
  },
  {
    id: 'v-beans',
    name: 'Green Cluster & French Beans',
    tamilName: 'பீன்ஸ் (French Beans)',
    category: 'vegetable',
    price: 60,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1567375698348-5d9d5ae99de0?auto=format&fit=crop&w=800&q=80',
    description: 'Stringless, crunchy green beans loaded with dietary fiber and plant protein.',
    badge: 'Protein Packed',
    isFeatured: false,
    isOrganic: true,
    rating: 4.7,
    reviewsCount: 80,
    inStock: true,
    nutrition: ['Fiber', 'Protein', 'Silicon']
  },

  // Services / Groceries
  {
    id: 's-organic-box',
    name: 'Organic Family Weekly Veggie Basket',
    tamilName: 'வாராந்திர ஆர்கானிக் காய்கறி கூடை',
    category: 'service',
    price: 499,
    unit: 'basket (7kg)',
    image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=800&q=80',
    description: 'A curated 7kg basket containing 10 essential chemical-free vegetables + fresh greens for a family of 4.',
    badge: 'Value Pack',
    isFeatured: true,
    isOrganic: true,
    rating: 5.0,
    reviewsCount: 340,
    inStock: true
  },
  {
    id: 's-bulk-order',
    name: 'Festival & Wedding Bulk Produce Supply',
    tamilName: 'திருமணம் & விசேஷ மொத்த ஆர்டர்',
    category: 'service',
    price: 1500,
    unit: 'custom quote',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
    description: 'Direct wholesale rates for marriages, temple festivals, hotel catering, and corporate events across Dindigul.',
    badge: 'Wholesale Rate',
    isFeatured: true,
    isOrganic: true,
    rating: 4.9,
    reviewsCount: 180,
    inStock: true
  },
  {
    id: 's-express-delivery',
    name: '30-Minute Doorstep Express Home Delivery',
    tamilName: '30 நிமிட டோர் டெலிவரி (Doorstep Delivery)',
    category: 'service',
    price: 0,
    unit: 'orders above ₹300',
    image: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=800&q=80',
    description: 'Free home delivery to Balakrishnapuram and nearby Dindigul areas for orders over ₹300.',
    badge: 'Free Delivery',
    isFeatured: true,
    isOrganic: true,
    rating: 5.0,
    reviewsCount: 520,
    inStock: true
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't-1',
    name: 'R. Meenakshi Sundaram',
    location: 'Balakrishnapuram, Dindigul',
    comment: 'Anbu Fruit Shop has been our family shop for 10 years! The Sevvazhai bananas and small onions are always ultra-fresh. Their 30-minute doorstep delivery in Balakrishnapuram is a lifesaver.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
    date: '2 days ago'
  },
  {
    id: 't-2',
    name: 'Dr. S. Kanthasamy',
    location: 'Collectorate Road, Dindigul',
    comment: 'As a medical practitioner, I advocate chemical-free organic produce. Mr. Anbu personally ensures farm-direct sourcing without artificial ripening chemicals. Outstanding quality!',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    date: '1 week ago'
  },
  {
    id: 't-3',
    name: 'P. Kavitha & Family',
    location: 'RMTC Colony, Dindigul',
    comment: 'We ordered bulk vegetables for our daughter’s wedding function. Everything was delivered neatly sorted, sparkling fresh, and at wholesale prices. Highest recommendation!',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    date: '3 weeks ago'
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g-1',
    title: 'Farm Fresh Organic Apple Display',
    category: 'fruits',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=800&q=80',
    description: 'Crisp Shimla & Kashmiri apples arranged in our climate-controlled display.'
  },
  {
    id: 'g-2',
    title: 'Daily Morning Harvest Tomatoes & Greens',
    category: 'vegetables',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=800&q=80',
    description: 'Country tomatoes sourced fresh every 5:00 AM from local growers.'
  },
  {
    id: 'g-3',
    title: 'Anbu Store Balakrishnapuram Counter',
    category: 'store',
    image: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=800&q=80',
    description: 'Our clean, organized storefront welcoming patrons in Dindigul.'
  },
  {
    id: 'g-4',
    title: 'Traditional Country Shallots & Garlic',
    category: 'grocery',
    image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cf?auto=format&fit=crop&w=800&q=80',
    description: 'Premium Dindigul Chinna Vengayam dried naturally for maximum flavor.'
  },
  {
    id: 'g-5',
    title: 'Fresh Mango & Watermelon Harvest Arrival',
    category: 'fresh',
    image: new URL('../assets/images/regenerated_image_1786159496467.webp', import.meta.url).href,
    description: 'Tree-ripened Alphonso mangoes arriving daily during season.'
  },
  {
    id: 'g-6',
    title: 'Hill Country Ooty Carrots & Beetroot',
    category: 'vegetables',
    image: new URL('../assets/images/regenerated_image_1786159498140.webp', import.meta.url).href,
    description: 'Vibrant Ooty root vegetables loaded with natural vitamins.'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'b-1',
    title: '10 Health Benefits of Eating Fresh Fruits Every Day',
    slug: '10-health-benefits-eating-fresh-fruits-every-day',
    excerpt: 'Discover how incorporating fresh organic apples, guavas, oranges, and watermelons into your daily diet rejuvenates your digestive health, immunity, and skin vitality.',
    author: 'Anbu Fruit & Vegetable Team',
    date: 'August 02, 2026',
    readTime: '6 min read',
    category: 'Nutrition & Health',
    image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=1200&q=80',
    tags: ['Fresh Fruits', 'Health Tips', 'Immunity', 'Dindigul Organic'],
    content: `
      <h2>The Natural Powerhouse on Your Plate</h2>
      <p>In today's fast-paced environment, maintaining optimal health can feel challenging. However, nature has provided us with a sweet, refreshing, and incredibly potent solution: fresh fruits. At <strong>Anbu Fruit & Vegetable Shop in Balakrishnapuram, Dindigul</strong>, we observe firsthand how shifting toward daily fresh fruit consumption transforms the health and energy levels of our local families.</p>
      
      <h3>1. Boosts Immune System Function</h3>
      <p>Citrus fruits like oranges, sweet limes, and guavas are overflowing with Vitamin C. Consuming a single country guava daily fulfills over 200% of your daily Vitamin C needs, stimulating white blood cell production and safeguarding your family against seasonal viral infections.</p>

      <h3>2. Enhances Digestive Wellness and Gut Health</h3>
      <p>Fruits are rich in soluble and insoluble dietary fibers. Pectin found in apples and the fiber in papayas and bananas support regular bowel movements, nourish beneficial gut bacteria, and eliminate bloating naturally.</p>

      <h3>3. Supports Cardiovascular Health</h3>
      <p>High potassium levels in local Dindigul Sevvazhai and Karpooravalli bananas help regulate blood pressure levels by balancing sodium in the bloodstream. Furthermore, antioxidants in dark grapes protect blood vessels from oxidative stress.</p>

      <h3>4. Natural Weight Management</h3>
      <p>Replacing processed snacks with nutrient-dense fruits like watermelons, pineapples, and guavas satisfies sweet cravings while keeping caloric intake low. The high water content promotes satiety and curbs overeating.</p>

      <h3>5. Radiant Skin & Youthful Complexion</h3>
      <p>Antioxidants like beta-carotene, Vitamin A, and Lycopene neutralize free radicals that accelerate skin aging. Eating fresh mangoes, papayas, and oranges regularly promotes collagen production for a healthy glow.</p>

      <h3>6. Regulates Blood Sugar Levels Naturally</h3>
      <p>Despite their natural sweetness, whole fruits have a low to moderate Glycemic Index (GI) because their fiber slows fructose absorption. Country guavas, apples, and pomegranates are particularly beneficial for metabolic health.</p>

      <h3>7. Essential Cellular Hydration</h3>
      <p>Watermelon, muskmelon, and oranges consist of over 85–92% water paired with vital minerals like magnesium and potassium, providing deep cellular hydration during warm Tamil Nadu afternoons.</p>

      <h3>8. Reduces Chronic Inflammation</h3>
      <p>Bioactive flavonoids and polyphenols found in berries, pineapples (bromelain), and pomegranates fight internal systemic inflammation, relieving joint discomfort and fatigue.</p>

      <h3>9. Improves Mental Clarity & Mood</h3>
      <p>The natural fructose in fresh fruits supplies steady glucose to the brain without the sudden crash caused by refined sugars. Folic acid and Vitamin B6 support neurotransmitters that boost mood and focus.</p>

      <h3>10. Sourced Farm-Fresh Delivers Maximum Potency</h3>
      <p>To reap these 10 benefits, freshness is critical. Fruits stored for weeks in cold chemical storage lose up to 50% of their delicate vitamins. At Anbu Fruit & Vegetable Shop, our farm-direct daily supply chain ensures every fruit arrives at peak nutritional vitality.</p>
    `
  },
  {
    id: 'b-2',
    title: 'Why Organic Vegetables Are Better for Your Family',
    slug: 'why-organic-vegetables-are-better-for-your-family',
    excerpt: 'Learn the vital reasons why chemical-free, farm-fresh country tomatoes, Ooty carrots, small onions, and moringa drumsticks protect your family from harmful synthetic pesticides.',
    author: 'Anbu Fruit & Vegetable Team',
    date: 'July 28, 2026',
    readTime: '7 min read',
    category: 'Organic Farming',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1200&q=80',
    tags: ['Organic Vegetables', 'Pesticide Free', 'Family Health', 'Balakrishnapuram'],
    content: `
      <h2>Reclaiming Pure, Chemical-Free Food</h2>
      <p>Every parent wants to feed their family wholesome, nourishing food. However, modern commercial farming heavily relies on synthetic chemical fertilizers, systemic pesticides, and artificial wax coatings. At <strong>Anbu Fruit & Vegetable Shop</strong>, we are committed to providing Balakrishnapuram and Dindigul residents with genuine, farm-direct organic vegetables that prioritize health above profits.</p>

      <h3>1. Freedom from Toxic Chemical Residues</h3>
      <p>Conventional vegetables like tomatoes, ladies fingers, and brinjal are frequently sprayed with organophosphate pesticides right up to harvest day. Washing alone cannot completely remove systemic chemicals absorbed into the plant tissue. Organic vegetables are grown without synthetic toxins, protecting young children and elderly family members from endocrine disrupters.</p>

      <h3>2. Superior Flavor and Authentic Aroma</h3>
      <p>Have you noticed how a traditional Sambar made with Dindigul Chinna Vengayam (small onions) and fresh moringa drumstick carries an unforgettable aroma? Organic vegetables grow at their natural pace, allowing sugars, essential oils, and aromatic compounds to develop fully. They taste richer, crisper, and more authentic.</p>

      <h3>3. Higher Antioxidant & Mineral Density</h3>
      <p>Multiple agricultural studies confirm that organic produce contains up to 20–40% higher concentrations of antioxidants, Vitamin C, iron, magnesium, and calcium. Because organic plants must build their own natural defenses against pests, they synthesize richer phytonutrients that directly benefit your body.</p>

      <h3>4. Safe for Gut Microbiome & Immunity</h3>
      <p>Traces of chemical herbicides like glyphosate ingested through sprayed vegetables can disrupt delicate beneficial gut bacteria. Organic country vegetables preserve your digestive balance, improving nutrient absorption and overall immunity.</p>

      <h3>5. Environmental Sourcing & Soil Preservation</h3>
      <p>Organic farming methods replenish soil health using organic compost, neem cakes, and crop rotation. Sourcing organic vegetables from local Tamil Nadu farmers reduces carbon emissions and protects our groundwater tables from toxic chemical runoff.</p>

      <h3>6. Guaranteed Freshness with Zero Wax or Preservatives</h3>
      <p>Commercial vendors often apply artificial paraffin wax to vegetables to make them shine on display shelves. At Anbu Fruit Shop, our organic produce is delivered untreated, cleaned with pure water, and brought straight from field to counter within hours.</p>

      <h3>How to Transition Your Home to Organic Eating</h3>
      <p>You don't need to change everything overnight. Start by swapping your everyday kitchen staples—tomatoes, small onions, green chilies, drumsticks, and leafy greens—with our chemical-free organic range. Visit our store in <strong>Balakrishnapuram, Dindigul</strong> or order our 7kg Organic Weekly Family Basket for convenient doorstep delivery!</p>
    `
  }
];

export const FAQS: FAQItem[] = [
  {
    category: 'Ordering & Delivery',
    question: 'How do I place an order for home delivery in Dindigul?',
    answer: 'You can easily order online using our interactive catalog on this website or directly send us a WhatsApp message at +91 94876 02371 with your shopping list. We deliver within 30 minutes in Balakrishnapuram and nearby areas!'
  },
  {
    category: 'Ordering & Delivery',
    question: 'Is there a minimum order requirement for free delivery?',
    answer: 'Home delivery is completely FREE for all orders above ₹300 in Balakrishnapuram and within 5km of our Dindigul store. A nominal ₹30 fee applies for smaller orders.'
  },
  {
    category: 'Quality & Sourcing',
    question: 'Are your fruits and vegetables genuinely chemical-free and organic?',
    answer: 'Yes! We partner directly with certified local organic farmers from Dindigul, Oddanchatram, and Ooty. We never use carbide ripening chemicals or artificial wax coatings.'
  },
  {
    category: 'Bulk & Events',
    question: 'Do you accept bulk wholesale orders for weddings, temple festivals, and catering?',
    answer: 'Absolutely! We specialize in bulk fruit & vegetable supply for marriages, temple festivals, hotel catering, and corporate events at attractive wholesale prices. Call +91 94876 02371 for custom quotes.'
  },
  {
    category: 'Store Details',
    question: 'What are your store operating hours and location?',
    answer: 'Our physical shop is located on Main Road, Balakrishnapuram, Dindigul (Tamil Nadu 624005). We are open 7 days a week from 7:00 AM to 9:00 PM.'
  }
];
