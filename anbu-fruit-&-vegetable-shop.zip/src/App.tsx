import React, { useState, useEffect } from 'react';
import { PageType, Product, CartItem } from './types';
import { PRODUCTS } from './data/storeData';
import { Navbar } from './components/Navbar';
import { HomeSection } from './components/HomeSection';
import { AboutSection } from './components/AboutSection';
import { ProductsSection } from './components/ProductsSection';
import { GallerySection } from './components/GallerySection';
import { ContactSection } from './components/ContactSection';
import { BlogSection } from './components/BlogSection';
import { CartDrawer } from './components/CartDrawer';
import { ProjectReportModal } from './components/ProjectReportModal';
import { Footer } from './components/Footer';
import { MessageCircle, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('anbu_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Save cart to local storage
  useEffect(() => {
    try {
      localStorage.setItem('anbu_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error('Failed to save cart', e);
    }
  }, [cartItems]);

  // Scroll to top on page change
  const handleNavigate = (page: PageType) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Add product to cart
  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });

    setToastMessage(`Added ${product.name} to basket!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Update cart item quantity
  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  // Remove item from cart
  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Total cart item count
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#070d0a] text-slate-100 flex flex-col justify-between selection:bg-emerald-500 selection:text-white font-sans">
      
      {/* Sticky Header Navigation */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenReport={() => setIsReportOpen(true)}
      />

      {/* Main Page Content */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomeSection
            onNavigate={handleNavigate}
            onAddToCart={handleAddToCart}
            onQuickView={() => handleNavigate('products')}
          />
        )}

        {currentPage === 'about' && <AboutSection />}

        {currentPage === 'products' && (
          <ProductsSection onAddToCart={handleAddToCart} />
        )}

        {currentPage === 'gallery' && <GallerySection />}

        {currentPage === 'contact' && <ContactSection />}

        {currentPage === 'blog' && <BlogSection />}
      </main>

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenReport={() => setIsReportOpen(true)}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={() => setCartItems([])}
      />

      {/* Project Report & SEO Inspector Modal */}
      <ProjectReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 px-4 py-3 rounded-2xl glass-panel bg-emerald-950/90 text-white font-bold text-xs border border-emerald-400/50 shadow-2xl flex items-center gap-2 animate-in slide-in-from-bottom-5 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Floating WhatsApp Quick Action Button */}
      <a
        href="https://wa.me/919487602371?text=Hello%20Anbu%20Fruit%20Shop!%20I%20want%20to%20order%20fresh%20fruits%20%26%20vegetables."
        target="_blank"
        rel="noreferrer"
        title="Chat on WhatsApp (+91 94876 02371)"
        className="fixed bottom-6 right-6 z-40 p-3.5 rounded-full bg-emerald-500 text-slate-950 shadow-2xl shadow-emerald-500/40 hover:bg-emerald-400 hover:scale-110 active:scale-95 transition-all flex items-center justify-center border border-emerald-300"
      >
        <MessageCircle className="w-6 h-6 fill-slate-950 text-emerald-500" />
      </a>

    </div>
  );
}
