import React, { useState } from 'react';
import { Product } from '../types';
import { PRODUCTS, STORE_INFO } from '../data/storeData';
import { Search, Filter, ShoppingBag, MessageCircle, Star, Sparkles, CheckCircle2, Info, X } from 'lucide-react';

interface ProductsSectionProps {
  onAddToCart: (product: Product) => void;
}

export const ProductsSection: React.FC<ProductsSectionProps> = ({ onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating'>('featured');
  const [activeModalProduct, setActiveModalProduct] = useState<Product | null>(null);

  // Filter products
  const filteredProducts = PRODUCTS.filter((product) => {
    const matchesCategory =
      selectedCategory === 'all' || product.category === selectedCategory;
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (product.tamilName && product.tamilName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
  });

  return (
    <div className="pt-24 md:pt-28 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
      
      {/* Header */}
      <div className="text-center space-y-3 max-w-3xl mx-auto">
        <span className="text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          Fresh Store Catalog
        </span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white font-display">
          Products & <span className="text-emerald-400 font-serif-italic font-normal">Services</span>
        </h1>
        <p className="text-slate-300 text-xs sm:text-sm">
          Farm-harvested fruits, organic country vegetables, daily grocers, and wedding/festival bulk orders in Dindigul.
        </p>
      </div>

      {/* Controls: Category Filter Tabs, Search & Sort */}
      <div className="glass-card p-5 rounded-3xl border border-emerald-500/20 space-y-4">
        
        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {[
            { id: 'all', label: 'All Items' },
            { id: 'fruit', label: '🍎 Fresh Fruits' },
            { id: 'vegetable', label: '🥦 Organic Vegetables' },
            { id: 'service', label: '📦 Baskets & Bulk Services' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedCategory(tab.id)}
              className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === tab.id
                  ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Bar & Sort Dropdown */}
        <div className="flex flex-col sm:flex-row gap-3 pt-2 border-t border-slate-800">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search fruits, vegetables or Tamil names (e.g. Tomato, தக்காளி)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900/80 border border-emerald-500/30 text-white text-xs focus:outline-none focus:border-emerald-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-emerald-400 hidden sm:block" />
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="px-3 py-2.5 rounded-xl bg-slate-900/80 border border-emerald-500/30 text-white text-xs font-medium focus:outline-none focus:border-emerald-400"
            >
              <option value="featured">Sort by: Featured</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="rating">Rating: Highest Rated</option>
            </select>
          </div>
        </div>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {sortedProducts.map((product) => (
          <div
            key={product.id}
            className="glass-card rounded-2xl overflow-hidden flex flex-col justify-between group border border-emerald-500/20 hover:border-emerald-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-950/40"
          >
            <div>
              {/* Product Image */}
              <div className="relative h-48 overflow-hidden bg-slate-900">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a140f] via-transparent to-transparent opacity-80" />

                {/* Badge */}
                {product.badge && (
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono uppercase bg-emerald-500 text-slate-950 shadow-md">
                    {product.badge}
                  </span>
                )}

                {/* Info button for modal */}
                <button
                  onClick={() => setActiveModalProduct(product)}
                  title="View Nutrition & Details"
                  className="absolute top-3 right-3 p-1.5 rounded-full bg-slate-900/80 text-emerald-400 hover:text-white border border-emerald-500/40"
                >
                  <Info className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Info */}
              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-semibold text-slate-400 uppercase tracking-wider">
                    {product.category}
                  </span>
                  <div className="flex items-center gap-1 text-amber-400 text-xs font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{product.rating}</span>
                  </div>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors line-clamp-1">
                  {product.name}
                </h3>
                {product.tamilName && (
                  <p className="text-xs text-emerald-400 font-medium">{product.tamilName}</p>
                )}

                <p className="text-slate-400 text-xs line-clamp-2 leading-relaxed">
                  {product.description}
                </p>
              </div>
            </div>

            {/* Price & Actions */}
            <div className="p-4 pt-0 space-y-3">
              <div className="flex items-baseline justify-between border-t border-slate-800 pt-3">
                <div>
                  <span className="text-xl font-extrabold text-white font-display">₹{product.price}</span>
                  <span className="text-xs text-slate-400 ml-1">/ {product.unit}</span>
                </div>
                <span className="text-[11px] text-emerald-400 font-mono">Farm Fresh</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => onAddToCart(product)}
                  className="w-full py-2 px-3 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-emerald-400 transition-colors shadow-md shadow-emerald-500/20"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Add to Cart</span>
                </button>

                <a
                  href={`https://wa.me/${STORE_INFO.whatsapp}?text=${encodeURIComponent(`Hello Anbu Fruit Shop! I want to order ${product.name} (₹${product.price}/${product.unit}). Please deliver to my address in Dindigul.`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-2 px-3 rounded-xl bg-slate-800 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/10 font-bold text-xs flex items-center justify-center gap-1 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      {sortedProducts.length === 0 && (
        <div className="text-center py-16 space-y-3 glass-card rounded-3xl p-8">
          <p className="text-lg font-bold text-slate-200">No items match your search criteria.</p>
          <p className="text-xs text-slate-400">Try adjusting your category filter or search query.</p>
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-full bg-emerald-500 text-slate-950 font-bold text-xs"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Product Detail / Nutrition Modal */}
      {activeModalProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="glass-card max-w-lg w-full rounded-3xl p-6 sm:p-8 border border-emerald-500/30 space-y-6 relative overflow-hidden">
            <button
              onClick={() => setActiveModalProduct(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-900/80 text-slate-300 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4">
              <img
                src={activeModalProduct.image}
                alt={activeModalProduct.name}
                className="w-20 h-20 rounded-2xl object-cover border border-emerald-500/30"
              />
              <div>
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest">
                  {activeModalProduct.category}
                </span>
                <h3 className="text-xl font-bold text-white font-display">{activeModalProduct.name}</h3>
                {activeModalProduct.tamilName && (
                  <p className="text-xs text-emerald-300 font-medium">{activeModalProduct.tamilName}</p>
                )}
                <p className="text-lg font-bold text-amber-400 font-display mt-1">
                  ₹{activeModalProduct.price} <span className="text-xs text-slate-400 font-normal">/ {activeModalProduct.unit}</span>
                </p>
              </div>
            </div>

            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              {activeModalProduct.description}
            </p>

            {/* Nutrition highlights */}
            {activeModalProduct.nutrition && activeModalProduct.nutrition.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-mono font-bold text-emerald-400 uppercase">Nutritional Highlights:</span>
                <div className="flex flex-wrap gap-2">
                  {activeModalProduct.nutrition.map((nut, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      <span>{nut}</span>
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-2 flex gap-3">
              <button
                onClick={() => {
                  onAddToCart(activeModalProduct);
                  setActiveModalProduct(null);
                }}
                className="flex-1 py-3 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 hover:bg-emerald-400"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Cart</span>
              </button>

              <a
                href={`https://wa.me/${STORE_INFO.whatsapp}?text=${encodeURIComponent(`Hello Anbu Fruit Shop! I want to order ${activeModalProduct.name} (₹${activeModalProduct.price}/${activeModalProduct.unit}). Please deliver to my address.`)}`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 rounded-xl bg-slate-800 text-emerald-400 border border-emerald-500/30 font-bold text-xs flex items-center justify-center gap-2 hover:bg-emerald-500/10"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Order</span>
              </a>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
