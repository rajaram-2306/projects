import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Sparkles, RotateCw, RefreshCw, Layers } from 'lucide-react';

interface Hero3DSphereProps {
  onExploreClick?: () => void;
}

export const Hero3DSphere: React.FC<Hero3DSphereProps> = ({ onExploreClick }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [theme, setTheme] = useState<'orange' | 'apple' | 'watermelon'>('orange');
  const [isRotating, setIsRotating] = useState(true);
  const [interactionHint, setInteractionHint] = useState(true);

  // References for animation
  const sceneRef = useRef<THREE.Scene | null>(null);
  const sphereRef = useRef<THREE.Mesh | null>(null);
  const particleGroupRef = useRef<THREE.Group | null>(null);
  const materialRef = useRef<THREE.MeshPhysicalMaterial | null>(null);
  const lightRef = useRef<THREE.PointLight | null>(null);

  // Handle Theme Color Changes
  useEffect(() => {
    if (!materialRef.current || !lightRef.current) return;

    if (theme === 'orange') {
      materialRef.current.color.setHex(0xf97316); // Bright Citrus Orange
      materialRef.current.roughness = 0.25;
      materialRef.current.metalness = 0.1;
      materialRef.current.clearcoat = 0.8;
      lightRef.current.color.setHex(0xffaa00);
    } else if (theme === 'apple') {
      materialRef.current.color.setHex(0x10b981); // Fresh Emerald Green Apple
      materialRef.current.roughness = 0.15;
      materialRef.current.metalness = 0.2;
      materialRef.current.clearcoat = 1.0;
      lightRef.current.color.setHex(0x34d399);
    } else {
      materialRef.current.color.setHex(0xe11d48); // Ruby Watermelon Red
      materialRef.current.roughness = 0.3;
      materialRef.current.metalness = 0.05;
      materialRef.current.clearcoat = 0.6;
      lightRef.current.color.setHex(0xf43f5e);
    }
  }, [theme]);

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // 1. Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 6;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;

    // 4. Main 3D Sphere Geometry & Glossy Physical Material
    const sphereGeometry = new THREE.SphereGeometry(1.6, 64, 64);

    // Procedural organic fruit bump texture using Canvas
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 800; i++) {
        const x = Math.random() * 256;
        const y = Math.random() * 256;
        const radius = Math.random() * 2 + 1;
        ctx.fillStyle = Math.random() > 0.5 ? '#ffffff' : '#000000';
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    const bumpTexture = new THREE.CanvasTexture(canvas);
    bumpTexture.wrapS = THREE.RepeatWrapping;
    bumpTexture.wrapT = THREE.RepeatWrapping;
    bumpTexture.repeat.set(4, 4);

    const sphereMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xf97316,
      bumpMap: bumpTexture,
      bumpScale: 0.03,
      roughness: 0.25,
      metalness: 0.1,
      clearcoat: 0.9,
      clearcoatRoughness: 0.1,
      reflectivity: 0.9,
      transmission: 0.1,
    });
    materialRef.current = sphereMaterial;

    const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
    scene.add(sphere);
    sphereRef.current = sphere;

    // 5. Orbiting Floating Organic Orbs & Particles
    const particleGroup = new THREE.Group();
    scene.add(particleGroup);
    particleGroupRef.current = particleGroup;

    const orbGeometry = new THREE.SphereGeometry(0.12, 16, 16);
    const orbColors = [0x34d399, 0xf97316, 0xfacc15, 0xef4444];

    for (let i = 0; i < 16; i++) {
      const orbMat = new THREE.MeshStandardMaterial({
        color: orbColors[i % orbColors.length],
        roughness: 0.2,
        metalness: 0.8,
      });
      const orb = new THREE.Mesh(orbGeometry, orbMat);
      const angle = (i / 16) * Math.PI * 2;
      const radius = 2.8 + Math.random() * 0.8;
      orb.position.x = Math.cos(angle) * radius;
      orb.position.y = (Math.random() - 0.5) * 2;
      orb.position.z = Math.sin(angle) * radius;
      particleGroup.add(orb);
    }

    // 6. Studio Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const keyLight = new THREE.PointLight(0xffaa00, 3, 20);
    keyLight.position.set(4, 4, 4);
    scene.add(keyLight);
    lightRef.current = keyLight;

    const fillLight = new THREE.PointLight(0x10b981, 2, 20);
    fillLight.position.set(-4, -2, 3);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 1.5);
    rimLight.position.set(0, 5, -5);
    scene.add(rimLight);

    // Mouse Drag Interaction
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      setInteractionHint(false);
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !sphereRef.current) return;
      const deltaX = e.clientX - previousMousePosition.x;
      const deltaY = e.clientY - previousMousePosition.y;

      sphereRef.current.rotation.y += deltaX * 0.01;
      sphereRef.current.rotation.x += deltaY * 0.01;

      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const canvasElem = canvasRef.current;
    canvasElem.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // Resize Handler
    const handleResize = () => {
      if (!containerRef.current || !renderer) return;
      const newW = containerRef.current.clientWidth;
      const newH = containerRef.current.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (sphereRef.current && isRotating && !isDragging) {
        sphereRef.current.rotation.y += 0.006;
        sphereRef.current.rotation.x += 0.002;
      }

      if (particleGroupRef.current) {
        particleGroupRef.current.rotation.y += 0.003;
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      canvasElem.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      renderer.dispose();
    };
  }, []);

  return (
    <div ref={containerRef} className="relative w-full h-[480px] md:h-[580px] flex items-center justify-center select-none overflow-hidden">
      {/* Background Ambient Glows */}
      <div className={`absolute w-80 h-80 rounded-full blur-3xl opacity-40 transition-colors duration-700 pointer-events-none ${
        theme === 'orange' ? 'bg-orange-500/30' : theme === 'apple' ? 'bg-emerald-500/30' : 'bg-rose-500/30'
      }`} />

      {/* 3D Canvas */}
      <canvas
        ref={canvasRef}
        className="cursor-grab active:cursor-grabbing z-10 w-full h-full"
      />

      {/* Reflective Studio Floor Gradient */}
      <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-[#070d0a] via-[#070d0a]/80 to-transparent z-15 pointer-events-none" />
      <div className="absolute bottom-4 w-2/3 h-1 bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent blur-sm z-20 pointer-events-none" />

      {/* Floating 3D Controls overlay */}
      <div className="absolute bottom-6 z-30 flex flex-wrap items-center justify-center gap-3 px-4 py-2 rounded-full glass-panel border border-emerald-500/20 shadow-2xl backdrop-blur-md">
        <div className="flex items-center gap-1.5 text-xs text-slate-300 pr-2 border-r border-slate-700">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
          <span className="hidden sm:inline font-medium">3D Sphere:</span>
        </div>

        {/* Theme Buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setTheme('orange')}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all flex items-center gap-1.5 ${
              theme === 'orange'
                ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-lg shadow-orange-500/30 scale-105'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>🍊</span>
            <span className="hidden xs:inline">Citrus</span>
          </button>

          <button
            onClick={() => setTheme('apple')}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all flex items-center gap-1.5 ${
              theme === 'apple'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg shadow-emerald-500/30 scale-105'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>🍏</span>
            <span className="hidden xs:inline">Emerald Apple</span>
          </button>

          <button
            onClick={() => setTheme('watermelon')}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all flex items-center gap-1.5 ${
              theme === 'watermelon'
                ? 'bg-gradient-to-r from-rose-500 to-red-600 text-white shadow-lg shadow-rose-500/30 scale-105'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>🍉</span>
            <span className="hidden xs:inline">Ruby Melon</span>
          </button>
        </div>

        {/* Rotation Toggle */}
        <button
          onClick={() => setIsRotating(!isRotating)}
          title={isRotating ? 'Pause Rotation' : 'Auto Rotate'}
          className="p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors"
        >
          <RotateCw className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin text-emerald-400' : ''}`} />
        </button>
      </div>

      {/* Drag Hint */}
      {interactionHint && (
        <div className="absolute top-8 z-20 pointer-events-none animate-bounce">
          <span className="text-[11px] uppercase tracking-widest px-3 py-1 rounded-full bg-slate-900/80 text-emerald-400 border border-emerald-500/30 shadow-lg font-mono">
            Drag to rotate 3D Fruit Sphere
          </span>
        </div>
      )}
    </div>
  );
};
