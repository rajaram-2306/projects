import React, { useState } from 'react';
import { CartItem } from '../types';
import { STORE_INFO } from '../data/storeData';
import { X, Trash2, Plus, Minus, MessageCircle, ShoppingBag, Truck, MapPin } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [customerName, setCustomerName] = useState('');

  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const deliveryFee = subtotal >= STORE_INFO.freeDeliveryThreshold || subtotal === 0 ? 0 : 30;
  const grandTotal = subtotal + deliveryFee;

  const handleWhatsAppCheckout = () => {
    if (cartItems.length === 0) return;

    let message = `🛒 *NEW ORDER - ANBU FRUIT SHOP*\n\n`;
    message += `*Customer:* ${customerName || 'Dindigul Resident'}\n`;
    message += `*Address:* ${deliveryAddress || 'Balakrishnapuram, Dindigul'}\n\n`;
    message += `*Items Ordered:*\n`;

    cartItems.forEach((item, index) => {
      message += `${index + 1}. ${item.product.name} (${item.product.price}/${item.product.unit}) x ${item.quantity} = ₹${item.product.price * item.quantity}\n`;
    });

    message += `\n*Subtotal:* ₹${subtotal}`;
    message += `\n*Delivery Fee:* ${deliveryFee === 0 ? 'FREE (Balakrishnapuram)' : '₹' + deliveryFee}`;
    message += `\n*Grand Total:* ₹${grandTotal}\n\n`;
    message += `Please confirm order availability & estimated delivery time. Thank you!`;

    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/${STORE_INFO.whatsapp}?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md glass-card bg-[#070d0a]/95 border-l border-emerald-500/30 p-6 flex flex-col justify-between shadow-2xl">
          
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-emerald-400" />
              <h2 className="text-xl font-bold text-white font-display">Your Fresh Basket</h2>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400">
                {cartItems.length} items
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto py-4 space-y-3">
            {cartItems.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <ShoppingBag className="w-12 h-12 text-slate-600 mx-auto" />
                <p className="text-sm font-bold text-slate-300">Your shopping basket is empty</p>
                <p className="text-xs text-slate-500">
                  Explore our fresh fruits & organic vegetables catalog to add items.
                </p>
              </div>
            ) : (
              cartItems.map((item) => (
                <div
                  key={item.product.id}
                  className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-14 h-14 rounded-xl object-cover border border-slate-700 shrink-0"
                  />

                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-white truncate">{item.product.name}</h4>
                    <p className="text-[11px] text-emerald-400 font-semibold">
                      ₹{item.product.price} <span className="text-slate-400 font-normal">/ {item.product.unit}</span>
                    </p>
                  </div>

                  {/* Quantity controls */}
                  <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
                    <button
                      onClick={() => onUpdateQuantity(item.product.id, -1)}
                      className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-xs font-bold text-white w-5 text-center">{item.quantity}</span>
                    <button
                      onClick={() => onUpdateQuantity(item.product.id, 1)}
                      className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <button
                    onClick={() => onRemoveItem(item.product.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Checkout Info & WhatsApp Action */}
          {cartItems.length > 0 && (
            <div className="border-t border-slate-800 pt-4 space-y-3">
              
              {/* Delivery Input */}
              <div className="space-y-2 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Dindigul Delivery Info:</span>
                </div>
                <input
                  type="text"
                  placeholder="Your Name (e.g. Meenakshi)"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-400"
                />
                <input
                  type="text"
                  placeholder="Street / Door No in Balakrishnapuram"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Pricing breakdown */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>Subtotal</span>
                  <span className="font-bold text-white">₹{subtotal}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="flex items-center gap-1">
                    <Truck className="w-3 h-3 text-emerald-400" />
                    <span>Local Delivery Fee</span>
                  </span>
                  <span className="font-bold text-emerald-400">
                    {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
                  </span>
                </div>
                <div className="flex justify-between text-base font-extrabold text-white border-t border-slate-800 pt-2">
                  <span>Grand Total</span>
                  <span className="text-amber-400 font-display">₹{grandTotal}</span>
                </div>
              </div>

              <button
                onClick={handleWhatsAppCheckout}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 hover:opacity-95 shadow-lg shadow-emerald-500/30"
              >
                <MessageCircle className="w-4.5 h-4.5" />
                <span>Place Order via WhatsApp</span>
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
