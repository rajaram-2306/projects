import React, { useState, useEffect } from 'react';
import { PageType } from '../types';
import { ShoppingBag, Phone, Menu, X, Leaf, Sparkles, MapPin, Award } from 'lucide-react';

interface NavbarProps {
  currentPage: PageType;
  onNavigate: (page: PageType) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenReport: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  cartCount,
  onOpenCart,
  onOpenReport,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { id: PageType; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'products', label: 'Products & Services' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'contact', label: 'Contact Us' },
    { id: 'blog', label: 'Blog & Health' },
  ];

  return (
    <header className="fixed top-0 inset-x-0 z-50 px-4 py-3 sm:py-4 transition-all duration-300">
      <div className={`max-w-7xl mx-auto rounded-full transition-all duration-300 px-4 sm:px-6 py-2.5 flex items-center justify-between ${
        isScrolled
          ? 'glass-panel border-emerald-500/30 shadow-2xl shadow-emerald-950/50 bg-[#070d0a]/90 backdrop-blur-xl'
          : 'bg-[#0d1a13]/60 border border-white/10 backdrop-blur-md'
      }`}>
        
        {/* Brand Logo */}
        <button
          onClick={() => {
            onNavigate('home');
            setMobileMenuOpen(false);
          }}
          className="flex items-center gap-2.5 group text-left focus:outline-none"
        >
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-700 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform border border-emerald-300/40">
            <Leaf className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-display font-bold text-lg sm:text-xl tracking-tight text-white group-hover:text-emerald-400 transition-colors">
              ANBU
            </span>
            <p className="text-[10px] text-slate-400 font-medium tracking-wide">
              Fruit & Vegetable Shop • Dindigul
            </p>
          </div>
        </button>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-900/60 p-1 rounded-full border border-white/5">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all relative ${
                currentPage === item.id
                  ? 'text-white bg-gradient-to-r from-emerald-600 to-emerald-500 shadow-md shadow-emerald-600/30 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right Quick Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Phone Call Quick Link */}
          <a
            href="tel:+919487602371"
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold text-amber-300 bg-amber-500/10 border border-amber-500/20 hover:bg-amber-500/20 transition-colors"
          >
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            <span>+91 94876 02371</span>
          </a>



          {/* Shopping Cart Button */}
          <button
            onClick={onOpenCart}
            className="relative p-2 sm:px-3 sm:py-2 rounded-full bg-emerald-500 text-slate-950 font-semibold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/25 hover:bg-emerald-400 transition-all hover:scale-105 active:scale-95"
          >
            <ShoppingBag className="w-4 h-4 text-slate-950" />
            <span className="hidden xs:inline">Cart</span>
            {cartCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-slate-950 text-emerald-400 text-[11px] font-bold flex items-center justify-center border border-emerald-400/50 animate-bounce">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Hamburger Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-full lg:hidden glass-panel text-slate-200 hover:text-white hover:bg-slate-800"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden mt-2 max-w-7xl mx-auto rounded-2xl glass-panel p-5 border border-emerald-500/30 bg-[#070d0a]/95 backdrop-blur-2xl shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col gap-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  currentPage === item.id
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'text-slate-300 hover:bg-slate-800/80'
                }`}
              >
                {item.label}
              </button>
            ))}

            <hr className="border-slate-800 my-2" />

            <div className="flex flex-col gap-2 pt-1">
              <a
                href="tel:+919487602371"
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500/20 text-amber-300 font-semibold text-xs border border-amber-500/30"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>Call Store: +91 94876 02371</span>
              </a>

              <button
                onClick={() => {
                  onOpenReport();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 font-semibold text-xs border border-emerald-500/30 font-mono"
              >
                <Award className="w-4 h-4 text-emerald-400" />
                <span>MCA Academic Report & SEO Info</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
