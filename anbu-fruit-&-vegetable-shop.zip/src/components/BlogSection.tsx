import React, { useState } from 'react';
import { BLOG_POSTS } from '../data/storeData';
import { BlogPost } from '../types';
import { Clock, Calendar, User, ArrowLeft, Share2, Sparkles, BookOpen } from 'lucide-react';

export const BlogSection: React.FC = () => {
  const [activePost, setActivePost] = useState<BlogPost | null>(null);

  if (activePost) {
    return (
      <div className="pt-24 md:pt-28 pb-16 max-w-4xl mx-auto px-4 sm:px-6 space-y-8 animate-in fade-in duration-300">
        <button
          onClick={() => setActivePost(null)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-panel text-slate-300 hover:text-white text-xs font-semibold border border-emerald-500/20"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-400" />
          <span>Back to All Articles</span>
        </button>

        {/* Article Container */}
        <article className="glass-card rounded-3xl p-6 sm:p-10 border border-emerald-500/20 space-y-6">
          <div className="space-y-3">
            <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
              {activePost.category}
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-display leading-tight">
              {activePost.title}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 border-b border-slate-800 pb-4">
              <span className="flex items-center gap-1.5 text-slate-300">
                <User className="w-3.5 h-3.5 text-emerald-400" />
                <span>{activePost.author}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span>{activePost.date}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>{activePost.readTime}</span>
              </span>
            </div>
          </div>

          <div className="relative h-80 sm:h-96 rounded-2xl overflow-hidden">
            <img
              src={activePost.image}
              alt={activePost.title}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Article Full Content */}
          <div
            className="prose prose-invert prose-emerald max-w-none text-slate-200 text-sm sm:text-base leading-relaxed space-y-4"
            dangerouslySetInnerHTML={{ __html: activePost.content }}
          />

          {/* Tags */}
          <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-400 font-mono">Tags:</span>
              {activePost.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded-full text-xs font-medium bg-slate-900 text-emerald-400 border border-emerald-500/20"
                >
                  #{tag}
                </span>
              ))}
            </div>

            <button
              onClick={() => alert(`Share link copied: ${window.location.href}`)}
              className="px-4 py-2 rounded-full glass-panel text-xs text-slate-200 hover:text-white flex items-center gap-1.5 border border-emerald-500/20"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Share Article</span>
            </button>
          </div>
        </article>
      </div>
    );
  }

  return (
    <div className="pt-24 md:pt-28 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
      
      {/* Header */}
      <div className="text-center space-y-3 max-w-3xl mx-auto">
        <span className="text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          Health & Nutrition Journal
        </span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white font-display">
          Fresh Organic <span className="text-emerald-400 font-serif-italic font-normal">Blog & News</span>
        </h1>
        <p className="text-slate-300 text-xs sm:text-sm">
          Expert articles written by the Anbu Fruit & Vegetable Shop team to guide your family toward chemical-free living and organic wellness.
        </p>
      </div>

      {/* Blog Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {BLOG_POSTS.map((post) => (
          <article
            key={post.id}
            className="glass-card rounded-3xl overflow-hidden border border-emerald-500/20 hover:border-emerald-500/50 transition-all duration-300 flex flex-col justify-between group hover:shadow-2xl hover:shadow-emerald-950/50"
          >
            <div>
              <div className="relative h-60 overflow-hidden bg-slate-900">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-mono font-bold uppercase bg-emerald-500 text-slate-950 shadow-md">
                  {post.category}
                </span>
              </div>

              <div className="p-6 space-y-3">
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>{post.date}</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>{post.readTime}</span>
                  </span>
                </div>

                <h2 className="text-xl font-bold text-white font-display group-hover:text-emerald-400 transition-colors">
                  {post.title}
                </h2>

                <p className="text-slate-300 text-xs leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>
              </div>
            </div>

            <div className="p-6 pt-0">
              <button
                onClick={() => setActivePost(post)}
                className="w-full py-3 rounded-xl bg-slate-900 hover:bg-emerald-500 hover:text-slate-950 text-emerald-400 font-bold text-xs border border-emerald-500/30 transition-all flex items-center justify-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                <span>Read Full 400+ Word Article</span>
              </button>
            </div>
          </article>
        ))}
      </div>

    </div>
  );
};
