import React, { useState } from 'react';
import { GALLERY_ITEMS } from '../data/storeData';
import { GalleryItem } from '../types';
import { Maximize2, X, Image as ImageIcon } from 'lucide-react';

export const GallerySection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeLightbox, setActiveLightbox] = useState<GalleryItem | null>(null);

  const filteredItems = GALLERY_ITEMS.filter((item) =>
    selectedCategory === 'all' ? true : item.category === selectedCategory
  );

  return (
    <div className="pt-24 md:pt-28 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
      
      {/* Header */}
      <div className="text-center space-y-3 max-w-3xl mx-auto">
        <span className="text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          Visual Showcase
        </span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white font-display">
          Store & Harvest <span className="text-emerald-400 font-serif-italic font-normal">Gallery</span>
        </h1>
        <p className="text-slate-300 text-xs sm:text-sm">
          Explore real photographs from our Balakrishnapuram storefront, fresh daily organic harvests, fruit displays, and country produce counters.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-center gap-2 overflow-x-auto pb-2">
        {[
          { id: 'all', label: 'All Photos' },
          { id: 'fruits', label: '🍎 Fruits' },
          { id: 'vegetables', label: '🥦 Vegetables' },
          { id: 'store', label: '🏪 Storefront' },
          { id: 'grocery', label: '🧅 Groceries' },
          { id: 'fresh', label: '✨ Fresh Arrivals' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedCategory(tab.id)}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
              selectedCategory === tab.id
                ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 glass-panel'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            onClick={() => setActiveLightbox(item)}
            className="group glass-card rounded-3xl overflow-hidden cursor-pointer border border-emerald-500/20 hover:border-emerald-500/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-emerald-950/50 relative"
          >
            <div className="relative h-64 overflow-hidden bg-slate-900">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#070d0a] via-[#070d0a]/40 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              <div className="absolute top-4 right-4 p-2 rounded-full bg-slate-900/80 text-emerald-400 group-hover:scale-110 transition-transform">
                <Maximize2 className="w-4 h-4" />
              </div>

              <div className="absolute bottom-4 inset-x-4 space-y-1">
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {item.category}
                </span>
                <h3 className="text-base font-bold text-white font-display group-hover:text-emerald-400 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-300 line-clamp-1">
                  {item.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Dark Glass Lightbox Modal */}
      {activeLightbox && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-200">
          <div className="relative max-w-4xl w-full glass-card rounded-3xl p-6 border border-emerald-500/40 space-y-4">
            <button
              onClick={() => setActiveLightbox(null)}
              className="absolute top-4 right-4 p-2.5 rounded-full bg-slate-900/80 text-slate-200 hover:text-white border border-slate-700"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative rounded-2xl overflow-hidden max-h-[70vh] flex items-center justify-center bg-slate-950">
              <img
                src={activeLightbox.image}
                alt={activeLightbox.title}
                className="max-h-[65vh] w-auto object-contain rounded-xl"
              />
            </div>

            <div className="space-y-1 pt-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-emerald-400 uppercase px-2.5 py-0.5 rounded bg-emerald-500/20">
                  {activeLightbox.category}
                </span>
                <span className="text-xs text-slate-400">Anbu Fruit & Vegetable Shop • Balakrishnapuram</span>
              </div>
              <h3 className="text-2xl font-bold text-white font-display">{activeLightbox.title}</h3>
              <p className="text-slate-300 text-sm leading-relaxed">{activeLightbox.description}</p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
