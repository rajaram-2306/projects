import React, { useState } from 'react';
import { PageType, Product } from '../types';
import { PRODUCTS, TESTIMONIALS, FAQS, STORE_INFO } from '../data/storeData';
import { Hero3DSphere } from './Hero3DSphere';
import {
  Sparkles,
  ShoppingBag,
  Truck,
  ShieldCheck,
  HeartHandshake,
  Star,
  ChevronRight,
  Send,
  MessageCircle,
  Clock,
  MapPin,
  CheckCircle2,
  ChevronDown,
  ArrowRight
} from 'lucide-react';

interface HomeSectionProps {
  onNavigate: (page: PageType) => void;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
}

export const HomeSection: React.FC<HomeSectionProps> = ({
  onNavigate,
  onAddToCart,
  onQuickView,
}) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [testimonialIdx, setTestimonialIdx] = useState(0);

  const featuredProducts = PRODUCTS.filter((p) => p.isFeatured);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setNewsletterSuccess(true);
      setNewsletterEmail('');
      setTimeout(() => setNewsletterSuccess(false), 5000);
    }
  };

  const categories = [
    {
      title: 'Farm Fresh Fruits',
      tamil: 'பழங்கள் (Fruits)',
      desc: 'Shimla Apples, Sevvazhai Bananas, Mangoes, Watermelons & Country Guava',
      image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=600&q=80',
      tag: '8+ Varieties',
      pageCategory: 'fruit'
    },
    {
      title: 'Organic Vegetables',
      tamil: 'காய்கறிகள் (Vegetables)',
      desc: 'Country Tomatoes, Ooty Carrots, Shallots, Moringa Drumsticks & Okra',
      image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80',
      tag: '10+ Harvests',
      pageCategory: 'vegetable'
    },
    {
      title: 'Weekly Organic Basket',
      tamil: 'ஆர்கானிக் கூடை',
      desc: 'Curated 7kg family veggie box delivered free every week in Balakrishnapuram',
      image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
      tag: 'Best Value',
      pageCategory: 'service'
    },
  ];

  return (
    <div className="space-y-20 pb-16">
      
      {/* HERO SECTION - Dark 3D Edition */}
      <section className="relative pt-24 md:pt-28 overflow-hidden min-h-[85vh] flex flex-col justify-center">
        {/* Background glow graphics */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute top-1/3 right-10 w-96 h-96 bg-orange-500/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Text Column */}
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left pt-6 lg:pt-0">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-panel border-emerald-500/30 text-emerald-400 text-xs font-mono font-semibold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Balakrishnapuram, Dindigul • Est. 2008</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.1]">
              Pure Farm Goodness.{' '}
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 font-serif-italic font-normal py-1">
                Fresh. Organic. Delivered.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-xl mx-auto lg:mx-0 font-normal leading-relaxed">
              Welcome to <strong className="text-white">Anbu Fruit & Vegetable Shop</strong>. Delivering chemical-free, farm-harvested fruits and crisp country vegetables directly to your kitchen in Dindigul within 30 minutes.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={() => onNavigate('products')}
                className="px-7 py-3.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold text-sm shadow-xl shadow-emerald-500/30 hover:scale-105 active:scale-95 transition-all flex items-center gap-2.5"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Shop Fresh Products</span>
              </button>

              <a
                href={`https://wa.me/${STORE_INFO.whatsapp}?text=${encodeURIComponent('Hello Anbu Fruit Shop! I want to inquire about daily fresh fruits & vegetables delivery in Dindigul.')}`}
                target="_blank"
                rel="noreferrer"
                className="px-6 py-3.5 rounded-full glass-panel border border-emerald-500/30 text-white font-semibold text-sm hover:bg-emerald-500/20 hover:border-emerald-500/50 transition-all flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp Order</span>
              </a>
            </div>

            {/* Micro Stats */}
            <div className="grid grid-cols-3 gap-3 pt-6 border-t border-slate-800/80 max-w-lg mx-auto lg:mx-0">
              <div className="text-center lg:text-left">
                <p className="text-xl sm:text-2xl font-bold text-emerald-400 font-display">100%</p>
                <p className="text-[11px] text-slate-400">Chemical Free</p>
              </div>
              <div className="text-center lg:text-left">
                <p className="text-xl sm:text-2xl font-bold text-amber-400 font-display">30 Min</p>
                <p className="text-[11px] text-slate-400">Local Delivery</p>
              </div>
              <div className="text-center lg:text-left">
                <p className="text-xl sm:text-2xl font-bold text-emerald-400 font-display">15+ Yrs</p>
                <p className="text-[11px] text-slate-400">Dindigul Trust</p>
              </div>
            </div>
          </div>

          {/* Right 3D Sphere Interactive Centerpiece */}
          <div className="lg:col-span-6 flex justify-center">
            <Hero3DSphere onExploreClick={() => onNavigate('products')} />
          </div>

        </div>
      </section>

      {/* BUSINESS INTRODUCTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-3xl p-8 sm:p-12 relative overflow-hidden border border-emerald-500/20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-7 space-y-4">
              <span className="text-xs font-mono font-semibold text-emerald-400 uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                Balakrishnapuram's Trusted Store
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-white font-display">
                Dedicated to Sourcing <span className="font-serif-italic text-emerald-400 font-normal">Pure Country Harvest</span> Since 2008
              </h2>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                Founded by <strong>Mr. Anbu</strong> in Balakrishnapuram, Dindigul, our shop has grown from a neighborhood fresh stall into Dindigul’s most cherished source for Grade-A fruits and organic vegetables. We believe every home deserves produce free from artificial carbide gas, harmful waxes, or prolonged chemical storage.
              </p>
              <div className="flex flex-wrap gap-4 pt-2">
                <div className="flex items-center gap-2 text-xs font-medium text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Farm-Direct Every 5:00 AM</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Fair Pricing for Local Farmers</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Hygienically Sorted & Cleaned</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 flex justify-center">
              <div className="relative group">
                <div className="absolute -inset-2 bg-gradient-to-r from-emerald-500 to-amber-500 rounded-2xl blur-lg opacity-40 group-hover:opacity-70 transition duration-500" />
                <img
                  src="https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=800&q=80"
                  alt="Anbu Fruit Shop Counter"
                  className="relative rounded-2xl border border-emerald-500/30 object-cover h-64 w-full sm:w-80 shadow-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US - Glass Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <h2 className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">The Anbu Guarantee</h2>
          <p className="text-3xl sm:text-4xl font-bold text-white font-display">
            Why Dindigul Families Choose Us
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="glass-card p-6 rounded-2xl space-y-3 hover:-translate-y-1 transition-transform">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">100% Carbide Free</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              We never use toxic calcium carbide or artificial chemicals to ripen mangoes or bananas. 100% natural tree-ripened goodness.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl space-y-3 hover:-translate-y-1 transition-transform">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">30-Min Local Delivery</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Free doorstep delivery for Balakrishnapuram residents on orders above ₹300. Freshness delivered before breakfast!
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl space-y-3 hover:-translate-y-1 transition-transform">
            <div className="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">Direct Farm Sourcing</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Sourced daily from Oddanchatram, Ooty, and local Dindigul farmers. Cutting middlemen guarantees low prices.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl space-y-3 hover:-translate-y-1 transition-transform">
            <div className="w-12 h-12 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center border border-orange-500/30">
              <MessageCircle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">Easy WhatsApp Order</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              No complicated logins required. Just pick items or send your list on WhatsApp for instant confirmation.
            </p>
          </div>
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-10 gap-4">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">Today's Harvest</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-white font-display">
              Featured Fresh Produce
            </h2>
          </div>

          <button
            onClick={() => onNavigate('products')}
            className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 group"
          >
            <span>View All Products & Prices</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.slice(0, 8).map((product) => (
            <div
              key={product.id}
              className="glass-card rounded-2xl overflow-hidden flex flex-col justify-between group border border-emerald-500/20 hover:border-emerald-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-950/40"
            >
              <div>
                {/* Product Image */}
                <div className="relative h-48 overflow-hidden bg-slate-900">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a140f] via-transparent to-transparent opacity-80" />

                  {/* Badge */}
                  {product.badge && (
                    <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono uppercase bg-emerald-500 text-slate-950 shadow-md">
                      {product.badge}
                    </span>
                  )}

                  {/* Organic tag */}
                  {product.isOrganic && (
                    <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-900/80 text-emerald-400 border border-emerald-500/40">
                      Organic
                    </span>
                  )}
                </div>

                {/* Info */}
                <div className="p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      {product.category}
                    </span>
                    <div className="flex items-center gap-1 text-amber-400 text-xs font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>{product.rating}</span>
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors line-clamp-1">
                    {product.name}
                  </h3>
                  {product.tamilName && (
                    <p className="text-xs text-emerald-400/90 font-medium">{product.tamilName}</p>
                  )}

                  <p className="text-slate-400 text-xs line-clamp-2 leading-relaxed">
                    {product.description}
                  </p>
                </div>
              </div>

              {/* Price & Cart Actions */}
              <div className="p-4 pt-0 space-y-3">
                <div className="flex items-baseline justify-between border-t border-slate-800 pt-3">
                  <div>
                    <span className="text-xl font-extrabold text-white font-display">₹{product.price}</span>
                    <span className="text-xs text-slate-400 ml-1">/ {product.unit}</span>
                  </div>
                  <span className="text-[11px] text-emerald-400 font-mono">In Stock</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onAddToCart(product)}
                    className="w-full py-2 px-3 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-emerald-400 transition-colors shadow-md shadow-emerald-500/20"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Add to Cart</span>
                  </button>

                  <a
                    href={`https://wa.me/${STORE_INFO.whatsapp}?text=${encodeURIComponent(`Hello Anbu Fruit Shop! I would like to buy ${product.name} (₹${product.price}/${product.unit}). Please confirm availability for Dindigul delivery.`)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2 px-3 rounded-xl bg-slate-800 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/10 font-bold text-xs flex items-center justify-center gap-1 transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Quick Buy</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORIES SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">Explore Catalog</span>
          <h2 className="text-3xl sm:text-4xl font-bold text-white font-display">
            Browse Our Store Categories
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((cat, idx) => (
            <div
              key={idx}
              onClick={() => onNavigate('products')}
              className="group relative h-80 rounded-3xl overflow-hidden cursor-pointer border border-emerald-500/30 shadow-2xl"
            >
              <img
                src={cat.image}
                alt={cat.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#070d0a] via-[#070d0a]/60 to-transparent" />

              <div className="absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold font-mono bg-emerald-500 text-slate-950">
                {cat.tag}
              </div>

              <div className="absolute bottom-6 inset-x-6 space-y-2">
                <h3 className="text-2xl font-bold text-white font-display group-hover:text-emerald-400 transition-colors">
                  {cat.title}
                </h3>
                <p className="text-xs font-semibold text-emerald-300">{cat.tamil}</p>
                <p className="text-slate-300 text-xs line-clamp-2 leading-relaxed">
                  {cat.desc}
                </p>
                <div className="pt-2 flex items-center gap-2 text-xs font-bold text-amber-400 group-hover:translate-x-2 transition-transform">
                  <span>Explore Items</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CUSTOMER TESTIMONIALS SLIDER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-3xl p-8 sm:p-12 border border-emerald-500/20 relative overflow-hidden">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
              Dindigul Customer Reviews
            </span>

            <div className="flex justify-center gap-1 text-amber-400">
              {[...Array(TESTIMONIALS[testimonialIdx].rating)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-amber-400" />
              ))}
            </div>

            <p className="text-lg sm:text-2xl font-serif-italic text-slate-100 leading-relaxed">
              "{TESTIMONIALS[testimonialIdx].comment}"
            </p>

            <div className="flex flex-col items-center gap-1 pt-2">
              <span className="font-bold text-white text-base font-display">
                {TESTIMONIALS[testimonialIdx].name}
              </span>
              <span className="text-xs text-emerald-400 font-medium">
                {TESTIMONIALS[testimonialIdx].location} • Verified Local Patron
              </span>
            </div>

            {/* Testimonial Nav dots */}
            <div className="flex justify-center gap-2 pt-4">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setTestimonialIdx(i)}
                  className={`h-2.5 rounded-full transition-all ${
                    testimonialIdx === i ? 'w-8 bg-emerald-400' : 'w-2.5 bg-slate-700 hover:bg-slate-500'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* LATEST OFFERS BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-950 border border-emerald-500/30 p-8 sm:p-12 shadow-2xl">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold uppercase bg-amber-400 text-slate-950">
                Special Offer
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
                Weekly 7kg Organic Family Veggie Box — Just ₹499!
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed max-w-xl">
                Get 10 fresh chemical-free vegetables + morning green herbs packed in a clean reusable basket. Free doorstep delivery in Balakrishnapuram, Dindigul every Sunday!
              </p>
              <div className="pt-2">
                <a
                  href={`https://wa.me/${STORE_INFO.whatsapp}?text=${encodeURIComponent('Hello Anbu Fruit Shop! I want to subscribe to the Weekly 7kg Organic Family Veggie Box (₹499) with free doorstep delivery.')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-amber-400 text-slate-950 font-extrabold text-xs hover:bg-amber-300 transition-colors shadow-lg shadow-amber-400/20"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Subscribe via WhatsApp</span>
                </a>
              </div>
            </div>

            <div className="lg:col-span-4 flex justify-center">
              <div className="p-6 rounded-2xl glass-panel text-center space-y-2 border border-amber-400/30">
                <span className="text-xs text-amber-300 font-mono">PROMO CODE</span>
                <p className="text-2xl font-extrabold text-white font-mono tracking-wider">ANBUFRESH10</p>
                <p className="text-[11px] text-slate-400">Mention code on WhatsApp for 10% off your first order!</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NEWSLETTER */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="glass-card rounded-3xl p-8 sm:p-10 text-center space-y-4 border border-emerald-500/20">
          <h2 className="text-2xl sm:text-3xl font-bold text-white font-display">
            Stay Updated on Daily Fresh Arrivals
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm max-w-lg mx-auto">
            Subscribe to receive daily morning fresh market updates, seasonal fruit alerts, and exclusive discounts from Anbu Fruit Shop.
          </p>

          <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto pt-2">
            <input
              type="email"
              required
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="Enter your email address..."
              className="flex-1 px-4 py-3 rounded-full bg-slate-900/80 border border-emerald-500/30 text-white text-xs focus:outline-none focus:border-emerald-400"
            />
            <button
              type="submit"
              className="px-6 py-3 rounded-full bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-colors flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Subscribe</span>
            </button>
          </form>

          {newsletterSuccess && (
            <p className="text-xs font-semibold text-emerald-400 animate-fade-in">
              🎉 Thank you for subscribing! We've sent a 10% discount coupon to your email.
            </p>
          )}
        </div>
      </section>

      {/* FAQ SECTION */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center space-y-2 mb-10">
          <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">Got Questions?</span>
          <h2 className="text-3xl font-bold text-white font-display">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq, idx) => (
            <div
              key={idx}
              className="glass-card rounded-2xl border border-emerald-500/20 overflow-hidden transition-all"
            >
              <button
                onClick={() => setOpenFaqIndex(openFaqIndex === idx ? null : idx)}
                className="w-full text-left p-5 font-bold text-white text-sm flex items-center justify-between gap-4 hover:text-emerald-400 transition-colors"
              >
                <span>{faq.question}</span>
                <ChevronDown className={`w-4 h-4 text-emerald-400 transition-transform ${openFaqIndex === idx ? 'rotate-180' : ''}`} />
              </button>

              {openFaqIndex === idx && (
                <div className="px-5 pb-5 text-slate-300 text-xs leading-relaxed border-t border-slate-800/80 pt-3">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
