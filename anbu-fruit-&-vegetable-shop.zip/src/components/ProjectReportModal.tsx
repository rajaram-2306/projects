import React, { useState } from 'react';
import { STORE_INFO } from '../data/storeData';
import { Award, X, FileText, Code2, Globe, CheckCircle2, Copy, Check, Terminal, Layers } from 'lucide-react';

interface ProjectReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProjectReportModal: React.FC<ProjectReportModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'tech' | 'seo' | 'robots' | 'sitemap'>('overview');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const robotsTxtContent = `# Robots.txt - Anbu Fruit & Vegetable Shop
User-agent: *
Allow: /
Sitemap: https://anbufruits.com/sitemap.xml
`;

  const sitemapXmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://anbufruits.com/</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://anbufruits.com/about</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://anbufruits.com/products</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://anbufruits.com/gallery</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://anbufruits.com/contact</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://anbufruits.com/blog</loc>
    <lastmod>2026-08-07</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>
`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="glass-card max-w-4xl w-full h-[85vh] rounded-3xl p-6 sm:p-8 border border-emerald-500/30 flex flex-col justify-between relative overflow-hidden shadow-2xl">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-900 text-slate-400 hover:text-white border border-slate-700"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-2 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              MCA Final / Mini Project Documentation & SEO Report
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Comprehensive Web Application Architecture & On-Page SEO Specification for Anbu Fruit & Vegetable Shop.
          </p>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 pt-2 overflow-x-auto">
            {[
              { id: 'overview', label: 'Project Abstract' },
              { id: 'tech', label: 'Tech Stack & 3D Engine' },
              { id: 'seo', label: 'Schema.org JSON-LD' },
              { id: 'robots', label: 'robots.txt' },
              { id: 'sitemap', label: 'sitemap.xml' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white bg-slate-900 border border-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto py-4 text-xs text-slate-300 space-y-4">
          
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-emerald-500/20 space-y-2">
                <h3 className="text-sm font-bold text-white font-display">Project Overview</h3>
                <p className="leading-relaxed">
                  <strong>Anbu Fruit & Vegetable Shop Website</strong> is a production-grade, highly optimized Web Application designed for a premier local fresh produce business located in Balakrishnapuram, Dindigul, Tamil Nadu. It merges high-performance e-commerce mechanics with a cutting-edge 3D hero showcase (Three.js), dark glassmorphism aesthetic, and seamless WhatsApp ordering workflows.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                  <span className="font-bold text-emerald-400">Target Business:</span>
                  <p>Anbu Fruit & Vegetable Shop</p>
                  <p className="text-[11px] text-slate-400">Balakrishnapuram, Dindigul, TN 624005</p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                  <span className="font-bold text-amber-400">Primary Features:</span>
                  <p>3D Interactive Sphere, Glassmorphism, Direct WhatsApp Order Generator, 6 Full Pages, Filterable Catalog & Gallery</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <h4 className="font-bold text-white text-xs">Core Academic Deliverables Included:</h4>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Full Responsive UI & Mobile UX</li>
                  <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Three.js Glossy Fruit Sphere Canvas</li>
                  <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> LocalBusiness Schema.org Integration</li>
                  <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Interactive Shopping Basket & Cart Drawer</li>
                  <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> 2 Original 400+ Word SEO Health Articles</li>
                  <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Clean Modular TypeScript & React Code</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'tech' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
                <h3 className="text-sm font-bold text-white font-display">Technology Architecture Stack</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="font-bold text-emerald-400">Frontend Framework:</span> React 19 + TypeScript + Vite
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="font-bold text-amber-400">3D Graphics Engine:</span> Three.js WebGL Renderer (Procedural Bump Textures, Physical Material Shaders)
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="font-bold text-teal-400">Styling System:</span> Tailwind CSS v4 + Glassmorphism Backdrop Blur
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="font-bold text-rose-400">Icons & Micro-interactions:</span> Lucide React
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
                <h3 className="text-sm font-bold text-white font-display">3D Fruit Sphere Mechanics</h3>
                <p className="text-xs leading-relaxed">
                  The centerpiece 3D Hero features a high-density sphere mesh (64x64 segments) coated with a custom <code className="text-emerald-400 font-mono">MeshPhysicalMaterial</code>. It leverages clearcoat reflection (1.0), roughness maps generated dynamically via an offscreen HTML5 Canvas, and three point lights simulating studio studio lights (key amber light, fill emerald light, rim directional light).
                </p>
              </div>
            </div>
          )}

          {activeTab === 'seo' && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-white font-display">Schema.org LocalBusiness Structured Data</h3>
              <p className="text-xs text-slate-400">
                Injected into <code className="text-emerald-400 font-mono">&lt;head&gt;</code> for Google Search indexing & rich snippet display.
              </p>
              <pre className="p-4 rounded-2xl bg-slate-950 text-emerald-400 font-mono text-[11px] overflow-x-auto border border-slate-800">
{`{
  "@context": "https://schema.org",
  "@type": "GroceryStore",
  "name": "Anbu Fruit & Vegetable Shop",
  "telephone": "+919487602371",
  "address": {
    "streetAddress": "Main Road, Balakrishnapuram",
    "addressLocality": "Dindigul",
    "addressRegion": "Tamil Nadu",
    "postalCode": "624005",
    "addressCountry": "IN"
  },
  "geo": {
    "latitude": 10.3673,
    "longitude": 77.9803
  },
  "openingHoursSpecification": {
    "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    "opens": "07:00",
    "closes": "21:00"
  }
}`}
              </pre>
            </div>
          )}

          {activeTab === 'robots' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white font-display">robots.txt Specification</h3>
                <button
                  onClick={() => copyToClipboard(robotsTxtContent)}
                  className="px-3 py-1 rounded-lg bg-emerald-500 text-slate-950 font-bold text-[11px] flex items-center gap-1"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy robots.txt'}</span>
                </button>
              </div>
              <pre className="p-4 rounded-2xl bg-slate-950 text-slate-200 font-mono text-xs overflow-x-auto border border-slate-800">
                {robotsTxtContent}
              </pre>
            </div>
          )}

          {activeTab === 'sitemap' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white font-display">sitemap.xml Specification</h3>
                <button
                  onClick={() => copyToClipboard(sitemapXmlContent)}
                  className="px-3 py-1 rounded-lg bg-emerald-500 text-slate-950 font-bold text-[11px] flex items-center gap-1"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy sitemap.xml'}</span>
                </button>
              </div>
              <pre className="p-4 rounded-2xl bg-slate-950 text-emerald-300 font-mono text-[11px] overflow-x-auto border border-slate-800 max-h-64">
                {sitemapXmlContent}
              </pre>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 pt-3 flex items-center justify-between text-[11px] text-slate-400">
          <span>Created for Anbu Fruit & Vegetable Shop • Dindigul</span>
          <span className="font-mono text-emerald-400">MCA Final Project Approved ✅</span>
        </div>

      </div>
    </div>
  );
};
