import React, { useState } from 'react';
import { STORE_INFO } from '../data/storeData';
import { Phone, MapPin, Clock, Mail, MessageCircle, Send, CheckCircle2, Navigation, Facebook, Instagram, Youtube } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    email: '',
    subject: 'Daily Fresh Home Delivery',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: '',
        mobile: '',
        email: '',
        subject: 'Daily Fresh Home Delivery',
        message: '',
      });
    }, 6000);
  };

  return (
    <div className="pt-24 md:pt-28 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
      
      {/* Header */}
      <div className="text-center space-y-3 max-w-3xl mx-auto">
        <span className="text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          Get In Touch
        </span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white font-display">
          Contact <span className="text-emerald-400 font-serif-italic font-normal">Anbu Shop</span>
        </h1>
        <p className="text-slate-300 text-xs sm:text-sm">
          Have a inquiry regarding doorstep delivery, bulk wedding produce orders, or organic baskets in Dindigul? We are here to help!
        </p>
      </div>

      {/* Grid: Details & Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Business Info Cards */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass-card p-8 rounded-3xl border border-emerald-500/20 space-y-6">
            <h2 className="text-2xl font-bold text-white font-display">Store Information</h2>

            <div className="space-y-4">
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">Shop Address</h4>
                  <p className="text-slate-300 text-xs leading-relaxed mt-0.5">
                    {STORE_INFO.address}
                  </p>
                  <p className="text-xs text-emerald-400 mt-1 font-medium">Landmark: {STORE_INFO.landmark}</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">Phone & WhatsApp</h4>
                  <a href="tel:+919487602371" className="text-slate-300 text-xs hover:text-white font-semibold">
                    {STORE_INFO.phone}
                  </a>
                  <p className="text-[11px] text-slate-400">Call anytime during store hours</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">Operating Hours</h4>
                  <p className="text-slate-300 text-xs">{STORE_INFO.hours}</p>
                  <p className="text-[11px] text-emerald-400 font-medium">Open 7 Days a Week!</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">Email Support</h4>
                  <p className="text-slate-300 text-xs">{STORE_INFO.email}</p>
                </div>
              </div>
            </div>

            {/* Quick WhatsApp CTA button */}
            <div className="pt-2">
              <a
                href={`https://wa.me/${STORE_INFO.whatsapp}?text=${encodeURIComponent('Hello Anbu Shop! I am contacting you from your website regarding fresh produce.')}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 hover:opacity-90 transition-opacity shadow-lg shadow-emerald-500/25"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat Directly on WhatsApp</span>
              </a>
            </div>

            {/* Social Links */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400">Connect With Us:</span>
              <div className="flex items-center gap-2">
                <a href="https://facebook.com" target="_blank" rel="noreferrer" className="p-2 rounded-full bg-slate-900 text-slate-300 hover:text-emerald-400">
                  <Facebook className="w-4 h-4" />
                </a>
                <a href="https://instagram.com" target="_blank" rel="noreferrer" className="p-2 rounded-full bg-slate-900 text-slate-300 hover:text-emerald-400">
                  <Instagram className="w-4 h-4" />
                </a>
                <a href="https://youtube.com" target="_blank" rel="noreferrer" className="p-2 rounded-full bg-slate-900 text-slate-300 hover:text-emerald-400">
                  <Youtube className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Contact Form */}
        <div className="lg:col-span-7">
          <div className="glass-card p-8 rounded-3xl border border-emerald-500/20 space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-white font-display">Send Us a Message</h2>
              <p className="text-slate-300 text-xs mt-1">
                Fill out the form below for home delivery inquiries, wholesale bulk orders, or custom feedback.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Meenakshi Sundaram"
                    className="w-full px-4 py-3 rounded-xl bg-slate-900/80 border border-emerald-500/30 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    placeholder="e.g. +91 94876 02371"
                    className="w-full px-4 py-3 rounded-xl bg-slate-900/80 border border-emerald-500/30 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Email Address (Optional)</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@example.com"
                    className="w-full px-4 py-3 rounded-xl bg-slate-900/80 border border-emerald-500/30 text-white text-xs focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Inquiry Subject</label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-slate-900/80 border border-emerald-500/30 text-white text-xs focus:outline-none focus:border-emerald-400"
                  >
                    <option value="Daily Fresh Home Delivery">Daily Fresh Home Delivery</option>
                    <option value="Wedding / Event Bulk Order">Wedding / Event Bulk Order</option>
                    <option value="Weekly Organic Basket Subscription">Weekly Organic Basket Subscription</option>
                    <option value="General Inquiry">General Inquiry</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Your Message or Order Details *</label>
                <textarea
                  required
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell us what fruits or vegetables you need, delivery location in Dindigul..."
                  className="w-full px-4 py-3 rounded-xl bg-slate-900/80 border border-emerald-500/30 text-white text-xs focus:outline-none focus:border-emerald-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-colors flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25"
              >
                <Send className="w-4 h-4" />
                <span>Submit Inquiry</span>
              </button>

              {submitted && (
                <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Thank you! Your message has been sent to Mr. Anbu. We will contact you back on {formData.mobile} within 15 minutes!</span>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* Map Embed Section */}
      <div className="glass-card p-6 rounded-3xl border border-emerald-500/20 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-white font-bold text-base font-display">
            <Navigation className="w-5 h-5 text-emerald-400" />
            <span>Store Location Map — Balakrishnapuram, Dindigul</span>
          </div>
          <a
            href="https://maps.google.com/?q=Balakrishnapuram+Dindigul"
            target="_blank"
            rel="noreferrer"
            className="text-xs text-emerald-400 font-semibold hover:underline"
          >
            Open in Google Maps ↗
          </a>
        </div>

        {/* Interactive Simulated Map Frame */}
        <div className="relative w-full h-72 rounded-2xl overflow-hidden bg-slate-900 border border-emerald-500/30 flex items-center justify-center">
          <iframe
            title="Anbu Fruit Shop Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31375.438596636733!2d77.96205565!3d10.367333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b00ab0000000000%3A0x0!2sDindigul%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1650000000000!5m2!1sen!2sin"
            className="w-full h-full border-0 grayscale opacity-80 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
            loading="lazy"
          />
          <div className="absolute bottom-4 left-4 p-3 rounded-xl glass-panel text-xs text-white border border-emerald-500/30">
            <p className="font-bold">Anbu Fruit & Vegetable Shop</p>
            <p className="text-slate-300 text-[11px]">Balakrishnapuram, Dindigul - 624005</p>
          </div>
        </div>
      </div>

    </div>
  );
};
