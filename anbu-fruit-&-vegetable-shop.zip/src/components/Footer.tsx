import React from 'react';
import { PageType } from '../types';
import { STORE_INFO } from '../data/storeData';
import { Leaf, Phone, MapPin, Clock, Heart, Award, ArrowUp } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: PageType) => void;
  onOpenReport: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenReport }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#040806] border-t border-emerald-500/20 text-slate-300 pt-16 pb-12 relative overflow-hidden">
      
      {/* Glow highlight */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-1 bg-gradient-to-r from-transparent via-emerald-500/50 to-transparent blur-sm" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          
          {/* Brand Info */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-700 flex items-center justify-center border border-emerald-300/40">
                <Leaf className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-display font-bold text-xl text-white">ANBU</span>
                <p className="text-xs text-slate-400 font-medium">Fruit & Vegetable Shop • Dindigul</p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Providing Balakrishnapuram and Dindigul residents with 100% chemical-free, farm-fresh organic fruits, vegetables, and daily grocery items. Delivering farm goodness to your kitchen within 30 minutes!
            </p>

            <div className="space-y-1.5 text-xs text-slate-300">
              <p className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Balakrishnapuram, Dindigul - 624005, Tamil Nadu</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <a href="tel:+919487602371" className="hover:text-white font-semibold">+91 94876 02371</a>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <span>Mon – Sun: 7:00 AM – 9:00 PM</span>
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-bold text-white text-sm font-display tracking-wider uppercase">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-emerald-400 transition-colors">
                  Home Page
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-emerald-400 transition-colors">
                  About Us & Story
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('products')} className="hover:text-emerald-400 transition-colors">
                  Products & Services Catalog
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('gallery')} className="hover:text-emerald-400 transition-colors">
                  Store & Harvest Gallery
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-emerald-400 transition-colors">
                  Contact Us & Map
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('blog')} className="hover:text-emerald-400 transition-colors">
                  Health & Organic Blog
                </button>
              </li>
            </ul>
          </div>

          {/* Academic & SEO Badge */}
          <div className="lg:col-span-4 space-y-4">
            <h4 className="font-bold text-white text-sm font-display tracking-wider uppercase">
              Academic & SEO Documentation
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Designed as an SEO-optimized MCA final project for Anbu Fruit & Vegetable Shop featuring LocalBusiness JSON-LD structured data, dynamic 3D WebGL renderer, and sitemap generator.
            </p>

            <button
              onClick={onOpenReport}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-emerald-500 hover:text-slate-950 text-emerald-400 font-bold text-xs border border-emerald-500/30 transition-all flex items-center justify-center gap-2"
            >
              <Award className="w-4 h-4 text-emerald-400" />
              <span>View Project Report & SEO Artifacts</span>
            </button>
          </div>

        </div>

        {/* Bottom copyright bar */}
        <div className="border-t border-slate-900 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2008 - 2026 Anbu Fruit & Vegetable Shop. All Rights Reserved. Balakrishnapuram, Dindigul.</p>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-slate-400">
              Crafted with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 inline" /> in Tamil Nadu
            </span>

            <button
              onClick={scrollToTop}
              title="Back to top"
              className="p-2 rounded-full bg-slate-900 text-emerald-400 hover:text-white border border-slate-800"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
