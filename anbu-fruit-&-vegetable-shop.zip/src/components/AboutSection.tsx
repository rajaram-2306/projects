import React from 'react';
import { STORE_INFO } from '../data/storeData';
import { Award, ShieldCheck, Heart, Leaf, Users, Clock, CheckCircle2, MapPin, Phone } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <div className="pt-24 md:pt-28 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
      
      {/* Header Banner */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <span className="text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          Our Heritage & Story
        </span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white font-display">
          About <span className="text-emerald-400 font-serif-italic font-normal">Anbu Fruit & Vegetable Shop</span>
        </h1>
        <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
          Serving Balakrishnapuram and Dindigul with farm-harvested chemical-free produce, traditional honesty, and doorstep convenience since 2008.
        </p>
      </div>

      {/* Main Story & Owner's Message */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-7 space-y-6">
          <div className="glass-card p-8 rounded-3xl border border-emerald-500/20 space-y-4">
            <h2 className="text-2xl font-bold text-white font-display">
              Our Journey: From A Humble Stall To Dindigul's Most Loved Fresh Store
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              In 2008, <strong>Mr. Anbu</strong> laid the foundation for Anbu Fruit & Vegetable Shop with a single clear vision: to ensure that every household in Balakrishnapuram had access to genuinely fresh, nutrient-rich fruits and vegetables without paying exorbitant prices or eating chemically ripened produce.
            </p>
            <p className="text-slate-300 text-sm leading-relaxed">
              Over the last 18 years, our relationship with local farmers in Oddanchatram, Ooty, and surrounding Dindigul agricultural belts has grown deep. Every morning at 5:00 AM, our team handpicks the finest daily harvests, inspects each item for crispness, and arranges them in our store for local families and doorstep delivery.
            </p>
          </div>

          {/* Owner Message Quote Box */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-950 to-slate-900 border-l-4 border-emerald-400 space-y-3">
            <p className="text-slate-200 text-sm font-serif-italic italic leading-relaxed">
              "We treat every customer who walks into our Balakrishnapuram shop as our own family. If a fruit isn't good enough for my own children to eat, it will never sit on our shelves. That is the Anbu Promise."
            </p>
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="font-bold text-emerald-400 font-display">— Mr. Anbu, Founder & Proprietor</span>
              <span className="text-slate-400 font-mono">Balakrishnapuram, Dindigul</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 space-y-4">
          <div className="relative rounded-3xl overflow-hidden border border-emerald-500/30 shadow-2xl">
            <img
              src="https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=800&q=80"
              alt="Anbu Organic Fresh Fruits"
              className="w-full h-80 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#070d0a] via-transparent to-transparent opacity-80" />
            <div className="absolute bottom-6 inset-x-6 text-white space-y-1">
              <p className="text-lg font-bold font-display">100% Farm-Direct Sourcing</p>
              <p className="text-xs text-emerald-300">Freshness harvested daily at dawn</p>
            </div>
          </div>

          {/* Business Highlights Box */}
          <div className="grid grid-cols-2 gap-3">
            <div className="glass-card p-4 rounded-2xl text-center border border-emerald-500/20">
              <p className="text-2xl font-bold text-emerald-400 font-display">18+ Years</p>
              <p className="text-[11px] text-slate-400 font-medium">Serving Dindigul</p>
            </div>
            <div className="glass-card p-4 rounded-2xl text-center border border-emerald-500/20">
              <p className="text-2xl font-bold text-amber-400 font-display">5,000+</p>
              <p className="text-[11px] text-slate-400 font-medium">Happy Local Homes</p>
            </div>
          </div>
        </div>
      </div>

      {/* MISSION, VISION, CORE VALUES */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-8 rounded-3xl space-y-3 border border-emerald-500/20 hover:border-emerald-500/40 transition-colors">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
            <Leaf className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white font-display">Our Mission</h3>
          <p className="text-slate-300 text-xs leading-relaxed">
            To make chemical-free, farm-fresh organic fruits and vegetables easily accessible and affordable to every family in Balakrishnapuram and Dindigul.
          </p>
        </div>

        <div className="glass-card p-8 rounded-3xl space-y-3 border border-emerald-500/20 hover:border-emerald-500/40 transition-colors">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-emerald-500/30">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white font-display">Our Vision</h3>
          <p className="text-slate-300 text-xs leading-relaxed">
            To become Tamil Nadu’s premier model for sustainable, community-first fresh produce distribution that empowers local farmers and fosters community wellness.
          </p>
        </div>

        <div className="glass-card p-8 rounded-3xl space-y-3 border border-emerald-500/20 hover:border-emerald-500/40 transition-colors">
          <div className="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center border border-emerald-500/30">
            <Heart className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white font-display">Core Values</h3>
          <p className="text-slate-300 text-xs leading-relaxed">
            Uncompromising chemical safety, honest pricing, daily morning freshness, personal warmth, and supporting local agriculture.
          </p>
        </div>
      </div>

      {/* WHY CUSTOMERS TRUST US */}
      <div className="glass-card p-8 sm:p-12 rounded-3xl border border-emerald-500/20 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">Quality Assurance Workflow</span>
          <h2 className="text-3xl font-bold text-white font-display">Why Customers Trust Anbu Shop</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2 text-center">
            <span className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center mx-auto">1</span>
            <h4 className="font-bold text-white text-sm">Dawn Farm Harvest</h4>
            <p className="text-slate-400 text-xs">Picked fresh at 5:00 AM from Oddanchatram & local fields.</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2 text-center">
            <span className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center mx-auto">2</span>
            <h4 className="font-bold text-white text-sm">Triple Quality Check</h4>
            <p className="text-slate-400 text-xs">Inspected for size, crispness, natural sweetness, and weight.</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2 text-center">
            <span className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center mx-auto">3</span>
            <h4 className="font-bold text-white text-sm">Hygienic Cold Mist</h4>
            <p className="text-slate-400 text-xs">Cleaned with pure water & stored under fresh humidity control.</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2 text-center">
            <span className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center mx-auto">4</span>
            <h4 className="font-bold text-white text-sm">30-Min Doorstep</h4>
            <p className="text-slate-400 text-xs">Packed in eco-friendly bags & delivered straight to your door.</p>
          </div>
        </div>
      </div>

    </div>
  );
};
