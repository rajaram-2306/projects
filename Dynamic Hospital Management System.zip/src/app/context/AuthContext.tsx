import React, { createContext, useContext, useState, useEffect } from 'react';
import { storage } from '../utils/storage';

interface User {
  id: string;
  email: string;
  role: 'patient' | 'doctor' | 'admin';
  name: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  register: (userData: any) => Promise<{ success: boolean; error?: string }>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Check if user is already logged in
    const currentUser = storage.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
    }
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    const users = storage.getUsers();
    const foundUser = users.find((u: any) => u.email === email && u.password === password);

    if (foundUser) {
      const userData = {
        id: foundUser.id,
        email: foundUser.email,
        role: foundUser.role,
        name: foundUser.name,
      };
      setUser(userData);
      storage.setCurrentUser(userData);
      return { success: true };
    }

    return { success: false, error: 'Invalid email or password' };
  };

  const logout = () => {
    setUser(null);
    storage.setCurrentUser(null);
  };

  const register = async (userData: any): Promise<{ success: boolean; error?: string }> => {
    const users = storage.getUsers();
    
    // Check if email already exists
    if (users.find((u: any) => u.email === userData.email)) {
      return { success: false, error: 'Email already registered' };
    }

    // Create new user
    const newUser = {
      id: `user_${Date.now()}`,
      email: userData.email,
      password: userData.password,
      role: 'patient',
      name: userData.name,
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    storage.setUsers(users);

    // Create patient profile
    const patients = storage.getPatients();
    const newPatient = {
      id: `patient_${Date.now()}`,
      userId: newUser.id,
      name: userData.name,
      email: userData.email,
      phone: userData.phone || '',
      dateOfBirth: userData.dateOfBirth || '',
      gender: userData.gender || '',
      bloodGroup: userData.bloodGroup || '',
      address: userData.address || '',
      emergencyContact: {
        name: '',
        relationship: '',
        phone: ''
      },
      medicalHistory: [],
      allergies: [],
      currentMedications: [],
      registeredDate: new Date().toISOString(),
    };

    patients.push(newPatient);
    storage.setPatients(patients);

    return { success: true };
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      register,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
