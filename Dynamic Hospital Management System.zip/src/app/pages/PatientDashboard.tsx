import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { storage } from '../utils/storage';
import { Calendar, FileText, User, AlertCircle, Clock, Activity, Plus, Download, Star, Video } from 'lucide-react';

export default function PatientDashboard() {
  const { user } = useAuth();
  const [patient, setPatient] = useState<any>(null);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [doctors, setDoctors] = useState<any[]>([]);

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = () => {
    const patients = storage.getPatients();
    const currentPatient = patients.find((p: any) => p.userId === user?.id);
    setPatient(currentPatient);

    if (currentPatient) {
      const allAppointments = storage.getAppointments();
      const patientAppointments = allAppointments.filter((a: any) => a.patientId === currentPatient.id);
      setAppointments(patientAppointments);

      const allReports = storage.getReports();
      const patientReports = allReports.filter((r: any) => r.patientId === currentPatient.id);
      setReports(patientReports);

      setDoctors(storage.getDoctors());
    }
  };

  const getDoctorName = (doctorId: string) => {
    const doctor = doctors.find(d => d.id === doctorId);
    return doctor ? doctor.name : 'Unknown Doctor';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-700';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700';
      case 'completed':
        return 'bg-blue-100 text-blue-700';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const upcomingAppointments = appointments.filter(a => 
    a.status === 'confirmed' && new Date(a.date) >= new Date()
  ).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const recentReports = reports.slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome back, {patient?.name}!</h1>
          <p className="text-gray-600">Manage your health records and appointments</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <p className="text-gray-600 text-sm">Total Appointments</p>
            <p className="text-2xl font-bold">{appointments.length}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <p className="text-gray-600 text-sm">Upcoming</p>
            <p className="text-2xl font-bold">{upcomingAppointments.length}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <p className="text-gray-600 text-sm">Medical Reports</p>
            <p className="text-2xl font-bold">{reports.length}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Activity className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <p className="text-gray-600 text-sm">Health Status</p>
            <p className="text-2xl font-bold text-green-600">Good</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Upcoming Appointments */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold">Upcoming Appointments</h2>
                <Link
                  to="/patient/book-appointment"
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                >
                  <Plus className="w-4 h-4" />
                  Book New
                </Link>
              </div>

              {upcomingAppointments.length === 0 ? (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No upcoming appointments</p>
                  <Link to="/patient/book-appointment" className="text-blue-600 hover:text-blue-700 mt-2 inline-block">
                    Book your first appointment →
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {upcomingAppointments.slice(0, 3).map((appointment) => (
                    <div key={appointment.id} className="border rounded-lg p-4 hover:shadow-md transition">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-semibold">{getDoctorName(appointment.doctorId)}</p>
                              <p className="text-sm text-gray-600">{appointment.reason}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-gray-600 ml-13">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {new Date(appointment.date).toLocaleDateString()}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {appointment.time}
                            </span>
                          </div>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                          {appointment.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Medical Reports */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold">Recent Medical Reports</h2>
                <Link to="/patient/reports" className="text-blue-600 hover:text-blue-700 text-sm">
                  View All →
                </Link>
              </div>

              {recentReports.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No medical reports yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentReports.map((report) => (
                    <div key={report.id} className="border rounded-lg p-4 hover:shadow-md transition">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <p className="font-semibold">{report.title}</p>
                            <p className="text-sm text-gray-600">
                              {new Date(report.date).toLocaleDateString()} • {getDoctorName(report.doctorId)}
                            </p>
                          </div>
                        </div>
                        <button className="p-2 hover:bg-gray-100 rounded-lg">
                          <Download className="w-5 h-5 text-gray-600" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Patient Profile Card */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Your Profile</h2>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                    {patient?.name?.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold">{patient?.name}</p>
                    <p className="text-sm text-gray-600">{patient?.email}</p>
                  </div>
                </div>
                <div className="border-t pt-3 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Blood Group:</span>
                    <span className="font-semibold">{patient?.bloodGroup || 'Not Set'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Gender:</span>
                    <span className="font-semibold">{patient?.gender || 'Not Set'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Phone:</span>
                    <span className="font-semibold">{patient?.phone || 'Not Set'}</span>
                  </div>
                </div>
                <Link
                  to="/patient/profile"
                  className="block w-full text-center px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition mt-4"
                >
                  Edit Profile
                </Link>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <Link
                  to="/patient/book-appointment"
                  className="flex items-center gap-3 p-3 hover:bg-blue-50 rounded-lg transition"
                >
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-blue-600" />
                  </div>
                  <span className="font-medium">Book Appointment</span>
                </Link>
                <Link
                  to="/patient/telemedicine"
                  className="flex items-center gap-3 p-3 hover:bg-green-50 rounded-lg transition"
                >
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <Video className="w-5 h-5 text-green-600" />
                  </div>
                  <span className="font-medium">Telemedicine</span>
                </Link>
                <Link
                  to="/patient/emergency"
                  className="flex items-center gap-3 p-3 hover:bg-red-50 rounded-lg transition"
                >
                  <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                  </div>
                  <span className="font-medium">Emergency Request</span>
                </Link>
              </div>
            </div>

            {/* Health Tips */}
            <div className="bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-lg shadow-md p-6">
              <h3 className="font-semibold mb-2">💡 Health Tip of the Day</h3>
              <p className="text-sm text-blue-50">
                Stay hydrated! Drink at least 8 glasses of water daily to maintain optimal health.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
