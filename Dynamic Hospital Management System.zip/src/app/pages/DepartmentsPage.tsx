import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { storage } from '../utils/storage';
import { Building2, Users, ArrowRight } from 'lucide-react';

export default function DepartmentsPage() {
  const [departments, setDepartments] = useState<any[]>([]);
  const [doctors, setDoctors] = useState<any[]>([]);

  useEffect(() => {
    setDepartments(storage.getDepartments());
    setDoctors(storage.getDoctors());
  }, []);

  const getDoctorCount = (deptId: string) => {
    return doctors.filter(d => d.departmentId === deptId).length;
  };

  const departmentIcons: any = {
    'dept1': '❤️',
    'dept2': '🧠',
    'dept3': '🦴',
    'dept4': '👶',
    'dept5': '🩺',
    'dept6': '⚕️',
    'dept7': '👩‍⚕️',
    'dept8': '🧘',
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Our Departments</h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Comprehensive medical care across specialized departments with expert doctors
          </p>
        </div>

        {/* Departments Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {departments.map((dept) => (
            <div
              key={dept.id}
              className="bg-white rounded-lg shadow-md hover:shadow-xl transition p-6"
            >
              <div className="text-5xl mb-4">{departmentIcons[dept.id] || '🏥'}</div>
              <h3 className="text-xl font-bold mb-2">{dept.name}</h3>
              <p className="text-gray-600 mb-4">{dept.description}</p>
              
              <div className="flex items-center justify-between pt-4 border-t">
                <div className="flex items-center gap-2 text-gray-600">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">{getDoctorCount(dept.id)} Doctors</span>
                </div>
                <Link
                  to={`/doctors?department=${dept.id}`}
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700 font-medium text-sm"
                >
                  View Doctors
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 md:p-12 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">Need Medical Assistance?</h2>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Book an appointment with our specialized doctors and get the best medical care
          </p>
          <Link
            to="/login/patient"
            className="inline-block px-8 py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100 transition"
          >
            Book Appointment Now
          </Link>
        </div>
      </div>
    </div>
  );
}
