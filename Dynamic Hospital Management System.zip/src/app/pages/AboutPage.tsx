import { Heart, Shield, Users, Award, Clock, TrendingUp } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function AboutPage() {
  const values = [
    {
      icon: Heart,
      title: 'Patient-Centered Care',
      description: 'We put our patients first, providing compassionate and personalized medical attention.'
    },
    {
      icon: Shield,
      title: 'Safety & Quality',
      description: 'Maintaining the highest standards of medical care and patient safety.'
    },
    {
      icon: Users,
      title: 'Expert Team',
      description: 'Highly qualified medical professionals dedicated to your health and wellness.'
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'Committed to delivering exceptional healthcare services and outcomes.'
    },
  ];

  const stats = [
    { number: '50+', label: 'Expert Doctors' },
    { number: '10,000+', label: 'Happy Patients' },
    { number: '15+', label: 'Departments' },
    { number: '20+', label: 'Years of Service' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-6">About SmartHealth HMS</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Leading the way in modern healthcare with innovative technology and compassionate care
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">Our Mission</h2>
              <p className="text-gray-600 mb-4 text-lg">
                At SmartHealth Care Administration System, our mission is to revolutionize healthcare delivery
                by combining cutting-edge technology with personalized patient care.
              </p>
              <p className="text-gray-600 mb-4 text-lg">
                We strive to make quality healthcare accessible, efficient, and patient-friendly through our
                comprehensive hospital management platform.
              </p>
              <p className="text-gray-600 text-lg">
                Our team of dedicated healthcare professionals works tirelessly to ensure every patient
                receives the highest standard of medical attention and support.
              </p>
            </div>
            <div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1770836037622-11643462bc1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwdGVhbSUyMGhlYWx0aGNhcmUlMjBwcm9mZXNzaW9uYWxzfGVufDF8fHx8MTc3MzA0NTMzNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Medical Team"
                className="rounded-lg shadow-xl w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Our Core Values</h2>
            <p className="text-gray-600 text-lg">The principles that guide everything we do</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index}>
                <div className="text-5xl font-bold mb-2">{stat.number}</div>
                <div className="text-blue-100">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Advanced Healthcare Technology</h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto">
              Our state-of-the-art hospital management system brings together the best in medical technology
              and patient care innovation
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">24/7 Availability</h3>
              <p className="text-gray-600">
                Access medical services and support anytime, anywhere through our digital platform.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Secure & Private</h3>
              <p className="text-gray-600">
                Your health data is protected with enterprise-grade security and encryption.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Continuous Innovation</h3>
              <p className="text-gray-600">
                We constantly evolve our platform with the latest healthcare technologies.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Join Our Healthcare Community</h2>
          <p className="text-xl text-purple-100 mb-8 max-w-2xl mx-auto">
            Experience the future of healthcare management with SmartHealth HMS
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a
              href="/register/patient"
              className="px-8 py-3 bg-white text-purple-600 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              Get Started Today
            </a>
            <a
              href="/doctors"
              className="px-8 py-3 border-2 border-white text-white rounded-lg font-semibold hover:bg-white hover:text-purple-600 transition"
            >
              Find a Doctor
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
