import { useState, useEffect } from 'react';
import { storage } from '../utils/storage';
import { Users, UserPlus, Calendar, FileText, TrendingUp, Activity, AlertCircle, DollarSign } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalPatients: 0,
    totalDoctors: 0,
    totalAppointments: 0,
    todayAppointments: 0,
    pendingAppointments: 0,
    emergencyRequests: 0,
    totalRevenue: 0,
  });
  const [recentAppointments, setRecentAppointments] = useState<any[]>([]);
  const [doctors, setDoctors] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const allPatients = storage.getPatients();
    const allDoctors = storage.getDoctors();
    const allAppointments = storage.getAppointments();
    const allEmergencies = storage.getEmergencies();

    setPatients(allPatients);
    setDoctors(allDoctors);
    setRecentAppointments(allAppointments.slice(0, 5));

    const today = new Date().toDateString();
    const todayAppts = allAppointments.filter((a: any) => 
      new Date(a.date).toDateString() === today
    );

    const pendingAppts = allAppointments.filter((a: any) => a.status === 'pending');

    // Calculate revenue (mock calculation)
    const revenue = allAppointments.filter((a: any) => a.status === 'completed').length * 150;

    setStats({
      totalPatients: allPatients.length,
      totalDoctors: allDoctors.length,
      totalAppointments: allAppointments.length,
      todayAppointments: todayAppts.length,
      pendingAppointments: pendingAppts.length,
      emergencyRequests: allEmergencies.length,
      totalRevenue: revenue,
    });
  };

  const getPatientName = (patientId: string) => {
    const patient = patients.find((p: any) => p.id === patientId);
    return patient ? patient.name : 'Unknown';
  };

  const getDoctorName = (doctorId: string) => {
    const doctor = doctors.find((d: any) => d.id === doctorId);
    return doctor ? doctor.name : 'Unknown';
  };

  // Chart data
  const appointmentData = [
    { name: 'Mon', appointments: 24 },
    { name: 'Tue', appointments: 32 },
    { name: 'Wed', appointments: 28 },
    { name: 'Thu', appointments: 35 },
    { name: 'Fri', appointments: 30 },
    { name: 'Sat', appointments: 20 },
    { name: 'Sun', appointments: 15 },
  ];

  const departmentData = [
    { name: 'Cardiology', value: 30 },
    { name: 'Neurology', value: 25 },
    { name: 'Orthopedics', value: 20 },
    { name: 'Pediatrics', value: 15 },
    { name: 'Others', value: 10 },
  ];

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Hospital Management System Overview</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-500">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-gray-600 text-sm">Total Patients</p>
            <p className="text-3xl font-bold">{stats.totalPatients}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-500">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <UserPlus className="w-6 h-6 text-green-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-gray-600 text-sm">Total Doctors</p>
            <p className="text-3xl font-bold">{stats.totalDoctors}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-purple-500">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-purple-600" />
              </div>
              <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded">Today: {stats.todayAppointments}</span>
            </div>
            <p className="text-gray-600 text-sm">Total Appointments</p>
            <p className="text-3xl font-bold">{stats.totalAppointments}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-orange-500">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-orange-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-gray-600 text-sm">Total Revenue</p>
            <p className="text-3xl font-bold">${stats.totalRevenue.toLocaleString()}</p>
          </div>
        </div>

        {/* Alerts */}
        {stats.emergencyRequests > 0 && (
          <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-red-600" />
              <div>
                <p className="font-semibold text-red-900">Emergency Alerts</p>
                <p className="text-sm text-red-700">
                  {stats.emergencyRequests} emergency request(s) pending review
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Charts Section */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Appointments Chart */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Weekly Appointments</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={appointmentData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="appointments" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Department Distribution */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Department Distribution</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={departmentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {departmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Appointments */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-6">Recent Appointments</h2>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Patient</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Doctor</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Date</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Time</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {recentAppointments.map((appointment) => (
                    <tr key={appointment.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm">{getPatientName(appointment.patientId)}</td>
                      <td className="px-4 py-3 text-sm">{getDoctorName(appointment.doctorId)}</td>
                      <td className="px-4 py-3 text-sm">{new Date(appointment.date).toLocaleDateString()}</td>
                      <td className="px-4 py-3 text-sm">{appointment.time}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          appointment.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                          appointment.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                          appointment.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {appointment.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Actions & Stats */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <button className="w-full flex items-center gap-3 p-3 hover:bg-blue-50 rounded-lg transition">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <UserPlus className="w-5 h-5 text-blue-600" />
                  </div>
                  <span className="font-medium">Add Doctor</span>
                </button>
                <button className="w-full flex items-center gap-3 p-3 hover:bg-green-50 rounded-lg transition">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <Users className="w-5 h-5 text-green-600" />
                  </div>
                  <span className="font-medium">Manage Patients</span>
                </button>
                <button className="w-full flex items-center gap-3 p-3 hover:bg-purple-50 rounded-lg transition">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-purple-600" />
                  </div>
                  <span className="font-medium">View All Appointments</span>
                </button>
                <button className="w-full flex items-center gap-3 p-3 hover:bg-orange-50 rounded-lg transition">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                    <FileText className="w-5 h-5 text-orange-600" />
                  </div>
                  <span className="font-medium">Generate Reports</span>
                </button>
              </div>
            </div>

            {/* System Status */}
            <div className="bg-gradient-to-br from-purple-500 to-pink-600 text-white rounded-lg shadow-md p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Activity className="w-5 h-5" />
                System Status
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Server Status:</span>
                  <span className="font-semibold">✓ Online</span>
                </div>
                <div className="flex justify-between">
                  <span>Database:</span>
                  <span className="font-semibold">✓ Connected</span>
                </div>
                <div className="flex justify-between">
                  <span>Last Backup:</span>
                  <span className="font-semibold">2 hours ago</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
