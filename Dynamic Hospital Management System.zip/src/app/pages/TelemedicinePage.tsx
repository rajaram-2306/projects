import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Video, Phone, MessageSquare, Calendar, Clock, User, ArrowLeft, VideoOff, Mic, MicOff } from 'lucide-react';

export default function TelemedicinePage() {
  const navigate = useNavigate();
  const [activeCall, setActiveCall] = useState(false);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);

  const upcomingConsultations = [
    {
      id: 1,
      doctor: 'Dr. Sarah Johnson',
      specialization: 'Cardiology',
      date: '2026-03-12',
      time: '14:00',
      type: 'Video Call'
    },
    {
      id: 2,
      doctor: 'Dr. Michael Chen',
      specialization: 'Neurology',
      date: '2026-03-15',
      time: '10:00',
      type: 'Video Call'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <button
          onClick={() => navigate('/patient/dashboard')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </button>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Telemedicine</h1>
          <p className="text-gray-600">Connect with doctors virtually from anywhere</p>
        </div>

        {!activeCall ? (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Quick Actions */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-4">Start Consultation</h2>
                <div className="grid md:grid-cols-3 gap-4">
                  <button
                    onClick={() => setActiveCall(true)}
                    className="flex flex-col items-center gap-3 p-6 border-2 border-blue-200 rounded-lg hover:border-blue-600 hover:bg-blue-50 transition"
                  >
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <Video className="w-6 h-6 text-blue-600" />
                    </div>
                    <span className="font-semibold">Video Call</span>
                  </button>

                  <button className="flex flex-col items-center gap-3 p-6 border-2 border-green-200 rounded-lg hover:border-green-600 hover:bg-green-50 transition">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <Phone className="w-6 h-6 text-green-600" />
                    </div>
                    <span className="font-semibold">Voice Call</span>
                  </button>

                  <button className="flex flex-col items-center gap-3 p-6 border-2 border-purple-200 rounded-lg hover:border-purple-600 hover:bg-purple-50 transition">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                      <MessageSquare className="w-6 h-6 text-purple-600" />
                    </div>
                    <span className="font-semibold">Chat</span>
                  </button>
                </div>
              </div>

              {/* Upcoming Consultations */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-4">Upcoming Video Consultations</h2>
                <div className="space-y-4">
                  {upcomingConsultations.map((consultation) => (
                    <div key={consultation.id} className="border rounded-lg p-4 hover:shadow-md transition">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <User className="w-6 h-6 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-semibold">{consultation.doctor}</p>
                            <p className="text-sm text-gray-600">{consultation.specialization}</p>
                            <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                              <span className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                {new Date(consultation.date).toLocaleDateString()}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                {consultation.time}
                              </span>
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => setActiveCall(true)}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                        >
                          Join Call
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Features */}
              <div className="bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-lg shadow-md p-8">
                <h2 className="text-2xl font-bold mb-4">Telemedicine Features</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Video className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold">HD Video Quality</p>
                      <p className="text-sm text-blue-100">Crystal clear video consultations</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold">Secure Chat</p>
                      <p className="text-sm text-blue-100">End-to-end encrypted messaging</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold">Easy Scheduling</p>
                      <p className="text-sm text-blue-100">Book appointments instantly</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold">24/7 Support</p>
                      <p className="text-sm text-blue-100">Round-the-clock assistance</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-4">How It Works</h2>
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-blue-600">
                      1
                    </div>
                    <div>
                      <p className="font-semibold">Book Appointment</p>
                      <p className="text-sm text-gray-600">Schedule a video consultation</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-blue-600">
                      2
                    </div>
                    <div>
                      <p className="font-semibold">Join Video Call</p>
                      <p className="text-sm text-gray-600">Connect at scheduled time</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-blue-600">
                      3
                    </div>
                    <div>
                      <p className="font-semibold">Get Consultation</p>
                      <p className="text-sm text-gray-600">Discuss health concerns</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-blue-600">
                      4
                    </div>
                    <div>
                      <p className="font-semibold">Receive Prescription</p>
                      <p className="text-sm text-gray-600">Get digital prescription</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <p className="text-sm text-green-800">
                  <strong>Note:</strong> Ensure you have a stable internet connection and a quiet environment for the best consultation experience.
                </p>
              </div>
            </div>
          </div>
        ) : (
          /* Video Call Interface */
          <div className="bg-gray-900 rounded-lg overflow-hidden shadow-2xl">
            <div className="relative aspect-video bg-gray-800">
              {/* Main Video */}
              <div className="absolute inset-0 flex items-center justify-center">
                {videoEnabled ? (
                  <div className="text-white text-center">
                    <div className="w-32 h-32 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <User className="w-16 h-16" />
                    </div>
                    <p className="text-xl font-semibold">Dr. Sarah Johnson</p>
                    <p className="text-gray-400">Cardiology Specialist</p>
                  </div>
                ) : (
                  <div className="text-white text-center">
                    <VideoOff className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                    <p>Video is off</p>
                  </div>
                )}
              </div>

              {/* Self Video */}
              <div className="absolute bottom-4 right-4 w-48 h-36 bg-gray-700 rounded-lg overflow-hidden border-2 border-white">
                <div className="w-full h-full flex items-center justify-center">
                  <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center text-white">
                    <User className="w-8 h-8" />
                  </div>
                </div>
              </div>

              {/* Call Duration */}
              <div className="absolute top-4 left-4 bg-black/50 text-white px-4 py-2 rounded-lg">
                <Clock className="w-4 h-4 inline mr-2" />
                <span>05:23</span>
              </div>
            </div>

            {/* Controls */}
            <div className="bg-gray-800 p-6">
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={() => setVideoEnabled(!videoEnabled)}
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition ${
                    videoEnabled ? 'bg-gray-700 hover:bg-gray-600' : 'bg-red-600 hover:bg-red-700'
                  } text-white`}
                >
                  {videoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                </button>

                <button
                  onClick={() => setAudioEnabled(!audioEnabled)}
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition ${
                    audioEnabled ? 'bg-gray-700 hover:bg-gray-600' : 'bg-red-600 hover:bg-red-700'
                  } text-white`}
                >
                  {audioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
                </button>

                <button
                  onClick={() => setActiveCall(false)}
                  className="w-14 h-14 bg-red-600 hover:bg-red-700 rounded-full flex items-center justify-center text-white transition"
                >
                  <Phone className="w-6 h-6 rotate-135" />
                </button>

                <button className="w-12 h-12 bg-gray-700 hover:bg-gray-600 rounded-full flex items-center justify-center text-white transition">
                  <MessageSquare className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
