import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { storage } from '../utils/storage';
import { Calendar, Users, FileText, Clock, TrendingUp, Video, Plus } from 'lucide-react';

export default function DoctorDashboard() {
  const { user } = useAuth();
  const [doctor, setDoctor] = useState<any>(null);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = () => {
    const doctors = storage.getDoctors();
    const currentDoctor = doctors.find((d: any) => d.userId === user?.id);
    setDoctor(currentDoctor);

    if (currentDoctor) {
      const allAppointments = storage.getAppointments();
      const doctorAppointments = allAppointments.filter((a: any) => a.doctorId === currentDoctor.id);
      setAppointments(doctorAppointments);

      const allPatients = storage.getPatients();
      const uniquePatientIds = [...new Set(doctorAppointments.map((a: any) => a.patientId))];
      const doctorPatients = allPatients.filter((p: any) => uniquePatientIds.includes(p.id));
      setPatients(doctorPatients);

      const allReports = storage.getReports();
      const doctorReports = allReports.filter((r: any) => r.doctorId === currentDoctor.id);
      setReports(doctorReports);
    }
  };

  const getPatientName = (patientId: string) => {
    const allPatients = storage.getPatients();
    const patient = allPatients.find((p: any) => p.id === patientId);
    return patient ? patient.name : 'Unknown Patient';
  };

  const todayAppointments = appointments.filter(a => {
    const appointmentDate = new Date(a.date).toDateString();
    const today = new Date().toDateString();
    return appointmentDate === today;
  });

  const upcomingAppointments = appointments.filter(a => 
    new Date(a.date) >= new Date() && a.status === 'confirmed'
  ).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome, {doctor?.name}!</h1>
          <p className="text-gray-600">{doctor?.specialization} • {doctor?.qualification}</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <p className="text-gray-600 text-sm">Today's Appointments</p>
            <p className="text-2xl font-bold">{todayAppointments.length}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <p className="text-gray-600 text-sm">Total Patients</p>
            <p className="text-2xl font-bold">{patients.length}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <p className="text-gray-600 text-sm">Reports Created</p>
            <p className="text-2xl font-bold">{reports.length}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <p className="text-gray-600 text-sm">Rating</p>
            <p className="text-2xl font-bold flex items-center gap-1">
              {doctor?.rating || '4.8'} <span className="text-base text-yellow-500">★</span>
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Today's Schedule */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold">Today's Schedule</h2>
                <span className="text-sm text-gray-600">
                  {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </span>
              </div>

              {todayAppointments.length === 0 ? (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No appointments scheduled for today</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {todayAppointments.map((appointment) => (
                    <div key={appointment.id} className="border rounded-lg p-4 hover:shadow-md transition">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <Users className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <p className="font-semibold">{getPatientName(appointment.patientId)}</p>
                            <p className="text-sm text-gray-600">{appointment.reason}</p>
                            <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
                              <Clock className="w-4 h-4" />
                              <span>{appointment.time}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button className="px-3 py-1 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">
                            Start Consultation
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Upcoming Appointments */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-6">Upcoming Appointments</h2>

              {upcomingAppointments.length === 0 ? (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No upcoming appointments</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {upcomingAppointments.slice(0, 5).map((appointment) => (
                    <div key={appointment.id} className="border rounded-lg p-3 hover:bg-gray-50 transition">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold text-sm">{getPatientName(appointment.patientId)}</p>
                          <p className="text-xs text-gray-600">
                            {new Date(appointment.date).toLocaleDateString()} at {appointment.time}
                          </p>
                        </div>
                        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                          {appointment.type}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Doctor Profile */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Your Profile</h2>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                    {doctor?.name?.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold">{doctor?.name}</p>
                    <p className="text-sm text-gray-600">{doctor?.specialization}</p>
                  </div>
                </div>
                <div className="border-t pt-3 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Experience:</span>
                    <span className="font-semibold">{doctor?.experience} years</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Consultation Fee:</span>
                    <span className="font-semibold">${doctor?.consultationFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Ratings:</span>
                    <span className="font-semibold">{doctor?.totalRatings}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <button className="flex items-center gap-3 w-full p-3 hover:bg-green-50 rounded-lg transition">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <Plus className="w-5 h-5 text-green-600" />
                  </div>
                  <span className="font-medium">Upload Report</span>
                </button>
                <button className="flex items-center gap-3 w-full p-3 hover:bg-blue-50 rounded-lg transition">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Video className="w-5 h-5 text-blue-600" />
                  </div>
                  <span className="font-medium">Start Video Call</span>
                </button>
                <button className="flex items-center gap-3 w-full p-3 hover:bg-purple-50 rounded-lg transition">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <FileText className="w-5 h-5 text-purple-600" />
                  </div>
                  <span className="font-medium">View All Reports</span>
                </button>
              </div>
            </div>

            {/* Availability */}
            <div className="bg-gradient-to-br from-green-500 to-teal-600 text-white rounded-lg shadow-md p-6">
              <h3 className="font-semibold mb-3">📅 Availability Status</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Status:</span>
                  <span className="font-semibold">Available</span>
                </div>
                <div className="flex justify-between">
                  <span>Next Slot:</span>
                  <span className="font-semibold">14:00 Today</span>
                </div>
              </div>
              <button className="w-full mt-4 px-4 py-2 bg-white text-green-600 rounded-lg font-semibold hover:bg-gray-100 transition">
                Update Schedule
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
