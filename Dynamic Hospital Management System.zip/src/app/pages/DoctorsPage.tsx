import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router';
import { storage } from '../utils/storage';
import { Star, Briefcase, DollarSign, Calendar } from 'lucide-react';

export default function DoctorsPage() {
  const [searchParams] = useSearchParams();
  const [doctors, setDoctors] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [filteredDoctors, setFilteredDoctors] = useState<any[]>([]);
  const [selectedDept, setSelectedDept] = useState('');

  useEffect(() => {
    const allDoctors = storage.getDoctors();
    const allDepts = storage.getDepartments();
    
    setDoctors(allDoctors);
    setDepartments(allDepts);

    const deptParam = searchParams.get('department');
    if (deptParam) {
      setSelectedDept(deptParam);
      setFilteredDoctors(allDoctors.filter((d: any) => d.departmentId === deptParam));
    } else {
      setFilteredDoctors(allDoctors);
    }
  }, [searchParams]);

  const handleDepartmentFilter = (deptId: string) => {
    setSelectedDept(deptId);
    if (deptId === '') {
      setFilteredDoctors(doctors);
    } else {
      setFilteredDoctors(doctors.filter((d: any) => d.departmentId === deptId));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Our Expert Doctors</h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Experienced medical professionals dedicated to your health and wellness
          </p>
        </div>

        {/* Filter */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-3 justify-center">
            <button
              onClick={() => handleDepartmentFilter('')}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                selectedDept === ''
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              All Departments
            </button>
            {departments.map((dept) => (
              <button
                key={dept.id}
                onClick={() => handleDepartmentFilter(dept.id)}
                className={`px-4 py-2 rounded-lg font-medium transition ${
                  selectedDept === dept.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                {dept.name}
              </button>
            ))}
          </div>
        </div>

        {/* Doctors Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredDoctors.map((doctor) => (
            <div
              key={doctor.id}
              className="bg-white rounded-lg shadow-md hover:shadow-xl transition overflow-hidden"
            >
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 h-24"></div>
              <div className="p-6 -mt-12">
                <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-3xl font-bold text-blue-600 border-4 border-white shadow-lg mb-4">
                  {doctor.name.charAt(0)}
                </div>
                
                <h3 className="text-xl font-bold mb-1">{doctor.name}</h3>
                <p className="text-blue-600 font-medium mb-3">{doctor.specialization}</p>
                
                <div className="space-y-2 text-sm text-gray-600 mb-4">
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-4 h-4" />
                    <span>{doctor.qualification}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span>{doctor.rating} ({doctor.totalRatings} reviews)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    <span>Consultation: ${doctor.consultationFee}</span>
                  </div>
                </div>

                <p className="text-gray-600 text-sm mb-4 line-clamp-2">{doctor.about}</p>

                <Link
                  to="/login/patient"
                  className="flex items-center justify-center gap-2 w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                >
                  <Calendar className="w-4 h-4" />
                  Book Appointment
                </Link>
              </div>
            </div>
          ))}
        </div>

        {filteredDoctors.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No doctors found in this department.</p>
          </div>
        )}
      </div>
    </div>
  );
}
