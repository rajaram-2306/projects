import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { storage } from '../utils/storage';
import { Calendar, Clock, User, FileText, CheckCircle, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

export default function BookAppointment() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [departments, setDepartments] = useState<any[]>([]);
  const [doctors, setDoctors] = useState<any[]>([]);
  const [filteredDoctors, setFilteredDoctors] = useState<any[]>([]);
  const [patient, setPatient] = useState<any>(null);

  const [formData, setFormData] = useState({
    departmentId: '',
    doctorId: '',
    date: '',
    time: '',
    reason: '',
    type: 'in-person',
  });

  useEffect(() => {
    setDepartments(storage.getDepartments());
    setDoctors(storage.getDoctors());
    
    const patients = storage.getPatients();
    const currentPatient = patients.find((p: any) => p.userId === user?.id);
    setPatient(currentPatient);
  }, [user]);

  useEffect(() => {
    if (formData.departmentId) {
      const filtered = doctors.filter((d: any) => d.departmentId === formData.departmentId);
      setFilteredDoctors(filtered);
    } else {
      setFilteredDoctors(doctors);
    }
  }, [formData.departmentId, doctors]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!patient) {
      toast.error('Patient information not found');
      return;
    }

    const appointments = storage.getAppointments();
    const newAppointment = {
      id: `apt_${Date.now()}`,
      patientId: patient.id,
      doctorId: formData.doctorId,
      departmentId: formData.departmentId,
      date: formData.date,
      time: formData.time,
      reason: formData.reason,
      status: 'confirmed',
      type: formData.type,
      notes: '',
      createdAt: new Date().toISOString(),
    };

    appointments.push(newAppointment);
    storage.setAppointments(appointments);

    // Add notification
    const notifications = storage.getNotifications();
    notifications.push({
      id: `notif_${Date.now()}`,
      userId: user?.id,
      type: 'appointment',
      title: 'Appointment Confirmed',
      message: `Your appointment has been confirmed for ${formData.date} at ${formData.time}`,
      read: false,
      createdAt: new Date().toISOString(),
    });
    storage.setNotifications(notifications);

    toast.success('Appointment booked successfully!');
    navigate('/patient/dashboard');
  };

  const selectedDoctor = doctors.find((d: any) => d.id === formData.doctorId);
  const selectedDepartment = departments.find((d: any) => d.id === formData.departmentId);

  const getAvailableTimeSlots = () => {
    if (!selectedDoctor || !formData.date) return [];
    
    const dayOfWeek = new Date(formData.date).toLocaleDateString('en-US', { weekday: 'lowercase' });
    return selectedDoctor.availability[dayOfWeek] || [];
  };

  const timeSlots = getAvailableTimeSlots();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <button
          onClick={() => navigate('/patient/dashboard')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </button>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center gap-4 mb-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                    step >= s ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {s}
                </div>
                {s < 3 && (
                  <div
                    className={`w-16 h-1 mx-2 ${
                      step > s ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="text-center">
            <p className="text-gray-600">
              {step === 1 && 'Select Department & Doctor'}
              {step === 2 && 'Choose Date & Time'}
              {step === 3 && 'Confirm Details'}
            </p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-8">
          <form onSubmit={handleSubmit}>
            {/* Step 1: Select Department & Doctor */}
            {step === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold mb-6">Select Department & Doctor</h2>

                <div>
                  <label className="block text-sm font-medium mb-2">Department *</label>
                  <select
                    value={formData.departmentId}
                    onChange={(e) => setFormData({ ...formData, departmentId: e.target.value, doctorId: '' })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Department</option>
                    {departments.map((dept) => (
                      <option key={dept.id} value={dept.id}>
                        {dept.name}
                      </option>
                    ))}
                  </select>
                </div>

                {formData.departmentId && (
                  <div>
                    <label className="block text-sm font-medium mb-3">Select Doctor *</label>
                    <div className="grid md:grid-cols-2 gap-4">
                      {filteredDoctors.map((doctor) => (
                        <div
                          key={doctor.id}
                          onClick={() => setFormData({ ...formData, doctorId: doctor.id })}
                          className={`border-2 rounded-lg p-4 cursor-pointer transition ${
                            formData.doctorId === doctor.id
                              ? 'border-blue-600 bg-blue-50'
                              : 'border-gray-200 hover:border-blue-300'
                          }`}
                        >
                          <div className="flex items-start gap-3">
                            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                              {doctor.name.charAt(0)}
                            </div>
                            <div className="flex-1">
                              <p className="font-semibold">{doctor.name}</p>
                              <p className="text-sm text-gray-600">{doctor.specialization}</p>
                              <p className="text-sm text-gray-600">{doctor.qualification}</p>
                              <div className="flex items-center gap-2 mt-2">
                                <span className="text-yellow-500">★</span>
                                <span className="text-sm font-medium">{doctor.rating}</span>
                                <span className="text-sm text-gray-500">({doctor.totalRatings})</span>
                              </div>
                              <p className="text-sm text-blue-600 font-semibold mt-1">
                                Fee: ${doctor.consultationFee}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setStep(2)}
                  disabled={!formData.doctorId}
                  className="w-full py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition disabled:bg-gray-400"
                >
                  Next: Choose Date & Time
                </button>
              </div>
            )}

            {/* Step 2: Choose Date & Time */}
            {step === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold mb-6">Choose Date & Time</h2>

                <div>
                  <label className="block text-sm font-medium mb-2">Appointment Type *</label>
                  <div className="grid grid-cols-2 gap-4">
                    <div
                      onClick={() => setFormData({ ...formData, type: 'in-person' })}
                      className={`border-2 rounded-lg p-4 cursor-pointer transition ${
                        formData.type === 'in-person'
                          ? 'border-blue-600 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <p className="font-semibold text-center">In-Person Visit</p>
                    </div>
                    <div
                      onClick={() => setFormData({ ...formData, type: 'telemedicine' })}
                      className={`border-2 rounded-lg p-4 cursor-pointer transition ${
                        formData.type === 'telemedicine'
                          ? 'border-blue-600 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <p className="font-semibold text-center">Telemedicine</p>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Select Date *</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value, time: '' })}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                {formData.date && (
                  <div>
                    <label className="block text-sm font-medium mb-3">Available Time Slots *</label>
                    {timeSlots.length === 0 ? (
                      <p className="text-gray-500 text-center py-4">
                        No available slots for the selected date. Please choose another date.
                      </p>
                    ) : (
                      <div className="grid grid-cols-4 gap-3">
                        {timeSlots.map((slot) => (
                          <div
                            key={slot}
                            onClick={() => setFormData({ ...formData, time: slot })}
                            className={`border-2 rounded-lg p-3 text-center cursor-pointer transition ${
                              formData.time === slot
                                ? 'border-blue-600 bg-blue-50 text-blue-600 font-semibold'
                                : 'border-gray-200 hover:border-blue-300'
                            }`}
                          >
                            {slot}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium mb-2">Reason for Visit *</label>
                  <textarea
                    value={formData.reason}
                    onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                    placeholder="Please describe your symptoms or reason for consultation"
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    disabled={!formData.date || !formData.time || !formData.reason}
                    className="flex-1 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition disabled:bg-gray-400"
                  >
                    Next: Confirm Details
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Confirm Details */}
            {step === 3 && (
              <div className="space-y-6">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <h2 className="text-2xl font-bold">Confirm Your Appointment</h2>
                  <p className="text-gray-600 mt-2">Please review your appointment details</p>
                </div>

                <div className="bg-gray-50 rounded-lg p-6 space-y-4">
                  <div className="flex items-start gap-3">
                    <User className="w-5 h-5 text-gray-600 mt-1" />
                    <div>
                      <p className="text-sm text-gray-600">Doctor</p>
                      <p className="font-semibold">{selectedDoctor?.name}</p>
                      <p className="text-sm text-gray-600">{selectedDepartment?.name}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-gray-600 mt-1" />
                    <div>
                      <p className="text-sm text-gray-600">Date & Time</p>
                      <p className="font-semibold">
                        {new Date(formData.date).toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </p>
                      <p className="font-semibold">{formData.time}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <FileText className="w-5 h-5 text-gray-600 mt-1" />
                    <div>
                      <p className="text-sm text-gray-600">Reason for Visit</p>
                      <p className="font-semibold">{formData.reason}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-gray-600 mt-1" />
                    <div>
                      <p className="text-sm text-gray-600">Appointment Type</p>
                      <p className="font-semibold capitalize">{formData.type.replace('-', ' ')}</p>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Consultation Fee</span>
                      <span className="text-2xl font-bold text-blue-600">
                        ${selectedDoctor?.consultationFee}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="flex-1 py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition"
                  >
                    Confirm & Book Appointment
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
