import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { storage } from '../utils/storage';
import { AlertCircle, Phone, MapPin, User, FileText, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

export default function EmergencyRequest() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    patientName: '',
    phone: '',
    location: '',
    emergencyType: '',
    description: '',
    severity: 'high',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const emergencies = storage.getEmergencies();
    const newEmergency = {
      id: `emerg_${Date.now()}`,
      userId: user?.id,
      ...formData,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    emergencies.push(newEmergency);
    storage.setEmergencies(emergencies);

    // Add notification
    const notifications = storage.getNotifications();
    notifications.push({
      id: `notif_${Date.now()}`,
      userId: user?.id,
      type: 'emergency',
      title: 'Emergency Request Submitted',
      message: 'Your emergency request has been submitted. Our team will contact you shortly.',
      read: false,
      createdAt: new Date().toISOString(),
    });
    storage.setNotifications(notifications);

    toast.success('Emergency request submitted successfully!');
    navigate('/patient/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100 py-12 px-4">
      <div className="container mx-auto max-w-2xl">
        <button
          onClick={() => navigate('/patient/dashboard')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </button>

        {/* Warning Banner */}
        <div className="bg-red-600 text-white rounded-lg p-6 mb-8">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-8 h-8 flex-shrink-0" />
            <div>
              <h2 className="text-2xl font-bold mb-2">Emergency Request</h2>
              <p className="text-red-100">
                For life-threatening emergencies, please call 911 immediately. This form is for urgent but non-life-threatening medical situations.
              </p>
              <div className="mt-4 flex items-center gap-2 bg-red-700 rounded-lg px-4 py-2 inline-flex">
                <Phone className="w-5 h-5" />
                <span className="font-semibold">Emergency Hotline: 1-800-EMERGENCY</span>
              </div>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="bg-white rounded-lg shadow-xl p-8">
          <h3 className="text-xl font-bold mb-6">Submit Emergency Request</h3>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium mb-2">Patient Name *</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={formData.patientName}
                  onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                  placeholder="Full Name"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Contact Phone *</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+1-555-0000"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Current Location *</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="Address or Location"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Emergency Type *</label>
              <select
                value={formData.emergencyType}
                onChange={(e) => setFormData({ ...formData, emergencyType: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                required
              >
                <option value="">Select Emergency Type</option>
                <option value="chest-pain">Chest Pain</option>
                <option value="breathing-difficulty">Breathing Difficulty</option>
                <option value="severe-injury">Severe Injury</option>
                <option value="high-fever">High Fever</option>
                <option value="severe-bleeding">Severe Bleeding</option>
                <option value="poisoning">Poisoning</option>
                <option value="allergic-reaction">Severe Allergic Reaction</option>
                <option value="other">Other Medical Emergency</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Severity Level *</label>
              <div className="grid grid-cols-3 gap-3">
                {['low', 'medium', 'high'].map((level) => (
                  <div
                    key={level}
                    onClick={() => setFormData({ ...formData, severity: level })}
                    className={`border-2 rounded-lg p-3 text-center cursor-pointer transition ${
                      formData.severity === level
                        ? level === 'high'
                          ? 'border-red-600 bg-red-50'
                          : level === 'medium'
                          ? 'border-orange-600 bg-orange-50'
                          : 'border-yellow-600 bg-yellow-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <p className="font-semibold capitalize">{level}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Description of Emergency *</label>
              <div className="relative">
                <FileText className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Please describe the emergency situation in detail..."
                  rows={5}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  required
                />
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <p className="text-sm text-amber-800">
                <strong>Note:</strong> By submitting this form, you agree that the information provided is accurate.
                Our emergency response team will contact you within minutes.
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition text-lg"
            >
              Submit Emergency Request
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
