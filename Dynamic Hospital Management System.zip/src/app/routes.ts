import { createBrowserRouter } from 'react-router';

// Pages
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import PatientLogin from './pages/PatientLogin';
import PatientRegister from './pages/PatientRegister';
import DoctorLogin from './pages/DoctorLogin';
import AdminLogin from './pages/AdminLogin';
import PatientDashboard from './pages/PatientDashboard';
import DoctorDashboard from './pages/DoctorDashboard';
import AdminDashboard from './pages/AdminDashboard';
import BookAppointment from './pages/BookAppointment';
import DepartmentsPage from './pages/DepartmentsPage';
import DoctorsPage from './pages/DoctorsPage';
import EmergencyRequest from './pages/EmergencyRequest';
import TelemedicinePage from './pages/TelemedicinePage';
import NotFound from './pages/NotFound';

// Layout
import RootLayout from './layouts/RootLayout';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: RootLayout,
    children: [
      {
        index: true,
        Component: HomePage,
      },
      {
        path: 'about',
        Component: AboutPage,
      },
      {
        path: 'departments',
        Component: DepartmentsPage,
      },
      {
        path: 'doctors',
        Component: DoctorsPage,
      },
      {
        path: 'login/patient',
        Component: PatientLogin,
      },
      {
        path: 'register/patient',
        Component: PatientRegister,
      },
      {
        path: 'login/doctor',
        Component: DoctorLogin,
      },
      {
        path: 'login/admin',
        Component: AdminLogin,
      },
      {
        path: 'patient/dashboard',
        Component: PatientDashboard,
      },
      {
        path: 'patient/book-appointment',
        Component: BookAppointment,
      },
      {
        path: 'patient/emergency',
        Component: EmergencyRequest,
      },
      {
        path: 'patient/telemedicine',
        Component: TelemedicinePage,
      },
      {
        path: 'doctor/dashboard',
        Component: DoctorDashboard,
      },
      {
        path: 'admin/dashboard',
        Component: AdminDashboard,
      },
      {
        path: '*',
        Component: NotFound,
      },
    ],
  },
]);