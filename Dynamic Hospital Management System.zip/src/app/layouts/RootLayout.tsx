import { Outlet, useLocation } from 'react-router';
import { Navbar } from '../components/Navbar';
import { Toaster } from 'sonner';

export default function RootLayout() {
  const location = useLocation();
  
  // Hide navbar on login/register pages
  const hideNavbar = location.pathname.includes('/login') || location.pathname.includes('/register');

  return (
    <div className="min-h-screen bg-gray-50">
      {!hideNavbar && <Navbar />}
      <main>
        <Outlet />
      </main>
      <Toaster position="top-right" richColors />
    </div>
  );
}
