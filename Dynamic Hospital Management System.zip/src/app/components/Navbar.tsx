import { Link, useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { Bell, User, LogOut, Menu, X, Activity } from 'lucide-react';
import { useState } from 'react';
import { storage } from '../utils/storage';

export function Navbar() {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const notifications = storage.getNotifications().filter((n: any) => n.userId === user?.id && !n.read);

  const handleLogout = () => {
    logout();
    navigate('/');
    setMobileMenuOpen(false);
  };

  const getDashboardLink = () => {
    if (!user) return '/';
    switch (user.role) {
      case 'patient':
        return '/patient/dashboard';
      case 'doctor':
        return '/doctor/dashboard';
      case 'admin':
        return '/admin/dashboard';
      default:
        return '/';
    }
  };

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <Activity className="w-8 h-8 text-blue-600" />
            <span className="font-semibold text-xl">SmartHealth HMS</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            {!isAuthenticated ? (
              <>
                <Link to="/" className="text-gray-600 hover:text-blue-600 transition">
                  Home
                </Link>
                <Link to="/about" className="text-gray-600 hover:text-blue-600 transition">
                  About
                </Link>
                <Link to="/departments" className="text-gray-600 hover:text-blue-600 transition">
                  Departments
                </Link>
                <Link to="/doctors" className="text-gray-600 hover:text-blue-600 transition">
                  Doctors
                </Link>
                <Link
                  to="/login/patient"
                  className="px-4 py-2 text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50 transition"
                >
                  Patient Login
                </Link>
                <Link
                  to="/login/doctor"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                >
                  Doctor Login
                </Link>
              </>
            ) : (
              <>
                <Link to={getDashboardLink()} className="text-gray-600 hover:text-blue-600 transition">
                  Dashboard
                </Link>
                
                {/* Notifications */}
                <div className="relative">
                  <button
                    onClick={() => setNotificationsOpen(!notificationsOpen)}
                    className="relative p-2 text-gray-600 hover:text-blue-600 transition"
                  >
                    <Bell className="w-5 h-5" />
                    {notifications.length > 0 && (
                      <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                    )}
                  </button>
                  
                  {notificationsOpen && (
                    <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border py-2 max-h-96 overflow-y-auto">
                      <div className="px-4 py-2 border-b">
                        <p className="font-semibold">Notifications</p>
                      </div>
                      {notifications.length === 0 ? (
                        <p className="px-4 py-3 text-gray-500 text-sm">No new notifications</p>
                      ) : (
                        notifications.map((notif: any) => (
                          <div key={notif.id} className="px-4 py-3 hover:bg-gray-50 border-b last:border-b-0">
                            <p className="font-medium text-sm">{notif.title}</p>
                            <p className="text-xs text-gray-600 mt-1">{notif.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>

                {/* User Menu */}
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-sm font-medium">{user.name}</p>
                    <p className="text-xs text-gray-500 capitalize">{user.role}</p>
                  </div>
                  <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                    <User className="w-5 h-5" />
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-gray-600 hover:text-blue-600"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            {!isAuthenticated ? (
              <div className="flex flex-col gap-2">
                <Link
                  to="/"
                  className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Home
                </Link>
                <Link
                  to="/about"
                  className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  About
                </Link>
                <Link
                  to="/departments"
                  className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Departments
                </Link>
                <Link
                  to="/doctors"
                  className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Doctors
                </Link>
                <Link
                  to="/login/patient"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg text-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Patient Login
                </Link>
                <Link
                  to="/login/doctor"
                  className="px-4 py-2 border border-blue-600 text-blue-600 rounded-lg text-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Doctor Login
                </Link>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <Link
                  to={getDashboardLink()}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Dashboard
                </Link>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg text-left flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
