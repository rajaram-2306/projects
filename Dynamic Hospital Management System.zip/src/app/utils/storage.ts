// localStorage utility functions for data persistence

export const storage = {
  // Users
  getUsers: () => {
    const users = localStorage.getItem('hms_users');
    return users ? JSON.parse(users) : [];
  },
  setUsers: (users: any[]) => {
    localStorage.setItem('hms_users', JSON.stringify(users));
  },
  
  // Patients
  getPatients: () => {
    const patients = localStorage.getItem('hms_patients');
    return patients ? JSON.parse(patients) : [];
  },
  setPatients: (patients: any[]) => {
    localStorage.setItem('hms_patients', JSON.stringify(patients));
  },
  
  // Doctors
  getDoctors: () => {
    const doctors = localStorage.getItem('hms_doctors');
    return doctors ? JSON.parse(doctors) : [];
  },
  setDoctors: (doctors: any[]) => {
    localStorage.setItem('hms_doctors', JSON.stringify(doctors));
  },
  
  // Appointments
  getAppointments: () => {
    const appointments = localStorage.getItem('hms_appointments');
    return appointments ? JSON.parse(appointments) : [];
  },
  setAppointments: (appointments: any[]) => {
    localStorage.setItem('hms_appointments', JSON.stringify(appointments));
  },
  
  // Medical Reports
  getReports: () => {
    const reports = localStorage.getItem('hms_reports');
    return reports ? JSON.parse(reports) : [];
  },
  setReports: (reports: any[]) => {
    localStorage.setItem('hms_reports', JSON.stringify(reports));
  },
  
  // Emergency Requests
  getEmergencies: () => {
    const emergencies = localStorage.getItem('hms_emergencies');
    return emergencies ? JSON.parse(emergencies) : [];
  },
  setEmergencies: (emergencies: any[]) => {
    localStorage.setItem('hms_emergencies', JSON.stringify(emergencies));
  },
  
  // Feedback
  getFeedback: () => {
    const feedback = localStorage.getItem('hms_feedback');
    return feedback ? JSON.parse(feedback) : [];
  },
  setFeedback: (feedback: any[]) => {
    localStorage.setItem('hms_feedback', JSON.stringify(feedback));
  },
  
  // Departments
  getDepartments: () => {
    const departments = localStorage.getItem('hms_departments');
    return departments ? JSON.parse(departments) : [];
  },
  setDepartments: (departments: any[]) => {
    localStorage.setItem('hms_departments', JSON.stringify(departments));
  },
  
  // Payments
  getPayments: () => {
    const payments = localStorage.getItem('hms_payments');
    return payments ? JSON.parse(payments) : [];
  },
  setPayments: (payments: any[]) => {
    localStorage.setItem('hms_payments', JSON.stringify(payments));
  },
  
  // Notifications
  getNotifications: () => {
    const notifications = localStorage.getItem('hms_notifications');
    return notifications ? JSON.parse(notifications) : [];
  },
  setNotifications: (notifications: any[]) => {
    localStorage.setItem('hms_notifications', JSON.stringify(notifications));
  },
  
  // Current User
  getCurrentUser: () => {
    const user = localStorage.getItem('hms_current_user');
    return user ? JSON.parse(user) : null;
  },
  setCurrentUser: (user: any) => {
    if (user) {
      localStorage.setItem('hms_current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('hms_current_user');
    }
  },
  
  // Clear all data
  clearAll: () => {
    localStorage.clear();
  }
};
