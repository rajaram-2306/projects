// Initial mock data for the hospital management system

export const initialDepartments = [
  { id: 'dept1', name: 'Cardiology', description: 'Heart and cardiovascular system' },
  { id: 'dept2', name: 'Neurology', description: 'Brain and nervous system' },
  { id: 'dept3', name: 'Orthopedics', description: 'Bones and joints' },
  { id: 'dept4', name: 'Pediatrics', description: 'Children\'s health' },
  { id: 'dept5', name: 'Dermatology', description: 'Skin conditions' },
  { id: 'dept6', name: 'General Medicine', description: 'General health issues' },
  { id: 'dept7', name: 'Gynecology', description: 'Women\'s health' },
  { id: 'dept8', name: 'Psychiatry', description: 'Mental health' },
];

export const initialDoctors = [
  {
    id: 'doc1',
    userId: 'user_doc1',
    name: 'Dr. Sarah Johnson',
    email: 'sarah.johnson@hospital.com',
    phone: '+1-555-0101',
    specialization: 'Cardiology',
    departmentId: 'dept1',
    qualification: 'MD, FACC',
    experience: 15,
    consultationFee: 150,
    rating: 4.8,
    totalRatings: 234,
    availability: {
      monday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
      tuesday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
      wednesday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
      thursday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
      friday: ['09:00', '10:00', '11:00', '14:00', '15:00'],
      saturday: ['09:00', '10:00', '11:00'],
      sunday: []
    },
    about: 'Specialist in cardiovascular diseases with over 15 years of experience.'
  },
  {
    id: 'doc2',
    userId: 'user_doc2',
    name: 'Dr. Michael Chen',
    email: 'michael.chen@hospital.com',
    phone: '+1-555-0102',
    specialization: 'Neurology',
    departmentId: 'dept2',
    qualification: 'MD, PhD',
    experience: 12,
    consultationFee: 200,
    rating: 4.9,
    totalRatings: 189,
    availability: {
      monday: ['10:00', '11:00', '14:00', '15:00', '16:00'],
      tuesday: ['10:00', '11:00', '14:00', '15:00', '16:00'],
      wednesday: ['10:00', '11:00', '14:00', '15:00', '16:00'],
      thursday: ['10:00', '11:00', '14:00', '15:00', '16:00'],
      friday: ['10:00', '11:00', '14:00', '15:00'],
      saturday: [],
      sunday: []
    },
    about: 'Expert neurologist specializing in brain disorders and neurological conditions.'
  },
  {
    id: 'doc3',
    userId: 'user_doc3',
    name: 'Dr. Emily Rodriguez',
    email: 'emily.rodriguez@hospital.com',
    phone: '+1-555-0103',
    specialization: 'Pediatrics',
    departmentId: 'dept4',
    qualification: 'MD, FAAP',
    experience: 10,
    consultationFee: 120,
    rating: 4.7,
    totalRatings: 312,
    availability: {
      monday: ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00'],
      tuesday: ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00'],
      wednesday: ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00'],
      thursday: ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00'],
      friday: ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00'],
      saturday: ['09:00', '10:00', '11:00'],
      sunday: []
    },
    about: 'Dedicated pediatrician committed to children\'s health and wellness.'
  },
  {
    id: 'doc4',
    userId: 'user_doc4',
    name: 'Dr. James Wilson',
    email: 'james.wilson@hospital.com',
    phone: '+1-555-0104',
    specialization: 'Orthopedics',
    departmentId: 'dept3',
    qualification: 'MD, MS (Ortho)',
    experience: 18,
    consultationFee: 180,
    rating: 4.6,
    totalRatings: 156,
    availability: {
      monday: ['09:00', '10:00', '11:00', '15:00', '16:00'],
      tuesday: ['09:00', '10:00', '11:00', '15:00', '16:00'],
      wednesday: ['09:00', '10:00', '11:00', '15:00', '16:00'],
      thursday: ['09:00', '10:00', '11:00', '15:00', '16:00'],
      friday: ['09:00', '10:00', '11:00'],
      saturday: [],
      sunday: []
    },
    about: 'Orthopedic surgeon with expertise in joint replacement and sports injuries.'
  },
];

export const initialUsers = [
  // Admin
  {
    id: 'user_admin1',
    email: 'admin@hospital.com',
    password: 'admin123', // In production, this would be hashed
    role: 'admin',
    name: 'Admin User',
    createdAt: new Date().toISOString()
  },
  // Doctors
  {
    id: 'user_doc1',
    email: 'sarah.johnson@hospital.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dr. Sarah Johnson',
    createdAt: new Date().toISOString()
  },
  {
    id: 'user_doc2',
    email: 'michael.chen@hospital.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dr. Michael Chen',
    createdAt: new Date().toISOString()
  },
  {
    id: 'user_doc3',
    email: 'emily.rodriguez@hospital.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dr. Emily Rodriguez',
    createdAt: new Date().toISOString()
  },
  {
    id: 'user_doc4',
    email: 'james.wilson@hospital.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dr. James Wilson',
    createdAt: new Date().toISOString()
  },
  // Sample Patients
  {
    id: 'user_patient1',
    email: 'john.doe@email.com',
    password: 'patient123',
    role: 'patient',
    name: 'John Doe',
    createdAt: new Date().toISOString()
  },
  {
    id: 'user_patient2',
    email: 'jane.smith@email.com',
    password: 'patient123',
    role: 'patient',
    name: 'Jane Smith',
    createdAt: new Date().toISOString()
  },
];

export const initialPatients = [
  {
    id: 'patient1',
    userId: 'user_patient1',
    name: 'John Doe',
    email: 'john.doe@email.com',
    phone: '+1-555-1001',
    dateOfBirth: '1985-05-15',
    gender: 'Male',
    bloodGroup: 'O+',
    address: '123 Main Street, New York, NY 10001',
    emergencyContact: {
      name: 'Mary Doe',
      relationship: 'Spouse',
      phone: '+1-555-1002'
    },
    medicalHistory: [
      { condition: 'Hypertension', diagnosedDate: '2020-03-15', status: 'Ongoing' },
      { condition: 'Type 2 Diabetes', diagnosedDate: '2019-08-20', status: 'Ongoing' }
    ],
    allergies: ['Penicillin', 'Peanuts'],
    currentMedications: ['Metformin 500mg', 'Lisinopril 10mg'],
    registeredDate: '2024-01-10'
  },
  {
    id: 'patient2',
    userId: 'user_patient2',
    name: 'Jane Smith',
    email: 'jane.smith@email.com',
    phone: '+1-555-2001',
    dateOfBirth: '1992-09-22',
    gender: 'Female',
    bloodGroup: 'A+',
    address: '456 Oak Avenue, Los Angeles, CA 90001',
    emergencyContact: {
      name: 'Robert Smith',
      relationship: 'Father',
      phone: '+1-555-2002'
    },
    medicalHistory: [
      { condition: 'Asthma', diagnosedDate: '2010-05-10', status: 'Ongoing' }
    ],
    allergies: ['Dust', 'Pollen'],
    currentMedications: ['Albuterol Inhaler'],
    registeredDate: '2024-02-15'
  },
];

export const initialAppointments = [
  {
    id: 'apt1',
    patientId: 'patient1',
    doctorId: 'doc1',
    departmentId: 'dept1',
    date: '2026-03-15',
    time: '10:00',
    reason: 'Regular checkup for hypertension',
    status: 'confirmed',
    type: 'in-person',
    notes: '',
    createdAt: '2026-03-10T10:00:00Z'
  },
  {
    id: 'apt2',
    patientId: 'patient2',
    doctorId: 'doc3',
    departmentId: 'dept4',
    date: '2026-03-12',
    time: '14:00',
    reason: 'Asthma follow-up',
    status: 'completed',
    type: 'in-person',
    notes: 'Patient responded well to treatment',
    createdAt: '2026-03-05T09:00:00Z'
  },
];

export const initialReports = [
  {
    id: 'report1',
    patientId: 'patient1',
    doctorId: 'doc1',
    appointmentId: 'apt1',
    title: 'Blood Pressure Report',
    type: 'Lab Result',
    date: '2026-03-11',
    findings: 'Blood pressure is within normal range. Continue current medication.',
    prescription: 'Lisinopril 10mg - Continue',
    followUpDate: '2026-06-11',
    uploadedAt: '2026-03-11T15:30:00Z'
  },
];

export const initialNotifications = [
  {
    id: 'notif1',
    userId: 'user_patient1',
    type: 'appointment',
    title: 'Appointment Reminder',
    message: 'You have an appointment with Dr. Sarah Johnson tomorrow at 10:00 AM',
    read: false,
    createdAt: new Date(Date.now() - 86400000).toISOString() // Yesterday
  },
];

export function initializeData() {
  const storage = {
    getUsers: () => {
      const users = localStorage.getItem('hms_users');
      return users ? JSON.parse(users) : [];
    },
    setUsers: (users: any[]) => {
      localStorage.setItem('hms_users', JSON.stringify(users));
    },
    getDoctors: () => {
      const doctors = localStorage.getItem('hms_doctors');
      return doctors ? JSON.parse(doctors) : [];
    },
    setDoctors: (doctors: any[]) => {
      localStorage.setItem('hms_doctors', JSON.stringify(doctors));
    },
    getPatients: () => {
      const patients = localStorage.getItem('hms_patients');
      return patients ? JSON.parse(patients) : [];
    },
    setPatients: (patients: any[]) => {
      localStorage.setItem('hms_patients', JSON.stringify(patients));
    },
    getAppointments: () => {
      const appointments = localStorage.getItem('hms_appointments');
      return appointments ? JSON.parse(appointments) : [];
    },
    setAppointments: (appointments: any[]) => {
      localStorage.setItem('hms_appointments', JSON.stringify(appointments));
    },
    getReports: () => {
      const reports = localStorage.getItem('hms_reports');
      return reports ? JSON.parse(reports) : [];
    },
    setReports: (reports: any[]) => {
      localStorage.setItem('hms_reports', JSON.stringify(reports));
    },
    getDepartments: () => {
      const departments = localStorage.getItem('hms_departments');
      return departments ? JSON.parse(departments) : [];
    },
    setDepartments: (departments: any[]) => {
      localStorage.setItem('hms_departments', JSON.stringify(departments));
    },
    getNotifications: () => {
      const notifications = localStorage.getItem('hms_notifications');
      return notifications ? JSON.parse(notifications) : [];
    },
    setNotifications: (notifications: any[]) => {
      localStorage.setItem('hms_notifications', JSON.stringify(notifications));
    },
  };
  
  // Initialize data only if not already present
  if (storage.getUsers().length === 0) {
    storage.setUsers(initialUsers);
  }
  if (storage.getDoctors().length === 0) {
    storage.setDoctors(initialDoctors);
  }
  if (storage.getPatients().length === 0) {
    storage.setPatients(initialPatients);
  }
  if (storage.getAppointments().length === 0) {
    storage.setAppointments(initialAppointments);
  }
  if (storage.getReports().length === 0) {
    storage.setReports(initialReports);
  }
  if (storage.getDepartments().length === 0) {
    storage.setDepartments(initialDepartments);
  }
  if (storage.getNotifications().length === 0) {
    storage.setNotifications(initialNotifications);
  }
}
