# 🏥 SmartHealth Care Administration System

A comprehensive Hospital Management System with modern UI and complete functionality.

## 🚀 Quick Start

### Demo Credentials

**Patient Account:**
- Email: `john.doe@email.com`
- Password: `patient123`

**Doctor Account:**
- Email: `sarah.johnson@hospital.com`
- Password: `doctor123`

**Admin Account:**
- Email: `admin@hospital.com`
- Password: `admin123`

## ✨ Key Features

### For Patients
- ✅ Register and login
- ✅ Book appointments with doctors
- ✅ View medical reports
- ✅ Telemedicine consultations
- ✅ Emergency requests
- ✅ Profile management

### For Doctors
- ✅ View daily schedule
- ✅ Manage appointments
- ✅ Upload medical reports
- ✅ Patient management
- ✅ Availability settings

### For Admins
- ✅ System analytics dashboard
- ✅ Manage doctors and patients
- ✅ View all appointments
- ✅ Department management
- ✅ Revenue tracking

## 📱 Pages

### Public Pages
- **/** - Home page
- **/about** - About us
- **/departments** - All departments
- **/doctors** - Doctor listings

### Patient Portal
- **/login/patient** - Patient login
- **/register/patient** - Patient registration
- **/patient/dashboard** - Patient dashboard
- **/patient/book-appointment** - Book appointment
- **/patient/emergency** - Emergency request
- **/patient/telemedicine** - Virtual consultations

### Doctor Portal
- **/login/doctor** - Doctor login
- **/doctor/dashboard** - Doctor dashboard

### Admin Portal
- **/login/admin** - Admin login
- **/admin/dashboard** - Admin dashboard

## 🛠️ Technology Stack

- React 18.3.1
- TypeScript
- Tailwind CSS 4.1.12
- React Router 7.13.0
- Recharts (for analytics)
- Lucide React (icons)
- Sonner (notifications)

## 💾 Data Storage

- Uses browser localStorage for data persistence
- Pre-loaded with sample data
- No backend required for demo

## ⚠️ Important Notes

This is a **demonstration/educational project**. For production use:
- Implement proper backend with database
- Add real authentication (JWT)
- Use HIPAA-compliant infrastructure
- Add data encryption
- Implement proper security measures

## 📄 Documentation

See `PROJECT_DOCUMENTATION.md` for complete documentation.

---

**Built with ❤️ for modern healthcare**
