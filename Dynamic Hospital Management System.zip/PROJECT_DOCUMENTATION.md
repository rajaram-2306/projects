# SmartHealth Care Administration System - Hospital Management System

A comprehensive, modern Hospital Management System built with React, TypeScript, Tailwind CSS, and React Router. This application provides a complete solution for managing hospital operations including patient management, doctor scheduling, appointments, medical reports, telemedicine, and emergency services.

## 🏥 Features

### Core Modules

#### 1. **User Authentication Module**
- Multi-role login system (Patient, Doctor, Admin)
- Patient registration and login
- Doctor login portal
- Admin login portal
- Secure session management using localStorage
- Demo credentials provided for testing

#### 2. **Patient Management Module**
- Patient profile creation and management
- Personal details and medical history
- View appointment history
- Medical document management
- Blood group and emergency contact information

#### 3. **Doctor Management Module**
- Doctor profiles with specialization
- Doctor availability schedules
- Comprehensive doctor dashboard
- Rating and review system
- Department-wise doctor listing

#### 4. **Appointment Booking Module**
- Interactive appointment booking system
- Department and doctor selection
- Available time slot selection
- In-person and telemedicine options
- Appointment confirmation and notifications
- Multi-step booking process

#### 5. **Medical Report Module**
- Digital medical reports
- Report viewing and downloading
- Doctor report uploads
- Patient medical history tracking

#### 6. **Admin Dashboard**
- System statistics and analytics
- Manage patients and doctors
- Appointment management
- Department management
- Revenue tracking
- Visual charts and graphs

### Advanced Features

#### 7. **Real-Time Dashboard**
- Total patient count
- Today's appointments
- Doctor availability status
- System health monitoring

#### 8. **Emergency Request Module**
- Emergency request submission
- Severity level selection
- Location tracking
- Immediate notification system
- Emergency hotline integration

#### 9. **Telemedicine Module**
- Video consultation interface
- Audio/Video controls
- Chat functionality
- Scheduled consultations
- Virtual waiting room

#### 10. **Notification System**
- Real-time notifications
- Appointment reminders
- Emergency alerts
- Status updates

#### 11. **Feedback & Rating System**
- Doctor rating system
- Patient reviews
- Average rating calculation

## 🎨 UI Pages

### Public Pages
- **Home Page** - Hero section, features, departments, statistics, contact
- **About Page** - Mission, values, team information
- **Departments Page** - All medical departments with doctor count
- **Doctors Page** - Doctor listings with filtering options

### Authentication Pages
- **Patient Login** - Patient authentication portal
- **Patient Registration** - New patient signup form
- **Doctor Login** - Doctor authentication portal
- **Admin Login** - Administrator authentication portal

### Patient Portal
- **Patient Dashboard** - Overview, appointments, reports, quick actions
- **Book Appointment** - 3-step appointment booking process
- **Telemedicine** - Virtual consultation interface
- **Emergency Request** - Emergency medical assistance form

### Doctor Portal
- **Doctor Dashboard** - Today's schedule, patients, statistics

### Admin Portal
- **Admin Dashboard** - System overview, analytics, management

### Error Pages
- **404 Not Found** - Custom error page

## 🔐 Demo Credentials

### Patient Account
- Email: `john.doe@email.com`
- Password: `patient123`

### Doctor Account
- Email: `sarah.johnson@hospital.com`
- Password: `doctor123`

### Admin Account
- Email: `admin@hospital.com`
- Password: `admin123`

## 🛠️ Technology Stack

- **Frontend Framework**: React 18.3.1
- **Language**: TypeScript
- **Routing**: React Router 7.13.0
- **Styling**: Tailwind CSS 4.1.12
- **UI Components**: Radix UI, Lucide React Icons
- **Charts**: Recharts 2.15.2
- **Notifications**: Sonner 2.0.3
- **Build Tool**: Vite 6.3.5

## 📁 Project Structure

```
/src
  /app
    /components
      - Navbar.tsx (Navigation component)
    /context
      - AuthContext.tsx (Authentication state management)
    /layouts
      - RootLayout.tsx (Main layout wrapper)
    /pages
      - HomePage.tsx
      - AboutPage.tsx
      - DepartmentsPage.tsx
      - DoctorsPage.tsx
      - PatientLogin.tsx
      - PatientRegister.tsx
      - DoctorLogin.tsx
      - AdminLogin.tsx
      - PatientDashboard.tsx
      - DoctorDashboard.tsx
      - AdminDashboard.tsx
      - BookAppointment.tsx
      - EmergencyRequest.tsx
      - TelemedicinePage.tsx
      - NotFound.tsx
    /utils
      - mockData.ts (Initial sample data)
      - storage.ts (LocalStorage utilities)
    - App.tsx (Main application component)
    - routes.ts (Route configuration)
```

## 🚀 Getting Started

The application uses localStorage for data persistence, making it a complete frontend demo without requiring a backend server.

### Data Initialization

On first load, the application automatically initializes with:
- 4 sample doctors across different departments
- 2 sample patients
- Sample appointments
- 8 medical departments
- Admin account

### Navigation Flow

1. **Public Users**: Start at home page → View departments/doctors → Login/Register
2. **Patients**: Login → Dashboard → Book appointments → View reports → Telemedicine
3. **Doctors**: Login → Dashboard → View appointments → Manage patients
4. **Admins**: Login → Dashboard → Manage system → View analytics

## 📊 Key Features Breakdown

### Appointment Booking System
- 3-step wizard interface
- Department selection
- Doctor selection with profiles
- Date and time slot selection
- Appointment type (in-person/telemedicine)
- Booking confirmation

### Dashboard Analytics
- Visual charts using Recharts
- Real-time statistics
- Weekly appointment trends
- Department distribution
- Revenue tracking

### Responsive Design
- Mobile-first approach
- Tablet and desktop optimized
- Collapsible navigation
- Touch-friendly interfaces

## 🔒 Security Considerations

**⚠️ IMPORTANT**: This is a demonstration/prototype application. In production:

1. **Never store passwords in plain text**
2. **Use proper backend authentication**
3. **Implement HIPAA compliance**
4. **Use encrypted databases**
5. **Add proper access controls**
6. **Implement audit logging**
7. **Use HTTPS only**
8. **Add rate limiting**

## 🎯 Future Enhancements

Potential features for production version:
- Real backend integration with Node.js/Express
- MySQL/PostgreSQL database
- JWT authentication
- Real-time notifications with WebSockets
- Payment gateway integration
- PDF report generation
- Email notifications
- SMS reminders
- Prescription management
- Inventory management
- Billing system
- Insurance integration

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🎨 Color Scheme

- Primary (Blue): `#3b82f6`
- Success (Green): `#10b981`
- Warning (Orange): `#f59e0b`
- Danger (Red): `#ef4444`
- Purple: `#8b5cf6`

## 📄 License

This is a demonstration project for educational purposes.

## 🤝 Support

For issues or questions about the system, refer to the in-app contact information or admin dashboard.

---

**Built with ❤️ for modern healthcare management**
